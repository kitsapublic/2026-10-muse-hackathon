"""`eligibility-lab-service`: the operator's commands for the local service.

    init            create (or upgrade) a store
    install-bundle  install a bundle folder as public (showcase) or private (benchmark only)
    review          approve or reject one proposal, or every reference proposal of a bundle
    experiment      create, enable, disable or show a live-spending experiment
    serve           run the loopback API, worker and showcase assets
    openapi         write the published API schema
    run-baseline    queue a baseline on any installed bundle with its approved interpretations and run it
    interpret       ask the model to interpret criteria (live; proposals then await review)
    plan            calculate requests, reuse coverage and cost reservations without sending or reserving anything
    status          inspect a job and its items (including private operator jobs)
    cancel          stop new work for a job
    resume          continue only unsent work of an interrupted job
    retry           explicitly retry named failed or ambiguous items
    run-scenario    recalculate a saved scenario against an immutable baseline
    proposals       list interpretations for review or benchmark scoring
    export          write a job's JSON report

Live work (`run-baseline --mode live`, `interpret`) needs an enabled experiment, `--confirm-spend` and
MODEL_API_KEY in the environment; it spends only within the experiment's ceiling. Exit codes: 0 done; 1 the job
ended without a complete result; 2 refused.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import sys
from typing import Sequence

LOOPBACK = ("127.0.0.1", "::1", "localhost")
DEV_ORIGIN = re.compile(r"http://(127\.0\.0\.1|localhost|\[::1\]):[0-9]{1,5}")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="eligibility-lab-service", description=__doc__.split("\n\n")[0])
    commands = parser.add_subparsers(dest="command", required=True)

    def store_command(name: str, text: str) -> argparse.ArgumentParser:
        command = commands.add_parser(name, help=text)
        command.add_argument("--store", type=Path, required=True, help="store directory")
        return command

    store_command("init", "create or upgrade a store")
    install = store_command("install-bundle", "install a bundle folder")
    install.add_argument("--bundle", type=Path, required=True)
    install.add_argument("--audience", choices=("public", "private"), required=True,
                         help="public bundles are visible over HTTP; private ones only to these commands")
    review = store_command("review", "approve or reject interpretations")
    target = review.add_mutually_exclusive_group(required=True)
    target.add_argument("--proposal", help="one proposal")
    target.add_argument("--bundle-key", help="every reference proposal of this bundle (with --all-reference)")
    review.add_argument("--all-reference", action="store_true")
    review.add_argument("--decision", choices=("approved", "rejected"), required=True)
    experiment = store_command("experiment", "manage a live-spending experiment")
    experiment.add_argument("action", choices=("create", "enable", "disable", "show"))
    experiment.add_argument("--id", required=True)
    experiment.add_argument("--ceiling-usd", help="at most 15; create only")
    experiment.add_argument("--max-requests", type=int, help="create only")
    serve = store_command("serve", "run the loopback API, worker and showcase")
    serve.add_argument("--host", default="127.0.0.1", choices=LOOPBACK)
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--assets", type=Path, help="built showcase folder to serve on the same origin")
    serve.add_argument("--allow-origin", action="append", default=[],
                       help="a loopback development origin allowed to make changes, e.g. http://127.0.0.1:5173")
    serve.add_argument("--concurrency", type=int, default=4, help="concurrent provider requests (1-16)")
    serve.add_argument("--enable-live", action="store_true",
                       help="allow live model jobs for --experiment; reads MODEL_API_KEY from the environment")
    serve.add_argument("--experiment", help="the enabled experiment that live jobs spend from")
    run = store_command("run-baseline", "run a baseline with the approved interpretations")
    run.add_argument("--bundle-key", required=True)
    run.add_argument("--mode", choices=("reference", "recorded", "live"), default="reference")
    run.add_argument("--idempotency-key", required=True)
    interpret = store_command("interpret", "ask the model to interpret criteria (live)")
    interpret.add_argument("--bundle-key", required=True)
    interpret.add_argument("--criterion", action="append", help="a criterion id; default every criterion")
    interpret.add_argument("--retry", action="store_true", help="ask again even when an answer is cached")
    interpret.add_argument("--idempotency-key", required=True)
    resume = store_command("resume", "continue unsent work of a job")
    retry = store_command("retry", "retry named failed or ambiguous items; each may spend again")
    retry.add_argument("--item", action="append", required=True, help="exact item id; repeat to name more")
    for control in (resume, retry):
        control.add_argument("--job", required=True)
    for live in (run, interpret, resume, retry):
        live.add_argument("--experiment", help="the enabled experiment that live work spends from")
        live.add_argument("--confirm-spend", action="store_true", help="allow live requests within the ceiling")
        live.add_argument("--concurrency", type=int, default=4, help="concurrent provider requests (1-16)")
    for command in (run, interpret):
        command.add_argument("--expect-plan", help="refuse if the current request-plan SHA-256 differs")
    plan = store_command("plan", "calculate a request plan without sending or reserving anything")
    plan.add_argument("--bundle-key", required=True)
    plan.add_argument("--task", choices=("baseline", "interpretation"), default="baseline")
    plan.add_argument("--mode", choices=("reference", "recorded", "live"), default="live")
    plan.add_argument("--criterion", action="append")
    plan.add_argument("--retry", action="store_true")
    plan.add_argument("--experiment")
    plan.add_argument("--output", type=Path, help="write once to an owner-only file, otherwise print")
    status = store_command("status", "inspect a job and its items")
    status_target = status.add_mutually_exclusive_group()
    status_target.add_argument("--job")
    status_target.add_argument("--bundle-key", help="filter the recent job listing")
    cancel = store_command("cancel", "stop new dispatch for a job")
    cancel.add_argument("--job", required=True)
    proposals = store_command("proposals", "list interpretations for review and scoring")
    proposals.add_argument("--bundle-key", required=True)
    scenario = store_command("run-scenario", "recalculate a saved scenario against an immutable baseline")
    scenario.add_argument("--baseline", required=True)
    scenario.add_argument("--scenario", required=True)
    scenario.add_argument("--idempotency-key", required=True)
    export = store_command("export", "write a job's JSON report")
    export.add_argument("--job", required=True)
    export.add_argument("--output", type=Path, required=True)
    schema = commands.add_parser("openapi", help="write the API schema")
    schema.add_argument("--output", type=Path, required=True)
    return parser


def _print(document) -> None:
    print(json.dumps(document, indent=2, sort_keys=True))


def _write_new(path: Path, data: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as handle:
        handle.write(data)


def run(argv: Sequence[str]) -> int:
    args = _parser().parse_args(argv)
    try:
        from eligibility_lab.service import api, catalog, exports, interpretations, jobs, ledger, planning
        from eligibility_lab.service.catalog import AUDIENCES
        from eligibility_lab.service.errors import Refusal
        from eligibility_lab.service.store import Store, loads
    except ImportError as exc:
        print(f"The service needs the 'service' extra: pip install 'kitsa-eligibility-lab[service]' ({exc.name})",
              file=sys.stderr)
        return 2
    operator = api.OPERATOR
    try:
        if args.command == "openapi":
            import tempfile

            with tempfile.TemporaryDirectory() as scratch:
                app = api.create_app(Store.open(Path(scratch), create=True), port=8765)
                _write_new(args.output, json.dumps(app.openapi(), indent=2, sort_keys=True).encode() + b"\n")
            return 0
        store = Store.open(args.store, create=args.command == "init")
        if args.command == "init":
            _print({"store": str(store.root), "schema_version": store.schema_version()})
        elif args.command == "install-bundle":
            _print(catalog.install_bundle(store, args.bundle, audience=args.audience, operator=operator))
        elif args.command == "review":
            if args.bundle_key is not None and not args.all_reference:
                raise Refusal("invalid_review", "--bundle-key reviews every reference proposal; add --all-reference")
            if args.proposal is not None:
                targets = [args.proposal]
            else:
                catalog.load_installed(store, args.bundle_key, audiences=AUDIENCES)
                targets = [p["proposal_id"] for p in interpretations.list_proposals(store, args.bundle_key)
                           if p["origin"] == "reference"]
            _print([interpretations.review(store, proposal, args.decision, operator) for proposal in targets])
        elif args.command == "experiment":
            if args.action == "create":
                if args.ceiling_usd is None or args.max_requests is None:
                    raise Refusal("invalid_experiment", "create needs --ceiling-usd and --max-requests")
                _print(ledger.create_experiment(store, args.id, ceiling_usd=args.ceiling_usd,
                                                max_requests=args.max_requests, operator=operator))
            elif args.action == "show":
                _print(ledger.summary(store, args.id))
            else:
                _print(ledger.set_enabled(store, args.id, args.action == "enable"))
        elif args.command == "serve":
            return _serve(args, store)
        elif args.command in ("run-baseline", "interpret"):
            from eligibility_lab.service.worker import Worker

            if not 1 <= args.concurrency <= 16:
                raise Refusal("invalid_concurrency", "concurrency must be from 1 to 16")
            installed = catalog.load_installed(store, args.bundle_key, audiences=AUDIENCES)
            live = args.command == "interpret" or args.mode == "live"
            spend = {"experiment_id": args.experiment, "confirm_spend": args.confirm_spend} if live else {}
            if args.command == "interpret":
                request = {"kind": "interpretation", "bundle_key": installed.key, "retry": args.retry,
                           "criterion_ids": args.criterion or [c["criterion_id"] for c in
                                                               installed.documents["criteria"]["criteria"]], **spend}
            else:
                chosen = planning.choose_proposals(store, installed.key)
                request = {"kind": "baseline", "bundle_key": installed.key, "mode": args.mode,
                           "proposal_ids": chosen, **spend}
            if args.expect_plan is not None:
                planned = planning.plan(store, installed.key,
                                        task="interpretation" if args.command == "interpret" else "baseline",
                                        mode="live" if args.command == "interpret" else args.mode,
                                        proposal_ids=request.get("proposal_ids"),
                                        criterion_ids=request.get("criterion_ids"), retry=request.get("retry", False))
                if args.expect_plan != planned["plan_sha256"]:
                    raise Refusal("plan_changed", "inputs or configuration changed since planning; review a new plan")
            if live:
                _spend_permission(store, args)
            client = _live_client(args.experiment) if live else None
            try:
                job, _ = jobs.submit(store, request, args.idempotency_key, operator=operator, audiences=AUDIENCES,
                                     live_experiment=args.experiment if live else None,
                                     transport=None if client is None else client.transport_label)
                Worker(store, client=client, concurrency=args.concurrency).run_until_idle(job_id=job["job_id"])
            finally:
                if client is not None:
                    client.close()
            job = jobs.get(store, job["job_id"], audiences=AUDIENCES)
            _print(job)
            return 0 if job["state"] == "succeeded" else 1
        elif args.command == "plan":
            planned = planning.plan(store, args.bundle_key, task=args.task, mode=args.mode,
                                    criterion_ids=args.criterion, experiment_id=args.experiment, retry=args.retry)
            if args.output is not None:
                _write_new(args.output, json.dumps(planned, indent=2, sort_keys=True).encode() + b"\n")
            else:
                _print(planned)
        elif args.command == "proposals":
            catalog.load_installed(store, args.bundle_key, audiences=AUDIENCES)
            _print(interpretations.list_proposals(store, args.bundle_key))
        elif args.command == "status":
            if args.job is None:
                _print(jobs.list_jobs(store, args.bundle_key, audiences=AUDIENCES))
            else:
                job = jobs.get(store, args.job, audiences=AUDIENCES)
                with store.read() as connection:
                    items = [{**dict(row), "outcome": loads(row["outcome"])} for row in connection.execute(
                        "SELECT item_id, position, kind, item_key, state, outcome, current_attempt, retry_of, answer_attempt "
                        "FROM items WHERE job_id = ? ORDER BY position", (args.job,))]
                _print({"job": job, "items": items})
        elif args.command == "cancel":
            _print(jobs.cancel(store, args.job, audiences=AUDIENCES))
        elif args.command in ("resume", "retry", "run-scenario"):
            from eligibility_lab.service.worker import Worker

            if not 1 <= getattr(args, "concurrency", 4) <= 16:
                raise Refusal("invalid_concurrency", "concurrency must be from 1 to 16")
            previous = jobs.get(store, args.baseline if args.command == "run-scenario" else args.job,
                                audiences=AUDIENCES)
            live = previous["mode"] == "live" and args.command != "run-scenario"
            if live:
                _spend_permission(store, args, previous["experiment_id"])
            client = _live_client(args.experiment) if live else None
            try:
                transport = None if client is None else client.transport_label
                if args.command == "run-scenario":
                    job, _ = jobs.submit(store, {"kind": "scenario", "baseline_job_id": args.baseline,
                                                 "scenario_id": args.scenario}, args.idempotency_key,
                                         operator=operator, audiences=AUDIENCES)
                elif args.command == "resume":
                    job = jobs.resume(store, args.job, audiences=AUDIENCES, transport=transport)
                else:
                    job = jobs.retry(store, args.job, args.item, audiences=AUDIENCES, transport=transport)
                Worker(store, client=client, concurrency=getattr(args, "concurrency", 4)).run_until_idle(
                    job_id=job["job_id"])
            finally:
                if client is not None:
                    client.close()
            job = jobs.get(store, job["job_id"], audiences=AUDIENCES)
            _print(job)
            return 0 if job["state"] == "succeeded" else 1
        elif args.command == "export":
            report = exports.report(store, args.job, audiences=AUDIENCES)
            _write_new(args.output, json.dumps(report, indent=2, sort_keys=True).encode() + b"\n")
        return 0
    except Refusal as exc:
        print(f"Refused: {exc.code}: {exc.message}", file=sys.stderr)
        for problem in exc.problems:
            print(f"  {problem}", file=sys.stderr)
        return 2
    except FileExistsError as exc:
        print(f"Refused: output_exists: {exc.filename} already exists", file=sys.stderr)
        return 2


def _spend_permission(store, args: argparse.Namespace, expected: str | None = None) -> None:
    """Refuse before reopening a job or constructing a provider client."""
    from eligibility_lab.service import ledger
    from eligibility_lab.service.errors import Refusal

    if not args.confirm_spend:
        raise Refusal("spend_not_confirmed", "live work needs --confirm-spend")
    if expected is not None and args.experiment != expected:
        raise Refusal("experiment_mismatch", "name the experiment the job was created under")
    if not args.experiment:
        raise Refusal("live_mode_unavailable", "live work needs --experiment")
    if not ledger.summary(store, args.experiment)["enabled"]:
        raise Refusal("live_mode_unavailable", "the spending experiment is disabled")


def _live_client(experiment: str | None):
    """The genuine Meta Model API client, only with an experiment named and the key in the environment."""
    from eligibility_lab.service.errors import Refusal
    from eligibility_lab.service.provider import MuseClient

    key = os.environ.get("MODEL_API_KEY", "")
    if not experiment or not key:
        raise Refusal("live_mode_unavailable", "live work needs --experiment and MODEL_API_KEY")
    return MuseClient(key)


def _serve(args: argparse.Namespace, store) -> int:
    import uvicorn

    from eligibility_lab.service import api
    from eligibility_lab.service.errors import Refusal
    from eligibility_lab.service.worker import Worker

    for origin in args.allow_origin:
        if not DEV_ORIGIN.fullmatch(origin):
            raise Refusal("invalid_origin", "an allowed origin must be a loopback http origin")
    if args.assets is not None and not (args.assets / "index.html").is_file():
        raise Refusal("invalid_assets", "the assets folder has no index.html")
    client, live = None, None
    if args.enable_live:
        client, live = _live_client(args.experiment), args.experiment
        print(f"Live mode enabled for experiment {live}; requests spend within its ceiling.", file=sys.stderr)
    worker = Worker(store, client=client, concurrency=args.concurrency)
    app = api.create_app(store, port=args.port, worker=worker, assets=args.assets, extra_origins=args.allow_origin,
                         live_experiment=live)
    print(f"Eligibility Lab on http://{'[::1]' if args.host == '::1' else args.host}:{args.port}/", file=sys.stderr)
    uvicorn.run(app, host=args.host, port=args.port, log_level="info", server_header=False, proxy_headers=False)
    return 0


def main() -> None:
    sys.exit(run(sys.argv[1:]))


if __name__ == "__main__":
    main()
