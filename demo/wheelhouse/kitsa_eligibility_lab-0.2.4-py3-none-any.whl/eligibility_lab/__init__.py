"""Eligibility Lab calculation engine: reviewed criterion rules, deterministic evaluation of a cohort, patient
classification, waterfalls, criterion impact and scenario comparison. Standard library only; it opens no network
connection or database and needs no credentials."""

__version__ = "0.2.4"
