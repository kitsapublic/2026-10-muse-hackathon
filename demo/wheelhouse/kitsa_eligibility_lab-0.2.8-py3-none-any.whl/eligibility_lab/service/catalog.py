"""Installed bundles: verified copies of bundle folders, selected by identity and never by path.

`install_bundle` copies a bundle folder's `manifest.json` and the five inputs it names, and nothing else: expectation,
provenance and family files beside them are never installed, so they cannot reach a model request, the showcase or an
export. The copy is verified byte for byte and validated by the engine's `load_bundle` before it is registered with
its audience. HTTP requests see only `public` bundles; `private` bundles (the evaluation split) are reachable only
through the operator CLI. Installing also records the reference interpretation of every criterion as a proposal that
still needs local review.

The scenario policy of a bundle is the set of parameters its reference criteria mark editable, with their bounds;
every other parameter is protected whatever a proposal says.

A patient record is one patient of an installed bundle exactly as its cohort records them: typed evidence and dated
notes with their provenance, never a narrative decision or expectation.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import shutil
import stat
import tempfile
import threading
from types import MappingProxyType
from typing import Any, Mapping

from eligibility_lab.canonical import strict_loads
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import INPUTS, MAX_FILE_BYTES, Bundle, load_bundle
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.interpretations import record_reference_proposals
from eligibility_lab.service.store import Store, dumps, loads

AUDIENCES = ("public", "private")


@dataclass(frozen=True)
class Installed:
    key: str
    audience: str
    manifest_sha256: str
    documents: Mapping[str, Any]  # `manifest` and each input, parsed
    bundle: Bundle
    policy: Mapping[tuple[str, str], Mapping[str, Any]]  # (criterion, parameter) -> type and bounds


def bundle_key(bundle_id: str, bundle_version: str) -> str:
    if any(c in part for part in (bundle_id, bundle_version) for c in ("/", "\\", "\0")):
        raise Refusal("bundle_invalid", "bundle identity must not contain path separators or NUL")
    return f"{bundle_id}@{bundle_version}"


def scenario_policy(criteria_document: Mapping[str, Any]) -> dict[tuple[str, str], dict[str, Any]]:
    policy = {}
    for criterion in criteria_document["criteria"]:
        interpretation = criterion["interpretation"]
        for name, parameter in (interpretation.get("parameters") or {}).items():
            if parameter.get("editable") is True:
                policy[(criterion["criterion_id"], name)] = {"type": parameter["type"], "value": parameter["value"],
                                                             "minimum": parameter["minimum"],
                                                             "maximum": parameter["maximum"]}
    return policy


def _read(path: Path, limit: int) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    try:
        if not stat.S_ISREG(path.lstat().st_mode):
            raise Refusal("bundle_integrity", f"{path.name} must be a regular file")
        with os.fdopen(os.open(path, flags), "rb") as handle:
            data = handle.read(limit + 1)
    except OSError:
        raise Refusal("bundle_integrity", f"{path.name} is missing or unreadable") from None
    if len(data) > limit:
        raise Refusal("bundle_integrity", f"{path.name} exceeds the size limit")
    return data


def _documents(directory: Path) -> tuple[dict[str, Any], dict[str, bytes]]:
    manifest_bytes = _read(directory / "manifest.json", MAX_FILE_BYTES)
    try:
        manifest = strict_loads(manifest_bytes)
        files = {name: manifest["inputs"][name]["file"] for name in INPUTS}
    except (ValueError, KeyError, TypeError, UnicodeDecodeError):
        raise Refusal("bundle_invalid", "manifest.json does not name the five bundle inputs") from None
    contents = {"manifest.json": manifest_bytes}
    for name, filename in files.items():
        if not isinstance(filename, str) or "/" in filename or filename.startswith(".") or filename == "manifest.json":
            raise Refusal("bundle_invalid", f"manifest input {name} must be a plain file name")
        contents[filename] = _read(directory / filename, MAX_FILE_BYTES)
    return manifest, contents


def install_bundle(store: Store, source: Path, *, audience: str, operator: str) -> dict[str, Any]:
    """Install the bundle in `source`; reinstalling identical bytes is a no-op, different bytes are refused."""
    if audience not in AUDIENCES:
        raise Refusal("invalid_audience", "audience must be public or private")
    manifest, contents = _documents(Path(source))
    staging = Path(tempfile.mkdtemp(prefix=".install-", dir=store.root / "bundles"))
    try:
        for filename, data in contents.items():
            (staging / filename).write_bytes(data)
            os.chmod(staging / filename, 0o400)
        try:
            bundle = load_bundle(staging)
        except EligibilityError as exc:
            raise Refusal.from_engine(exc) from None
        key = bundle_key(bundle.bundle_id, bundle.bundle_version)
        manifest_sha256 = hashlib.sha256(contents["manifest.json"]).hexdigest()
        identities = {"protocol": bundle.protocol.digest, "criteria": bundle.criteria.digest,
                      "cohort": bundle.cohort.digest, "narrative": bundle.narrative.digest,
                      "patients": len(bundle.cohort.patients), "criteria_count": len(bundle.criteria.criteria),
                      "reference_date": bundle.reference_date.isoformat()}
        target = store.root / "bundles" / key
        with store.write() as connection:
            existing = connection.execute("SELECT manifest_sha256, audience FROM bundles WHERE bundle_key = ?",
                                          (key,)).fetchone()
            if existing is not None:
                if (existing["manifest_sha256"], existing["audience"]) != (manifest_sha256, audience):
                    raise Refusal("bundle_conflict", f"{key} is installed with different content or audience",
                                  status=409)
                return describe(connection, key)
            if target.is_symlink():
                raise Refusal("bundle_integrity", "an installed bundle directory must not be a symlink")
            if target.exists():  # An unregistered copy left by an interrupted install.
                os.chmod(target, 0o700)
                shutil.rmtree(target)
            os.rename(staging, target)
            os.chmod(target, 0o500)
            connection.execute("INSERT INTO bundles (bundle_key, bundle_id, bundle_version, audience, manifest_sha256,"
                               " identities, installed_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                               (key, bundle.bundle_id, bundle.bundle_version, audience, manifest_sha256,
                                dumps(identities), store.timestamp()))
            record_reference_proposals(connection, store, load_installed(store, key, connection))
            return describe(connection, key)
    finally:
        if staging.exists():
            os.chmod(staging, 0o700)
            shutil.rmtree(staging)


def describe(connection, key: str) -> dict[str, Any]:
    row = connection.execute("SELECT * FROM bundles WHERE bundle_key = ?", (key,)).fetchone()
    return {"bundle_key": row["bundle_key"], "bundle_id": row["bundle_id"], "bundle_version": row["bundle_version"],
            "audience": row["audience"], "manifest_sha256": row["manifest_sha256"],
            "identities": loads(row["identities"]), "installed_at": row["installed_at"]}


def list_bundles(store: Store, audiences: tuple[str, ...]) -> list[dict[str, Any]]:
    with store.read() as connection:
        keys = [row["bundle_key"] for row in connection.execute(
            f"SELECT bundle_key FROM bundles WHERE audience IN ({','.join('?' * len(audiences))}) "
            "ORDER BY bundle_key", audiences)]
        return [describe(connection, key) for key in keys]


def patient_record(installed: Installed, patient_id: str) -> dict[str, Any]:
    """One patient of `installed` as its cohort records them."""
    raw = next((p for p in installed.documents["cohort"]["patients"] if p["patient_id"] == patient_id), None)
    if raw is None:
        raise Refusal("patient_not_found", "the bundle has no patient with that identity", status=404)
    cohort = installed.bundle.cohort
    return {"bundle_key": installed.key, "patient_id": patient_id,
            "reference_date": installed.bundle.reference_date.isoformat(),
            "cohort": {"cohort_id": cohort.cohort_id, "version": cohort.version, "digest": cohort.digest},
            "patient_digest": next(p.digest for p in cohort.patients if p.patient_id == patient_id),
            "evidence": copy.deepcopy(raw["evidence"]), "notes": copy.deepcopy(raw["notes"])}


_cache: dict[tuple[str, str], Installed] = {}
_cache_lock = threading.Lock()


def load_installed(store: Store, key: str, connection=None, *, audiences: tuple[str, ...] = AUDIENCES) -> Installed:
    """The installed bundle `key`, verified again against its manifest when first loaded in this process."""
    if connection is None:
        with store.read() as reader:
            row = reader.execute("SELECT * FROM bundles WHERE bundle_key = ?", (key,)).fetchone()
    else:
        row = connection.execute("SELECT * FROM bundles WHERE bundle_key = ?", (key,)).fetchone()
    if row is None or row["audience"] not in audiences:
        raise Refusal("bundle_not_found", "no installed bundle has that identity", status=404)
    cache_key = (str(store.root), key)
    with _cache_lock:
        cached = _cache.get(cache_key)
    if cached is not None and cached.manifest_sha256 == row["manifest_sha256"]:
        return cached
    directory = store.root / "bundles" / key
    manifest, contents = _documents(directory)
    if hashlib.sha256(contents["manifest.json"]).hexdigest() != row["manifest_sha256"]:
        raise Refusal("bundle_integrity", f"the installed copy of {key} changed", status=500)
    try:
        bundle = load_bundle(directory)
    except EligibilityError as exc:
        raise Refusal("bundle_integrity", f"the installed copy of {key} no longer validates: {exc}",
                      status=500) from None
    documents = {"manifest": manifest, **{name: strict_loads(contents[manifest["inputs"][name]["file"]])
                                          for name in INPUTS}}
    installed = Installed(key, row["audience"], row["manifest_sha256"], MappingProxyType(documents), bundle,
                          MappingProxyType(scenario_policy(documents["criteria"])))
    with _cache_lock:
        _cache[cache_key] = installed
    return installed
