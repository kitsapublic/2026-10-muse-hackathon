"""Bounded public site evidence. This adapter never reads the patient store or calls a model."""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
import hashlib
import json
import re
import unicodedata
from typing import Any, Literal

import httpx
from pydantic import BaseModel, ConfigDict, Field

from eligibility_lab.service.errors import Refusal

POOL_ID = "global-nsclc-six-campuses/1"
MCP_URL = "https://mcp.kitsa.com/mcp"
REGISTRY_URL = "https://clinicaltrials.gov/api/v2/studies"
PROTOCOL = "2026-07-28"
MAX_PAGES = 40
PAGE_SIZE = 100
MAX_BODY = 12 * 1024 * 1024
# The sponsor preference is fixed to AstraZeneca in this policy version. The registry
# query is a superset of the conditions and lead-sponsor aliases scored by the UI.
STUDY_QUERY = 'AREA[ConditionSearch]("non-small cell" OR NSCLC OR "lung adenocarcinoma" OR "squamous cell lung") OR AREA[LeadSponsorName](AstraZeneca)'


class SitePin(BaseModel):
    model_config = ConfigDict(extra="forbid")
    site_id: str
    name: str
    city: str
    country: str
    country_code: str
    registry_query: str
    facility_aliases: list[str]
    city_aliases: list[str]
    country_aliases: list[str]
    campus_qualification: str = "Exact facility name and city aliases identify this campus; uncertain matches are excluded."


PINS = [
    SitePin(site_id="memorial-sloan-new-york-new-york-4a11e4", name="Memorial Sloan Kettering", city="New York", country="United States", country_code="USA", registry_query='"Memorial Sloan Kettering"', facility_aliases=["Memorial Sloan Kettering Cancer Center", "Memorial Sloan-Kettering Cancer Center", "Memorial Sloan Kettering Cancer Center New York - Main Hospital"], city_aliases=["New York", "New York City"], country_aliases=["United States", "United States of America"]),
    SitePin(site_id="royal-marsden-h-9ed2bda0", name="Royal Marsden Hospital", city="Sutton", country="United Kingdom", country_code="GBR", registry_query='"Royal Marsden"', facility_aliases=["Royal Marsden Hospital", "The Royal Marsden Hospital", "Royal Marsden Hospital - Sutton", "Royal Marsden NHS Foundation Trust", "The Royal Marsden NHS Foundation Trust"], city_aliases=["Sutton"], country_aliases=["United Kingdom", "United Kingdom of Great Britain and Northern Ireland"]),
    SitePin(site_id="tata-memorial-centre-tata-memo-mumbai-96662be5", name="Tata Memorial Hospital", city="Mumbai", country="India", country_code="IND", registry_query='"Tata Memorial"', facility_aliases=["Tata Memorial Hospital", "Tata Memorial Centre", "Tata Memorial Center"], city_aliases=["Mumbai", "Bombay"], country_aliases=["India"]),
    SitePin(site_id="gustave-roussy-67fbbbda", name="Gustave Roussy", city="Villejuif", country="France", country_code="FRA", registry_query='"Gustave Roussy"', facility_aliases=["Gustave Roussy", "Institut Gustave Roussy", "Institut Gustave-Roussy", "Gustave Roussy Cancer Campus", "Institut Gustave Roussy - IGR"], city_aliases=["Villejuif", "Villejuif Cedex"], country_aliases=["France"]),
    SitePin(site_id="national-cancer-982fd435", name="National Cancer Centre Singapore", city="Singapore", country="Singapore", country_code="SGP", registry_query='"National Cancer Centre" AND "Singapore"', facility_aliases=["National Cancer Centre Singapore", "National Cancer Center Singapore", "National Cancer Centre", "National Cancer Centre Singapore (NCCS)"], city_aliases=["Singapore"], country_aliases=["Singapore"]),
    SitePin(site_id="peter-maccallum-b28bc873", name="Peter MacCallum Cancer Centre", city="Melbourne", country="Australia", country_code="AUS", registry_query='"Peter MacCallum"', facility_aliases=["Peter MacCallum Cancer Centre", "Peter MacCallum Cancer Center", "Peter MacCallum Cancer Institute", "Peter Maccallum Cancer Centre"], city_aliases=["Melbourne", "Parkville"], country_aliases=["Australia"]),
]
PIN_BY_ID = {p.site_id: p for p in PINS}

# Reviewed names in the captured registry records. Matching still requires the
# pinned city and country; a study's own site number is not a different campus.
REGISTRY_ALIASES = {
    "GBR": ["Royal Marsden NHS Trust", "The Royal Marsden NHS Trust", "The Royal Marsden Hospital, Sutton", "Royal Marsden NHS Trust (Surrey)", "The Royal Marsden Hospital (Surrey)", "Royal Marsden Hospital - Sutton, Surrey", "Royal Marsden Hospital NHS Foundation Trust", "Royal Marsden - Surrey", "Royal Marsden NHS Foundation Trust - Surrey", "The Royal Marsden NHS Foundation Trust - Sutton", "The Royal Marsden in Sutton"],
    "FRA": ["Institute Gustave Roussy", "Villejuif - Institut Gustave Roussy", "Gustave Roussy Institute", "Villejuif - Gustave Roussy", "Gustave Roussy Cancer Campus Grand Paris", "Gustave Roussy Cancer Center", "Gustave Roussy Cancer Institute", "Institut de Cancerologie Gustave Roussy"],
    "IND": ["Tata Memorial Centre - Tata Memorial Hospital", "Tata Memorial Hospital, Parel", "Tata Memorial Hospital; Dept of Medical Oncology", "Tata Memorial Hospital-Medical Oncology"],
    "SGP": ["National Cancer Centre of Singapore", "National Cancer Centre of Singapore PTE LTD", "National Cancer Centre; Medical Oncology", "National Cancer Centre - Medical Oncology Pharmacy"],
    "AUS": ["Peter MacCallum Cancer Centre (PMCC)", "Peter Maccallum Cancer Institute; Medical Oncology", "Peter MacCallum Cancer Centre-Parkville Cancer Clinical Trials Unit (PCCTU)"],
    "USA": ["Memorial Sloan Kettering Cancer Center New York - Main Campus", "Memorial Sloan Kettering Cancer Center - Main Campus", "Memorial Sloan Kettering Cancer Center 1275 York Avenue"],
}
for _pin in PINS:
    _pin.facility_aliases.extend(REGISTRY_ALIASES[_pin.country_code])


class PublicSiteField(BaseModel):
    section: str
    id: str
    label: str
    value: Any = None
    source: str
    references: list[str] = Field(default_factory=list)
    qualification: str | None = None


class SiteStudy(BaseModel):
    trial_id: str
    title: str
    url: str
    conditions: list[str]
    study_type: str | None
    overall_status: str | None
    facility_status: str | None
    status_source: Literal["facility", "study_proxy", "unknown"]
    start_date: str | None
    completion_date: str | None
    updated_on: str | None
    lead_sponsor: str | None
    collaborators: list[str]
    minimum_age: str | None
    maximum_age: str | None
    matched_facilities: list[str]


class EvidenceExclusion(BaseModel):
    trial_id: str
    reason: Literal["ambiguous_facility", "other_campus", "invalid_record"]
    facilities: list[str]


class RegistryCoverage(BaseModel):
    query: str
    total_returned_by_registry: int | None
    records_read: int
    pages_read: int
    pagination_complete: bool
    matching_complete: bool
    truncated: bool
    exclusions: list[EvidenceExclusion]
    error: str | None = None


class SiteEvidence(BaseModel):
    pool_id: str
    pin: SitePin
    retrieved_at: str
    source_mode: Literal["live", "recorded"]
    profile_url: str
    profile_modified_at: str | None
    profile_fields: list[PublicSiteField]
    profile_error: str | None
    registry: RegistryCoverage
    studies: list[SiteStudy]
    sources: list[str]
    content_sha256: str


def normal(value: str) -> str:
    text = unicodedata.normalize("NFKD", value).casefold()
    return re.sub(r"[^a-z0-9]+", " ", "".join(c for c in text if not unicodedata.combining(c))).strip()


def safe_text(value: Any, size: int = 1000) -> str | None:
    return value[:size] if isinstance(value, str) and value.strip() else None


def facility_name(value: str) -> str:
    return normal(re.sub(r"\s*(?:\(\s*Site\s+\d+\s*\)|/ID#\s*\d+)\s*$", "", value, flags=re.I))


def project_study(raw: dict[str, Any], pin: SitePin) -> tuple[SiteStudy | None, EvidenceExclusion | None]:
    """Only exact, versioned campus aliases qualify. Broad search results never imply a facility match."""
    if not isinstance(raw, dict) or not isinstance(raw.get("protocolSection"), dict):
        return None, EvidenceExclusion(trial_id="unknown", reason="invalid_record", facilities=[])
    section = raw["protocolSection"]
    if any(not isinstance(value, dict) for value in section.values()):
        return None, EvidenceExclusion(trial_id="unknown", reason="invalid_record", facilities=[])
    identity = section.get("identificationModule", {})
    trial_id = identity.get("nctId", "")
    if not isinstance(trial_id, str) or not re.fullmatch(r"NCT\d{8}", trial_id):
        return None, EvidenceExclusion(trial_id="unknown", reason="invalid_record", facilities=[])
    locations = section.get("contactsLocationsModule", {}).get("locations", [])
    aliases = {normal(v) for v in pin.facility_aliases}
    cities, countries = {normal(v) for v in pin.city_aliases}, {normal(v) for v in pin.country_aliases}
    if not isinstance(locations, list):
        return None, EvidenceExclusion(trial_id=trial_id, reason="invalid_record", facilities=[])
    local = [loc for loc in locations if isinstance(loc, dict) and normal(str(loc.get("city", ""))) in cities and normal(str(loc.get("country", ""))) in countries]
    matches = [loc for loc in local if facility_name(str(loc.get("facility", ""))) in aliases]
    if not matches:
        return None, EvidenceExclusion(trial_id=trial_id, reason="ambiguous_facility" if local else "other_campus", facilities=[str(loc.get("facility", ""))[:250] for loc in local][:10])
    statuses = {loc.get("status") for loc in matches if loc.get("status")}
    status = section.get("statusModule", {})
    facility_status = next(iter(statuses)) if len(statuses) == 1 and all(loc.get("status") for loc in matches) else None
    status_source = "facility" if facility_status else "unknown" if statuses else "study_proxy" if status.get("overallStatus") else "unknown"
    sponsor = section.get("sponsorCollaboratorsModule", {})
    eligibility = section.get("eligibilityModule", {})
    def dated(key):
        value = status.get(key, {})
        return safe_text(value.get("date"), 10) if isinstance(value, dict) else None
    return SiteStudy(trial_id=trial_id, title=safe_text(identity.get("briefTitle")) or trial_id,
                     url=f"https://clinicaltrials.gov/study/{trial_id}", conditions=[str(v)[:300] for v in section.get("conditionsModule", {}).get("conditions", [])][:100],
                     study_type=safe_text(section.get("designModule", {}).get("studyType")), overall_status=safe_text(status.get("overallStatus")),
                     facility_status=facility_status, status_source=status_source, start_date=dated("startDateStruct"), completion_date=dated("completionDateStruct"),
                     updated_on=dated("lastUpdatePostDateStruct"), lead_sponsor=safe_text(sponsor.get("leadSponsor", {}).get("name")),
                     collaborators=[str(v.get("name", ""))[:300] for v in sponsor.get("collaborators", [])][:100],
                     minimum_age=safe_text(eligibility.get("minimumAge")), maximum_age=safe_text(eligibility.get("maximumAge")),
                     matched_facilities=sorted({str(v["facility"])[:250] for v in matches})), None


async def bounded_json(client: httpx.AsyncClient, method: str, url: str, **kwargs) -> dict[str, Any]:
    async with client.stream(method, url, **kwargs) as response:
        if response.status_code == 429:
            raise Refusal("site_rate_limited", "The public source has reached its request limit. Try again later.", status=429)
        response.raise_for_status()
        body = bytearray()
        async for chunk in response.aiter_bytes():
            body.extend(chunk)
            if len(body) > MAX_BODY:
                raise ValueError("public source exceeds its response bound")
        value = json.loads(body)
        if not isinstance(value, dict):
            raise ValueError("public source returned an invalid document")
        return value


async def fetch_profile(client: httpx.AsyncClient, site_id: str) -> dict[str, Any]:
    result = await bounded_json(client, "POST", MCP_URL, headers={"MCP-Protocol-Version": PROTOCOL, "Mcp-Method": "tools/call", "Mcp-Name": "get_clinical_research_site", "Accept": "application/json"},
        json={"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "get_clinical_research_site", "arguments": {"site_id": site_id}, "_meta": {"io.modelcontextprotocol/protocolVersion": PROTOCOL, "io.modelcontextprotocol/clientCapabilities": {}}}})
    result = result.get("result", {})
    if result.get("isError") or not result:
        raise ValueError("The Kitsa MCP source could not return this profile.")
    value = result.get("structuredContent")
    if value is None:
        value = json.loads(next(c["text"] for c in result.get("content", []) if c.get("type") == "text"))
    if not isinstance(value, dict) or value.get("site_id") != site_id:
        raise ValueError("The profile identity does not match the requested campus.")
    return value


async def fetch_evidence(site_id: str, *, client: httpx.AsyncClient | None = None) -> SiteEvidence:
    pin = PIN_BY_ID.get(site_id)
    if pin is None:
        raise Refusal("site_not_in_pool", "Choose a site from the fixed candidate pool.", status=404)
    if client is None:
        async with httpx.AsyncClient(timeout=20, follow_redirects=False, trust_env=False) as owned:
            return await fetch_evidence(site_id, client=owned)
    retrieved = datetime.now(timezone.utc).isoformat()
    profile_fields, profile_modified, profile_error = [], None, None
    try:
        profile = await fetch_profile(client, site_id)
        profile_modified = profile.get("last_modified")
        for section in profile.get("sections", []):
            for field in section.get("fields", []):
                profile_fields.append(PublicSiteField(section=str(section.get("label", ""))[:250], id=str(field.get("id", ""))[:150], label=str(field.get("label", ""))[:250],
                    value=field.get("value"), source=str(field.get("source_label", field.get("source", "unknown")))[:100],
                    references=[v for v in field.get("references") or [] if isinstance(v, str) and v.startswith("https://")][:30], qualification=safe_text(field.get("disclaimer"))))
    except (httpx.HTTPError, ValueError, TypeError, AttributeError, KeyError, StopIteration, Refusal):
        profile_error = "The Kitsa profile could not be refreshed. Its recorded version has not been replaced."
    studies, exclusions, seen, seen_pages, returned_ids = [], [], set(), set(), set()
    total, pages, records, complete, truncated, error = None, 0, 0, False, False, None
    params: dict[str, Any] = {"query.locn": pin.registry_query, "query.term": STUDY_QUERY, "format": "json", "pageSize": PAGE_SIZE, "countTotal": "true", "fields": "IdentificationModule,StatusModule,SponsorCollaboratorsModule,ConditionsModule,DesignModule,EligibilityModule,ContactsLocationsModule"}
    try:
        async with asyncio.timeout(100):
            for _ in range(MAX_PAGES):
                page = await bounded_json(client, "GET", REGISTRY_URL, params=params)
                if not isinstance(page.get("studies"), list):
                    raise ValueError("The registry returned no study list.")
                reported_total = page.get("totalCount", total)
                if reported_total is not None and (not isinstance(reported_total, int) or reported_total < 0):
                    raise ValueError("Invalid registry total")
                total = reported_total
                pages += 1
                for raw in page["studies"]:
                    records += 1
                    study, exclusion = project_study(raw, pin)
                    identity = study.trial_id if study else exclusion.trial_id if exclusion else "unknown"
                    if identity != "unknown":
                        returned_ids.add(identity)
                    if study and study.trial_id not in seen:
                        seen.add(study.trial_id); studies.append(study)
                    elif exclusion:
                        exclusions.append(exclusion)
                cursor = page.get("nextPageToken")
                if not cursor:
                    if total is not None and len(returned_ids) != total:
                        raise ValueError("The registry total does not match the distinct records retrieved.")
                    complete = True; break
                if not isinstance(cursor, str) or cursor in seen_pages or len(cursor) > 4096:
                    raise ValueError("The registry returned an invalid pagination cursor.")
                seen_pages.add(cursor); params["pageToken"] = cursor
            truncated = not complete
    except (httpx.HTTPError, ValueError, TypeError, AttributeError, KeyError, TimeoutError, Refusal):
        truncated = True
        error = "Registry retrieval was incomplete. Workload, experience and competition cannot be treated as complete counts."
    coverage = RegistryCoverage(query=pin.registry_query + " AND (" + STUDY_QUERY + ")", total_returned_by_registry=total, records_read=records, pages_read=pages,
        pagination_complete=complete, matching_complete=complete and not any(e.reason != "other_campus" for e in exclusions), truncated=truncated, exclusions=exclusions, error=error)
    result = SiteEvidence(pool_id=POOL_ID, pin=pin, retrieved_at=retrieved, source_mode="live", profile_url=f"https://kitsa.com/s/{site_id}",
        profile_modified_at=profile_modified, profile_fields=profile_fields, profile_error=profile_error, registry=coverage,
        studies=sorted(studies, key=lambda s: s.trial_id), sources=[MCP_URL, REGISTRY_URL], content_sha256="")
    result.content_sha256 = hashlib.sha256(json.dumps(result.model_dump(exclude={"content_sha256"}), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()
    return result
