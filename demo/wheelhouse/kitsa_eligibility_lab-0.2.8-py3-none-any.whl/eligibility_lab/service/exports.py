"""Results, comparisons and exports: the engine result of a job, a scenario against its baseline, the JSON report and
the CSV matrices.

A comparison is the engine's own `compare`, recalculated from the scenario job's pinned inputs (the interpretation set,
the baseline's narrative decisions, the evaluation date and the edits) on the evaluator the job pinned; it must
reproduce the run identities of both committed jobs, or it is refused rather than shown.

A report holds the job, its pinned configuration, its mode, the installed bundle's identities, the interpretation set
with each proposal's origin, interpretation and review, the engine result, the narrative decisions it used, its
lineage and its provider work and cost. The lineage names, for every work item (a scenario's are its baseline's), the
attempt whose answer it accepted: sent by the same job (`direct`), reused from another job (`cache`) or replayed from a
genuine recording (`replay`), with that attempt's job, transport, request, response and configuration digests and
charge. Costs keep the job's own requests apart from the source cost of reused answers, which stays with the job that
paid it. A source outside the reader's audiences is named only by its kind. Nothing with credentials, request headers
or expectation material is ever stored, so none can be exported. CSV cells are all quoted, and text that a
spreadsheet would read as a formula is prefixed with an apostrophe.

A trace shows one work item of a job (a scenario's are its baseline's): its bound input, the attempts it sent itself,
failed, late and retried ones included, and the attempt whose answer it accepted, wherever that was sent, each with the
retained request, the reply's final message content, the validation outcome, the validated answer, the model and
configuration identity, latency, usage and cost. An item of any other job is not found. An accepted answer whose source
is outside the reader's audiences is named only by its kind, and its attempt is withheld. Response headers and every
other part of a response body, such as any reasoning the provider returned, are never shown.
"""
from __future__ import annotations

import csv
from datetime import date
import hashlib
import io
from typing import Any, Iterable, Mapping, Sequence

from eligibility_lab.canonical import digest
from eligibility_lab.model import Edit, parse_bundle
from eligibility_lab.run import DEFAULT_WORKSPACE, compare
from eligibility_lab.service import configuration, jobs
from eligibility_lab.service.catalog import AUDIENCES, describe as describe_bundle, load_installed
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.interpretations import describe_proposal
from eligibility_lab.service.store import Store, loads

REPORT_FORMAT = "kitsa/eligibility-lab-service-report/2"
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


def _visible_job(connection, job_id: str, audiences: Sequence[str]):
    row = connection.execute("SELECT jobs.*, bundles.audience FROM jobs JOIN bundles USING (bundle_key) "
                             "WHERE job_id = ?", (job_id,)).fetchone()
    if row is None or row["audience"] not in audiences:
        raise Refusal("job_not_found", "no job has that identity", status=404)
    return row


def result(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    with store.read() as connection:
        row = _visible_job(connection, job_id, audiences)
        stored = connection.execute("SELECT document FROM results WHERE job_id = ?", (job_id,)).fetchone()
        if stored is None:
            raise Refusal("result_not_ready", f"the job has no result ({row['state']})", status=409)
        return {"job": jobs.describe(connection, row), "result": loads(stored["document"])}


def comparison(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    """The scenario job `job_id` against its baseline, recalculated by the engine from the pinned inputs."""
    with store.read() as connection:
        row = _visible_job(connection, job_id, audiences)
        if row["kind"] != "scenario":
            raise Refusal("not_a_scenario", "only a scenario job has a comparison", status=409)
        scenario = connection.execute("SELECT * FROM results WHERE job_id = ?", (job_id,)).fetchone()
        baseline = connection.execute("SELECT * FROM results WHERE job_id = ?", (row["baseline_job_id"],)).fetchone()
        if scenario is None or baseline is None:
            raise Refusal("result_not_ready", "the scenario and its baseline both need results", status=409)
        configuration.check(loads(row["configuration"]), "scenario", row["mode"], None)
        criteria = loads(connection.execute("SELECT criteria_document FROM interpretation_sets WHERE set_id = ?",
                                            (row["set_id"],)).fetchone()["criteria_document"])
        job = jobs.describe(connection, row)
    request = loads(row["request"])
    installed = load_installed(store, row["bundle_key"], audiences=AUDIENCES)
    bundle = parse_bundle(jobs.job_documents(installed, criteria, loads(scenario["narrative_document"])))
    evaluation_date = date.fromisoformat(request["evaluation_date"])
    if request["scenario_id"] is not None:
        document = compare(bundle, scenario=request["scenario_id"], evaluation_date=evaluation_date,
                           workspace=DEFAULT_WORKSPACE)
    else:
        document = compare(bundle, edits=[Edit(e["criterion_id"], e["parameter"], e["value"])
                                          for e in request["edits"]],
                           author=request["operator"], evaluation_date=evaluation_date, workspace=DEFAULT_WORKSPACE)
    if (document["baseline"]["run_id"], document["scenario"]["run_id"]) != (baseline["run_id"], scenario["run_id"]):
        raise Refusal("comparison_inconsistent", "the recalculated comparison does not reproduce the committed runs",
                      status=500)
    return {"job": job, "baseline_job_id": row["baseline_job_id"], "comparison": document}


def _lineage(connection, row, audiences: Sequence[str]) -> tuple[str, list[dict[str, Any]]]:
    """The job whose work items supplied this job's answers (a scenario's baseline, otherwise the job) and, per item,
    the attempt whose answer it accepted."""
    owner = row["baseline_job_id"] if row["kind"] == "scenario" else row["job_id"]
    entries = []
    for item in connection.execute(
            "SELECT items.*, attempts.job_id AS source_job, attempts.transport, attempts.request_sha256, "
            "attempts.response_body, attempts.configuration AS source_configuration, attempts.charged_microusd, "
            "bundles.audience, proposals.proposal_id FROM items "
            "LEFT JOIN attempts ON attempts.attempt_id = items.answer_attempt "
            "LEFT JOIN jobs ON jobs.job_id = attempts.job_id LEFT JOIN bundles ON bundles.bundle_key = jobs.bundle_key "
            "LEFT JOIN proposals ON proposals.attempt_id = items.answer_attempt "
            "WHERE items.job_id = ? ORDER BY items.position", (owner,)):
        source = None
        if item["answer_attempt"] is not None:
            kind = ("direct" if item["source_job"] == owner else "replay" if row["mode"] == "recorded" else "cache")
            source = {"kind": kind, "visible": item["audience"] in audiences}
            if source["visible"]:
                source.update(
                    job_id=item["source_job"], attempt_id=item["answer_attempt"], transport=item["transport"],
                    request_sha256=item["request_sha256"],
                    response_sha256=None if item["response_body"] is None
                    else hashlib.sha256(item["response_body"]).hexdigest(),
                    configuration_sha256=digest(loads(item["source_configuration"])),
                    charged_microusd=item["charged_microusd"], incurred_by_this_job=item["source_job"] == row["job_id"])
        entries.append({"item_id": item["item_id"], "item_key": item["item_key"], "kind": item["kind"],
                        "state": item["state"], "outcome": (loads(item["outcome"]) or {}).get("code"),
                        "decision_id": f"nd-{digest([owner, item['item_key']])[:24]}"
                        if item["kind"] == "narrative" and source is not None else None,
                        "proposal_id": item["proposal_id"] if item["kind"] == "interpretation" else None,
                        "source": source})
    return owner, entries


def _costs(attempts: Sequence[Mapping[str, Any]], lineage: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    reused = [entry["source"] for entry in lineage if entry["source"] is not None and entry["source"]["visible"]
              and not entry["source"]["incurred_by_this_job"]]
    distinct = {source["attempt_id"]: source for source in reused}
    return {"this_job": {"requests": sum(a["state"] != "not_sent" for a in attempts),
                         "settled_microusd": sum(a["charged_microusd"] or 0 for a in attempts
                                                 if a["reservation"] == "settled"),
                         "held_microusd": sum(a["reserved_microusd"] for a in attempts if a["reservation"] == "held")},
            "reused": {"answers": len(reused), "source_attempts": len(distinct),
                       "source_settled_microusd": sum(s["charged_microusd"] or 0 for s in distinct.values())}}


def report(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    with store.read() as connection:
        row = _visible_job(connection, job_id, audiences)
        job = jobs.describe(connection, row)
        lineage_job, lineage = _lineage(connection, row, audiences)
        accepted = {item["answer_attempt"] for item in connection.execute(
            "SELECT answer_attempt FROM items WHERE job_id = ?", (job_id,))}
        bundle = describe_bundle(connection, row["bundle_key"])
        stored = connection.execute("SELECT * FROM results WHERE job_id = ?", (job_id,)).fetchone()
        members = []
        if row["set_id"] is not None:
            set_row = connection.execute("SELECT members FROM interpretation_sets WHERE set_id = ?",
                                         (row["set_id"],)).fetchone()
            for member in loads(set_row["members"]):
                proposal = describe_proposal(connection, connection.execute(
                    "SELECT * FROM proposals WHERE proposal_id = ?", (member["proposal_id"],)).fetchone())
                members.append({"criterion_id": member["criterion_id"], "proposal_id": member["proposal_id"],
                                "origin": proposal["origin"], "interpreter": proposal["interpreter"],
                                "interpretation": proposal["interpretation"], "questions": proposal["questions"],
                                "approved_by_review": member["review_id"]})
        attempts = [{"attempt_id": a["attempt_id"], "item_id": a["item_id"], "retry_of": a["retry_of"],
                     "transport": a["transport"], "model": a["model"], "state": a["state"],
                     "outcome": loads(a["outcome"]), "accepted": a["attempt_id"] in accepted,
                     "late": bool((loads(a["outcome"]) or {}).get("late")), "http_status": a["http_status"],
                     "response_id": a["response_id"], "reserved_microusd": a["reserved_microusd"],
                     "charged_microusd": a["charged_microusd"], "reservation": a["reservation"],
                     "usage": loads(a["usage"]), "latency_ms": a["latency_ms"], "request_sha256": a["request_sha256"],
                     "configuration_sha256": digest(loads(a["configuration"]))}
                    for a in connection.execute("SELECT * FROM attempts WHERE job_id = ? ORDER BY dispatched_at, "
                                                "attempt_id", (job_id,))]
    narrative = None if stored is None else loads(stored["narrative_document"])
    return {"format": REPORT_FORMAT, "job": job, "configuration": loads(row["configuration"]),
            "configuration_sha256": job["configuration_sha256"],
            "mode": {"mode": job["mode"], "label": job["mode_label"]},
            "bundle": bundle, "interpretation_set": {"set_id": row["set_id"], "members": members},
            "narrative_source": None if narrative is None else narrative["source"],
            "narrative_decisions": None if narrative is None else narrative["decisions"],
            "lineage_job_id": lineage_job, "lineage": lineage, "provider_attempts": attempts,
            "costs": _costs(attempts, lineage),
            "result": None if stored is None else loads(stored["document"]),
            "metrics": None if stored is None else loads(stored["metrics"])}


def _final_content(body: bytes | None, status: int | None) -> dict[str, Any]:
    """The reply's final assistant message content, finish reason and reported model: nothing else of the body."""
    shown: dict[str, Any] = {"model": None, "finish_reason": None, "content": None}
    if body is None or status != 200:
        return shown
    try:
        envelope = loads(body.decode("utf-8"))  # Read as the provider adapter reads a response envelope.
    except (UnicodeDecodeError, ValueError, RecursionError):
        return shown
    if not isinstance(envelope, dict):
        return shown
    choices = envelope.get("choices")
    choice = choices[0] if isinstance(choices, list) and len(choices) == 1 and isinstance(choices[0], dict) else {}
    message = choice.get("message") if isinstance(choice.get("message"), dict) else {}
    return {"model": envelope["model"] if isinstance(envelope.get("model"), str) else None,
            "finish_reason": choice.get("finish_reason") if isinstance(choice.get("finish_reason"), str) else None,
            "content": message.get("content") if isinstance(message.get("content"), str) else None}


def _attempt_trace(attempt, job_id: str, accepted: str | None) -> dict[str, Any]:
    body = loads(attempt["request_body"].decode("utf-8"))
    outcome = loads(attempt["outcome"]) or {}
    response = attempt["response_body"]
    return {"attempt_id": attempt["attempt_id"], "job_id": attempt["job_id"], "retry_of": attempt["retry_of"],
            "generation": attempt["generation"], "state": attempt["state"],
            "validation": {"code": outcome.get("code"), "detail": outcome.get("detail"),
                           "late": outcome.get("late")} if outcome else None,
            "accepted": attempt["attempt_id"] == accepted, "transport": attempt["transport"],
            "provider": attempt["provider"], "model": attempt["model"],
            "configuration": loads(attempt["configuration"]),
            "configuration_sha256": digest(loads(attempt["configuration"])),
            "request": {"request_sha256": attempt["request_sha256"], "body_bytes": len(attempt["request_body"]),
                        "model": body["model"], "reasoning_effort": body["reasoning_effort"],
                        "max_tokens": body["max_tokens"], "store": body["store"], "messages": body["messages"],
                        "response_format": body["response_format"]},
            "response": None if attempt["http_status"] is None and response is None else {
                "http_status": attempt["http_status"], "response_id": attempt["response_id"],
                "response_sha256": None if response is None else hashlib.sha256(response).hexdigest(),
                **_final_content(response, attempt["http_status"])},
            "answer": loads(attempt["answer"]), "usage": loads(attempt["usage"]), "latency_ms": attempt["latency_ms"],
            "cost": {"reserved_microusd": attempt["reserved_microusd"], "charged_microusd": attempt["charged_microusd"],
                     "reservation": attempt["reservation"], "incurred_by_this_job": attempt["job_id"] == job_id},
            "dispatched_at": attempt["dispatched_at"], "completed_at": attempt["completed_at"]}


def trace(store: Store, job_id: str, item_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    """The trace of work item `item_id` of job `job_id`; a scenario's items are its baseline's."""
    with store.read() as connection:
        row = _visible_job(connection, job_id, audiences)
        owner = row["baseline_job_id"] if row["kind"] == "scenario" else row["job_id"]
        item = connection.execute("SELECT * FROM items WHERE item_id = ? AND job_id = ?", (item_id, owner)).fetchone()
        if item is None:
            raise Refusal("item_not_found", "the job has no work item with that identity", status=404)
        own = connection.execute("SELECT * FROM attempts WHERE item_id = ? AND job_id = ? ORDER BY dispatched_at, "
                                 "attempt_id", (item_id, owner)).fetchall()
        source_row = None if item["answer_attempt"] is None else connection.execute(
            "SELECT attempts.*, bundles.audience FROM attempts JOIN jobs ON jobs.job_id = attempts.job_id JOIN "
            "bundles ON bundles.bundle_key = jobs.bundle_key WHERE attempt_id = ?",
            (item["answer_attempt"],)).fetchone()
        proposal = None if item["kind"] != "interpretation" or item["answer_attempt"] is None else connection.execute(
            "SELECT proposal_id FROM proposals WHERE attempt_id = ?", (item["answer_attempt"],)).fetchone()
    visible = source_row is not None and source_row["audience"] in audiences
    accepted = item["answer_attempt"] if visible else None
    source = None
    if source_row is not None:
        kind = "direct" if source_row["job_id"] == owner else "replay" if row["mode"] == "recorded" else "cache"
        source = {"kind": kind, "visible": visible, "job_id": None, "attempt_id": None, "incurred_by_this_job": None}
        if visible:
            source.update(job_id=source_row["job_id"], attempt_id=source_row["attempt_id"],
                          incurred_by_this_job=source_row["job_id"] == row["job_id"])
    attempts = [_attempt_trace(a, row["job_id"], accepted) for a in own]
    outcome = loads(item["outcome"])
    if outcome is not None and not visible and item["answer_attempt"] is not None \
            and outcome.get("attempt_id") == item["answer_attempt"]:
        outcome.pop("attempt_id")
    spec = loads(item["input"])
    narrative = item["kind"] == "narrative"
    reason = None if attempts or visible else (
        "source_not_visible" if source_row is not None else (outcome or {}).get("code") or "not_sent")
    return {"job_id": row["job_id"], "job_kind": row["kind"], "job_mode": row["mode"], "lineage_job_id": owner,
            "job_configuration_sha256": None if row["configuration"] is None else digest(loads(row["configuration"])),
            "item": {"item_id": item["item_id"], "position": item["position"], "kind": item["kind"],
                     "item_key": item["item_key"], "state": item["state"], "outcome": outcome,
                     "retry_of": item["retry_of"], "answer_attempt": accepted},
            "narrative_input": spec if narrative else None, "interpretation_input": None if narrative else spec,
            "decision_id": (f"nd-{digest([owner, item['item_key']])[:24]}" if narrative and source is not None
                            else None),
            "proposal_id": None if proposal is None or not visible else proposal["proposal_id"],
            "available": reason is None, "unavailable_reason": reason, "answer_source": source,
            "answer_attempt": None if not visible else _attempt_trace(source_row, row["job_id"], accepted),
            "attempts": attempts}


def safe_cell(value: Any) -> str:
    text = "" if value is None else str(value)
    return f"'{text}" if text.startswith(FORMULA_PREFIXES) else text


def _csv(rows: Iterable[Iterable[Any]]) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer, quoting=csv.QUOTE_ALL, lineterminator="\r\n")
    for row in rows:
        writer.writerow([safe_cell(value) for value in row])
    return buffer.getvalue()


def matrix_csv(document: Mapping[str, Any]) -> str:
    """One row per patient; per criterion its value (or execution failure), reasons and cited evidence and notes."""
    criteria = [c["criterion_id"] for c in document["criteria"]]
    header = ["patient_id", "classification"]
    for criterion in criteria:
        header += [f"{criterion} value", f"{criterion} reasons", f"{criterion} applicability",
                   f"{criterion} evidence", f"{criterion} sources"]
    rows = [["run_id", document["run_id"]], ["scenario", document["run"]["scenario"]["scenario_id"],
                                             document["run"]["scenario"]["title"],
                                             document["run"]["scenario"]["author"]], header]
    for patient in document["patients"]:
        row = [patient["patient_id"], patient["classification"]]
        for criterion in criteria:
            cell = patient["cells"][criterion]
            row += [cell["value"] if cell["outcome"] == "decision" else "execution_failure",
                    ";".join(cell["reasons"] + cell["failures"]), cell["applicability"],
                    ";".join(cell["evidence"] + cell["narrative_decisions"]), ";".join(cell["sources"])]
        rows.append(row)
    return _csv(rows)


def comparison_csv(document: Mapping[str, Any]) -> str:
    rows = [["baseline_run_id", document["baseline"]["run_id"]], ["scenario_run_id", document["scenario"]["run_id"]],
            ["scenario", document["scenario"]["scenario_id"], document["scenario"]["title"],
             document["scenario"]["author"]],
            ["patient_id", "from", "to", "changed_criteria"]]
    for patient in document["changed_patients"]:
        rows.append([patient["patient_id"], patient["from"], patient["to"],
                     ";".join(f"{c['criterion_id']}:{c['from']}->{c['to']}" for c in patient["changed_criteria"])])
    return _csv(rows)
