"""Canonical JSON and SHA-256 identities that reproduce byte for byte, and the checks applied to JSON a model wrote.

Floats are refused in both directions: decimal values travel as strings, so every producer encodes them identically.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Mapping

MAX_JSON_DEPTH = 64


def _check(value: Any) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("canonical JSON keys must be strings")
            _check(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _check(item)
    elif value is not None and not isinstance(value, (str, int, bool)):
        raise TypeError(f"canonical JSON cannot encode {type(value).__name__}")


def canonical_json(value: Any) -> bytes:
    _check(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def strict_loads(data: bytes) -> Any:
    """UTF-8 JSON without duplicate keys, floats or non-finite numbers."""
    def pairs(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = item
        return result

    def refuse(text):
        raise ValueError("JSON numbers must be integers; decimals are strings")

    return json.loads(data.decode("utf-8"), object_pairs_hook=pairs, parse_float=refuse, parse_constant=refuse)


def well_formed(value: Any, depth: int = 0) -> bool:
    """Nested at most MAX_JSON_DEPTH levels, with text that can be stored (no lone surrogates)."""
    if depth > MAX_JSON_DEPTH:
        return False
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeEncodeError:
            return False
        return True
    if isinstance(value, dict):
        return all(well_formed(k, depth + 1) and well_formed(v, depth + 1) for k, v in value.items())
    if isinstance(value, list):
        return all(well_formed(item, depth + 1) for item in value)
    return True


def schema_problems(value: Any, schema: Mapping[str, Any], path: str = "$") -> list[str]:
    """The closed subset of JSON Schema sent to models: object, array, string with optional enum."""
    kind = schema["type"]
    if kind == "object":
        if not isinstance(value, dict):
            return [f"{path}: must be an object"]
        problems = [f"{path}: missing {key}" for key in schema["required"] if key not in value]
        problems += [f"{path}: unexpected {key}" for key in value if key not in schema["properties"]]
        for key, item in value.items():
            if key in schema["properties"]:
                problems += schema_problems(item, schema["properties"][key], f"{path}.{key}")
        return problems
    if kind == "array":
        if not isinstance(value, list):
            return [f"{path}: must be an array"]
        return [problem for i, item in enumerate(value) for problem in schema_problems(item, schema["items"],
                                                                                      f"{path}[{i}]")]
    if not isinstance(value, str):
        return [f"{path}: must be a string"]
    if "enum" in schema and value not in schema["enum"]:
        return [f"{path}: unexpected value"]
    return []
