"""Narrative inputs and the narrative question contract.

A narrative leaf reads the patient's notes written inside its window: on or before the evaluation date and no earlier
than `window_days` before it. With no such note the leaf is insufficient evidence and needs no decision. Otherwise
the decision must consider exactly those notes and carry their `input_sha256` (`model.narrative_binding`), so any
change to the patient, question statement, date, window or a considered note's content leaves it stale.

The question contract is what any model answering a narrative input is given and held to, whichever provider serves
it: the instructions, the user content (the statement, the evaluation date, the window and every note inside it), the
closed answer schema whose citations may name only the notes supplied, and the local validation of the reply. A reply
is accepted only as strict JSON nested at most `MAX_JSON_DEPTH` levels, matching the schema, citing distinct supplied
notes, citing at least one for a decided answer and giving a reason consistent with its answer. The binding of an
accepted answer to its inputs is computed from the notes supplied, never taken from the reply.

`inputs_document` is the no-spend export of every input of a bundle under this contract, holding no narrative decision
of the bundle (its expected answers). `answers_document` validates the final replies a caller collected for those
inputs, one per input at most, and builds the model narrative source of the accepted ones; an input without an
accepted reply has no decision, so its cells are execution failures, never clinical answers.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
import json
from typing import Any, Sequence

from eligibility_lab.canonical import MAX_JSON_DEPTH, canonical_json, digest, schema_problems, strict_loads, well_formed
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import FORMATS, SHA256, Bundle, Cohort, CriterionSet, Note, Patient, narrative_binding
from eligibility_lab.rules import narratives_of

INSTRUCTIONS = """You decide one eligibility question about one synthetic patient, using only the clinical notes \
supplied.
Answer "yes" when the notes establish that the statement is true on the evaluation date, "no" when they establish \
that it is false, and "undetermined" otherwise.
A condition is absent only when a note states that it is absent; a note that does not mention a condition \
establishes nothing about it.
When the notes disagree and the most recent notes do not resolve the disagreement, answer "undetermined" with \
reason "conflicting_evidence".
When the notes do not address the statement, answer "undetermined" with reason "insufficient_evidence".
When you cannot decide for any other reason, answer "undetermined" with reason "cannot_determine".
For "yes" or "no", give reason "established" and cite every supporting note by its note_id.
Cite only note_ids of the notes supplied. Reply with JSON that matches the schema and nothing else."""

USER_FORMAT = "narrative/1"
ANSWER_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["answer", "reason", "supporting_note_ids"],
    "properties": {
        "answer": {"type": "string", "enum": ["yes", "no", "undetermined"]},
        "reason": {"type": "string",
                   "enum": ["established", "insufficient_evidence", "conflicting_evidence", "cannot_determine"]},
        "supporting_note_ids": {"type": "array", "items": {"type": "string", "enum": ["<supplied note ids>"]}}}}
# An undetermined reply's reason, as the decision records it.
MODEL_REASONS = {"insufficient_evidence": "insufficient_evidence", "conflicting_evidence": "conflicting_evidence",
                 "cannot_determine": "model_abstention"}
INPUTS_FORMAT = "kitsa/eligibility-lab-narrative-inputs/1"
OUTPUTS_FORMAT = "kitsa/eligibility-lab-narrative-outputs/1"
ANSWERS_FORMAT = "kitsa/eligibility-lab-narrative-answers/1"
OUTCOMES = ("answered", "no_output", "malformed_json", "schema_violation", "citation_invalid", "inconsistent_answer")
MAX_OUTPUT_CHARACTERS = 256 * 1024


@dataclass(frozen=True)
class NarrativeInput:
    patient_id: str
    question_id: str
    statement: str
    evaluation_date: date
    window_days: int
    notes: tuple[Note, ...]  # sorted by note_id
    input_sha256: str


def notes_in_window(patient: Patient, evaluation_date: date, window_days: int) -> tuple[Note, ...]:
    first = evaluation_date - timedelta(days=window_days)
    return tuple(sorted((note for note in patient.notes if first <= note.written_on <= evaluation_date),
                        key=lambda note: note.note_id))


def narrative_inputs(criteria: CriterionSet, cohort: Cohort, evaluation_date: date) -> tuple[NarrativeInput, ...]:
    """Every patient, question and window the criteria read that has notes to decide on, sorted by patient,
    question and window."""
    leaves = sorted({(leaf.question, leaf.window_days) for criterion in criteria.criteria
                     for leaf in narratives_of(criterion.interpretation)})
    inputs = []
    for patient in sorted(cohort.patients, key=lambda p: p.patient_id):
        for question, window in leaves:
            notes = notes_in_window(patient, evaluation_date, window)
            if notes:
                statement = criteria.questions[question]
                inputs.append(NarrativeInput(patient.patient_id, question, statement, evaluation_date, window, notes,
                                             narrative_binding(patient.patient_id, question, statement,
                                                               evaluation_date, window, notes)))
    return tuple(inputs)


def user_content(statement: str, evaluation_date: str, first_day: str, notes: Sequence[dict[str, str]]) -> str:
    """The user message: `notes` are the complete notes inside the window, each a note_id, written_on and text."""
    return canonical_json({"statement": statement, "evaluation_date": evaluation_date,
                           "notes_written_from": first_day, "notes_written_to": evaluation_date,
                           "notes": [{"note_id": n["note_id"], "written_on": n["written_on"], "text": n["text"]}
                                     for n in notes]}).decode("utf-8")


def input_content(item: NarrativeInput) -> str:
    return user_content(item.statement, item.evaluation_date.isoformat(),
                        (item.evaluation_date - timedelta(days=item.window_days)).isoformat(),
                        [{"note_id": n.note_id, "written_on": n.written_on.isoformat(), "text": n.text}
                         for n in item.notes])


def answer_schema(note_ids: Sequence[str]) -> dict[str, Any]:
    """The answer schema whose citations may name only `note_ids`, the notes supplied."""
    schema = json.loads(json.dumps(ANSWER_SCHEMA))
    schema["properties"]["supporting_note_ids"]["items"]["enum"] = list(note_ids)
    return schema


def read_answer(text: str, note_ids: Sequence[str]) -> tuple[str, str, dict[str, Any] | None]:
    """A reply's outcome code, detail and, when `answered`, the decision's value, reason and supporting notes."""
    try:
        content = strict_loads(text.encode("utf-8"))
    except (ValueError, RecursionError, UnicodeEncodeError):
        return "malformed_json", "the content is not strict JSON", None
    if not well_formed(content):
        return "malformed_json", f"the content is nested more than {MAX_JSON_DEPTH} levels", None
    schema = json.loads(json.dumps(ANSWER_SCHEMA))
    schema["properties"]["supporting_note_ids"]["items"].pop("enum")
    problems = schema_problems(content, schema)
    if problems:
        return "schema_violation", "; ".join(problems)[:300], None
    cited = content["supporting_note_ids"]
    if len(set(cited)) != len(cited) or not set(cited) <= set(note_ids):
        return "citation_invalid", "citations must name distinct supplied notes", None
    answer, reason = content["answer"], content["reason"]
    if answer in ("yes", "no"):
        if reason != "established":
            return "inconsistent_answer", "a decided answer gives reason established", None
        if not cited:
            return "citation_invalid", "a decided answer cites at least one supporting note", None
        return "answered", "", {"value": answer, "reason": None, "supporting_note_ids": sorted(cited)}
    if reason == "established":
        return "inconsistent_answer", "an undetermined answer gives why", None
    return "answered", "", {"value": "undetermined", "reason": MODEL_REASONS[reason],
                            "supporting_note_ids": sorted(cited)}


def contract_identity() -> dict[str, str]:
    """The prompt and schema identities a provider configuration pins for this contract."""
    return {"prompt": digest({"system": INSTRUCTIONS, "user_format": USER_FORMAT}), "schema": digest(ANSWER_SCHEMA)}


def _identity(bundle: Bundle, manifest_sha256: str, evaluation_date: date) -> dict[str, Any]:
    return {"bundle": {"bundle_id": bundle.bundle_id, "bundle_version": bundle.bundle_version,
                       "manifest_sha256": manifest_sha256, "protocol": bundle.protocol.digest,
                       "criteria": bundle.criteria.digest, "cohort": bundle.cohort.digest},
            "evaluation_date": evaluation_date.isoformat(), "contract": contract_identity()}


def inputs_document(bundle: Bundle, manifest_sha256: str, evaluation_date: date) -> dict[str, Any]:
    """Every narrative input of `bundle` on `evaluation_date` as this contract presents it to a model."""
    identity = _identity(bundle, manifest_sha256, evaluation_date)
    return {"format": INPUTS_FORMAT, **identity,
            "contract": {**identity["contract"], "instructions": INSTRUCTIONS, "user_format": USER_FORMAT},
            "inputs": [{"input_sha256": item.input_sha256, "patient_id": item.patient_id,
                        "question_id": item.question_id, "window_days": item.window_days,
                        "note_ids": [note.note_id for note in item.notes], "user_content": input_content(item),
                        "response_schema": answer_schema([note.note_id for note in item.notes])}
                       for item in narrative_inputs(bundle.criteria, bundle.cohort, evaluation_date)]}


def _replies(raw: Any, known: set[str]) -> dict[str, str]:
    """The final reply text per input of a `kitsa/eligibility-lab-narrative-outputs/1` document."""
    def refuse(message: str) -> None:
        raise EligibilityError("invalid_outputs", message)

    if not isinstance(raw, dict) or set(raw) != {"format", "outputs"} or raw["format"] != OUTPUTS_FORMAT:
        refuse(f"the outputs must be a {OUTPUTS_FORMAT} document with exactly format and outputs")
    if not isinstance(raw["outputs"], list):
        refuse("outputs must be a list")
    replies: dict[str, str] = {}
    for index, entry in enumerate(raw["outputs"]):
        if not isinstance(entry, dict) or set(entry) != {"input_sha256", "text"}:
            refuse(f"outputs[{index}] has exactly input_sha256 and text")
        key, text = entry["input_sha256"], entry["text"]
        if not isinstance(key, str) or not SHA256.fullmatch(key) or key not in known:
            refuse(f"outputs[{index}] names no narrative input of this bundle and date")
        if key in replies:
            refuse(f"outputs[{index}] repeats an input; give at most one final reply per input")
        if not isinstance(text, str) or len(text) > MAX_OUTPUT_CHARACTERS:
            refuse(f"outputs[{index}].text must be text of at most {MAX_OUTPUT_CHARACTERS} characters")
        replies[key] = text
    return replies


def answers_document(bundle: Bundle, manifest_sha256: str, evaluation_date: date, outputs: Any,
                     outputs_sha256: str, description: str) -> dict[str, Any]:
    """Each input's outcome under this contract, and the model narrative source of the accepted replies."""
    if not isinstance(description, str) or not description.strip() or len(description) > 1000:
        raise EligibilityError("invalid_outputs", "the description is non-empty text of at most 1000 characters")
    inputs = narrative_inputs(bundle.criteria, bundle.cohort, evaluation_date)
    replies = _replies(outputs, {item.input_sha256 for item in inputs})
    outcomes, decisions = [], []
    for item in inputs:
        note_ids = [note.note_id for note in item.notes]
        text = replies.get(item.input_sha256)
        code, detail, answer = ("no_output", "no final reply was supplied", None) if text is None \
            else read_answer(text, note_ids)
        outcomes.append({"input_sha256": item.input_sha256, "patient_id": item.patient_id,
                         "question_id": item.question_id, "window_days": item.window_days, "outcome": code,
                         "detail": detail})
        if answer is not None:
            decisions.append({"decision_id": f"nd-{digest([outputs_sha256, item.input_sha256])[:24]}",
                              "patient_id": item.patient_id, "question_id": item.question_id,
                              "evaluation_date": item.evaluation_date.isoformat(), "window_days": item.window_days,
                              "considered_note_ids": note_ids, "value": answer["value"], "reason": answer["reason"],
                              "supporting_note_ids": answer["supporting_note_ids"], "input_sha256": item.input_sha256})
    counts = {code: sum(o["outcome"] == code for o in outcomes) for code in OUTCOMES}
    return {"format": ANSWERS_FORMAT, **_identity(bundle, manifest_sha256, evaluation_date),
            "outputs_sha256": outputs_sha256, "counts": {"inputs": len(inputs), **counts}, "outcomes": outcomes,
            "narrative": {"format": FORMATS["narrative"], "source": {"kind": "model", "description": description},
                          "decisions": decisions}}
