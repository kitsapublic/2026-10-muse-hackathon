"""Versioned bundles: protocol, reviewed criteria, cohort evidence, narrative decisions and saved scenarios.

`load_bundle` reads a bundle folder: `manifest.json` names each input file with its SHA-256 and size, and every
input must match byte for byte. Files are bounded regular files, never symlinks, holding strict JSON (no duplicate
keys or floats). `parse_bundle` validates the documents themselves; every object has a closed set of fields.

Identities are content digests independent of input order: patients, evidence, notes and narrative decisions are
digested sorted by identifier. A criterion's rule digest covers its category, effective interpretation and the
statements of the narrative questions it reads, which is everything that can change its decisions. All objects are
immutable; `CriterionSet.apply` returns a new set and leaves the baseline unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import date
from decimal import Decimal
import hashlib
import os
from pathlib import Path
import re
import stat
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from eligibility_lab.canonical import canonical_json, digest, strict_loads
from eligibility_lab.errors import EligibilityError
from eligibility_lab.rules import (Executable, Interpretation, edit_value, interpretation_json, parse_interpretation,
                                   questions_of, with_value)
from eligibility_lab.vocabulary import CONCEPTS, DECIMAL

FORMATS = {"manifest": "kitsa/eligibility-lab-bundle/1", "protocol": "kitsa/eligibility-lab-protocol/1",
           "criteria": "kitsa/eligibility-lab-criteria/1", "cohort": "kitsa/eligibility-lab-cohort/1",
           "narrative": "kitsa/eligibility-lab-narrative/2", "scenarios": "kitsa/eligibility-lab-scenarios/1"}
INPUTS = ("protocol", "criteria", "cohort", "narrative", "scenarios")
MAX_FILE_BYTES = 64 * 1024 * 1024
MAX_TEXT = 20_000
IDENTIFIER = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}")
ISO_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
FILENAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\.json")
SHA256 = re.compile(r"[0-9a-f]{64}")
NARRATIVE_REASONS = ("insufficient_evidence", "conflicting_evidence", "model_abstention")
BINDING_FORMAT = "kitsa/eligibility-lab-narrative-binding/1"
BASELINE = "baseline"


@dataclass(frozen=True)
class Passage:
    anchor: str
    heading: str | None
    text: str


@dataclass(frozen=True)
class Protocol:
    protocol_id: str
    version: str
    title: str
    passages: tuple[Passage, ...]
    digest: str


@dataclass(frozen=True)
class Criterion:
    criterion_id: str
    category: str  # inclusion | exclusion
    text: str
    anchor: str
    review_state: str  # approved | pending | rejected
    interpretation: Interpretation
    questions: Mapping[str, str]  # the statements of the narrative questions the rule reads
    rule_digest: str


@dataclass(frozen=True)
class Edit:
    criterion_id: str
    parameter: str
    value: Any


@dataclass(frozen=True)
class CriterionSet:
    criterion_set_id: str
    version: str
    protocol_id: str
    protocol_version: str
    interpreter: Mapping[str, str]
    questions: Mapping[str, str]
    criteria: tuple[Criterion, ...]
    digest: str

    def criterion(self, criterion_id: str) -> Criterion:
        for criterion in self.criteria:
            if criterion.criterion_id == criterion_id:
                return criterion
        raise KeyError(criterion_id)

    def apply(self, edits: Sequence[Edit]) -> "CriterionSet":
        """A new criterion set with the edited parameter values; the receiver is unchanged."""
        if not edits:
            raise EligibilityError("invalid_scenario", "a scenario changes at least one parameter")
        seen = set()
        updated = {criterion.criterion_id: criterion for criterion in self.criteria}
        for edit in edits:
            path = f"{edit.criterion_id}.{edit.parameter}"[:200]
            if not isinstance(edit.criterion_id, str) or not isinstance(edit.parameter, str):
                raise EligibilityError("unknown_parameter", f"{path} is not a parameter of this criterion set")
            if (edit.criterion_id, edit.parameter) in seen:
                raise EligibilityError("duplicate_edit", f"{path} is edited more than once")
            seen.add((edit.criterion_id, edit.parameter))
            criterion = updated.get(edit.criterion_id)
            interpretation = criterion.interpretation if criterion is not None else None
            if not isinstance(interpretation, Executable) or edit.parameter not in interpretation.parameters:
                raise EligibilityError("unknown_parameter", f"{path} is not a parameter of this criterion set")
            parameter = interpretation.parameters[edit.parameter]
            if not parameter.editable:
                raise EligibilityError("protected_parameter", f"{path} is protected and cannot be edited")
            changed = with_value(interpretation, edit.parameter, edit_value(parameter, edit.value, path))
            updated[edit.criterion_id] = _criterion(criterion.criterion_id, criterion.category, criterion.text,
                                                    criterion.anchor, criterion.review_state, changed,
                                                    criterion.questions)
        return _criterion_set(self.criterion_set_id, self.version, self.protocol_id, self.protocol_version,
                              self.interpreter, self.questions,
                              tuple(updated[c.criterion_id] for c in self.criteria))


@dataclass(frozen=True)
class Quantity:
    amount: Decimal
    unit: str | None


@dataclass(frozen=True)
class Regimen:
    regimen_id: str
    state: str  # ongoing | completed
    start_on: date
    last_dose_on: date | None


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    concept: str
    observed_on: date
    encounter_id: str | None
    status: str  # final | entered_in_error
    value: Any  # date, str, bool (assertion present), int, Quantity or Regimen by concept kind
    origin: str


@dataclass(frozen=True)
class Note:
    note_id: str
    written_on: date
    encounter_id: str | None
    text: str
    origin: str


@dataclass(frozen=True)
class Patient:
    patient_id: str
    evidence: tuple[Evidence, ...]
    notes: tuple[Note, ...]
    digest: str


@dataclass(frozen=True)
class Cohort:
    cohort_id: str
    version: str
    patients: tuple[Patient, ...]
    digest: str


@dataclass(frozen=True)
class NarrativeDecision:
    decision_id: str
    patient_id: str
    question_id: str
    evaluation_date: date
    window_days: int
    considered: frozenset[str]
    value: str  # yes | no | undetermined
    reason: str | None
    supporting: tuple[str, ...]
    input_sha256: str
    input_matches: bool  # Checked against the bundled note content and question, not just their identifiers.


@dataclass(frozen=True)
class NarrativeSource:
    kind: str  # reference | model
    description: str
    decisions: Mapping[tuple[str, str, date, int], NarrativeDecision]
    patient_digests: Mapping[str, str]
    digest: str

    def lookup(self, patient_id: str, question_id: str, evaluation_date: date,
               window_days: int) -> NarrativeDecision | None:
        return self.decisions.get((patient_id, question_id, evaluation_date, window_days))


@dataclass(frozen=True)
class Scenario:
    scenario_id: str
    title: str
    author: str
    edits: tuple[Edit, ...]


@dataclass(frozen=True)
class Bundle:
    bundle_id: str
    bundle_version: str
    reference_date: date
    protocol: Protocol
    criteria: CriterionSet
    cohort: Cohort
    narrative: NarrativeSource
    scenarios: tuple[Scenario, ...]

    def scenario(self, scenario_id: str) -> Scenario:
        for scenario in self.scenarios:
            if scenario.scenario_id == scenario_id:
                return scenario
        raise EligibilityError("unknown_scenario", f"the bundle has no saved scenario {scenario_id!r}"[:200])


def note_json(note: Note) -> dict[str, Any]:
    """A note exactly as the cohort records it."""
    return {"note_id": note.note_id, "written_on": note.written_on.isoformat(), "encounter_id": note.encounter_id,
            "text": note.text, "provenance": {"source_kind": "note", "origin": note.origin}}


def narrative_binding(patient_id: str, question_id: str, statement: str | None, evaluation_date: date,
                      window_days: int, notes: Iterable[Note]) -> str:
    """The `input_sha256` a narrative decision must carry: the digest of its patient, exact question, evaluation date,
    window and complete considered notes."""
    return digest({"format": BINDING_FORMAT, "patient_id": patient_id,
                   "question": {"question_id": question_id, "statement": statement},
                   "evaluation_date": evaluation_date.isoformat(), "window_days": window_days,
                   "notes": [note_json(note) for note in sorted(notes, key=lambda n: n.note_id)]})


def _criterion(criterion_id: str, category: str, text: str, anchor: str, review_state: str,
               interpretation: Interpretation, questions: Mapping[str, str]) -> Criterion:
    rule_digest = digest({"category": category, "interpretation": interpretation_json(interpretation),
                          "questions": dict(questions)})
    return Criterion(criterion_id, category, text, anchor, review_state, interpretation,
                     MappingProxyType(dict(questions)), rule_digest)


def _criterion_set(criterion_set_id: str, version: str, protocol_id: str, protocol_version: str,
                   interpreter: Mapping[str, str], questions: Mapping[str, str],
                   criteria: tuple[Criterion, ...]) -> CriterionSet:
    identity = digest({"criterion_set_id": criterion_set_id, "version": version,
                       "protocol": [protocol_id, protocol_version], "interpreter": dict(interpreter),
                       "questions": dict(questions),
                       "criteria": [{"criterion_id": c.criterion_id, "text": c.text, "anchor": c.anchor,
                                     "review_state": c.review_state, "rule_digest": c.rule_digest}
                                    for c in sorted(criteria, key=lambda c: c.criterion_id)]})
    return CriterionSet(criterion_set_id, version, protocol_id, protocol_version, MappingProxyType(dict(interpreter)),
                        MappingProxyType(dict(questions)), criteria, identity)


class _Check:
    def __init__(self):
        self.problems: list[str] = []

    def add(self, path: str, message: str) -> None:
        self.problems.append(f"{path}: {message}")

    def fields(self, raw: Any, path: str, required: Iterable[str]) -> dict[str, Any] | None:
        required = tuple(required)
        if not isinstance(raw, dict):
            self.add(path, "must be an object")
            return None
        for key in required:
            if key not in raw:
                self.add(path, f"missing field {key}")
        for key in raw:
            if key not in required:
                self.add(path, f"unexpected field {key}")
        return raw if all(key in raw for key in required) else None

    def text(self, raw: Any, path: str, *, limit: int = 500, nullable: bool = False) -> str | None:
        if raw is None and nullable:
            return None
        if not isinstance(raw, str) or not raw.strip() or len(raw) > limit:
            self.add(path, f"must be non-empty text of at most {limit} characters")
            return ""
        return raw

    def identifier(self, raw: Any, path: str, *, nullable: bool = False) -> str | None:
        if raw is None and nullable:
            return None
        if not isinstance(raw, str) or not IDENTIFIER.fullmatch(raw):
            self.add(path, "must be an identifier of letters, digits and . _ : -")
            return ""
        return raw

    def date(self, raw: Any, path: str) -> date:
        try:
            if isinstance(raw, str) and ISO_DATE.fullmatch(raw):
                return date.fromisoformat(raw)
        except ValueError:
            pass
        self.add(path, "must be an ISO date YYYY-MM-DD")
        return date.min

    def format(self, raw: dict[str, Any], path: str, name: str) -> None:
        if raw.get("format") != FORMATS[name]:
            self.add(f"{path}.format", f"must be {FORMATS[name]}")

    def unique(self, values: Iterable[str], path: str, label: str) -> None:
        seen = set()
        for value in values:
            if value in seen:
                self.add(path, f"duplicate {label} {value}")
            seen.add(value)


def _protocol(raw: Any, check: _Check) -> Protocol:
    fields = check.fields(raw, "protocol", ("format", "protocol_id", "version", "title", "passages")) or {}
    if fields:
        check.format(fields, "protocol", "protocol")
    passages = []
    raw_passages = fields.get("passages")
    if not isinstance(raw_passages, list) or not raw_passages:
        check.add("protocol.passages", "must be a non-empty list")
        raw_passages = []
    for index, entry in enumerate(raw_passages):
        path = f"protocol.passages[{index}]"
        item = check.fields(entry, path, ("anchor", "heading", "text")) or {}
        if item:
            passages.append(Passage(check.identifier(item["anchor"], f"{path}.anchor"),
                                    check.text(item["heading"], f"{path}.heading", nullable=True),
                                    check.text(item["text"], f"{path}.text", limit=MAX_TEXT)))
    check.unique((p.anchor for p in passages), "protocol.passages", "anchor")
    identity = digest(raw) if not check.problems else ""
    return Protocol(check.identifier(fields.get("protocol_id"), "protocol.protocol_id") or "",
                    check.text(fields.get("version"), "protocol.version", limit=64) or "",
                    check.text(fields.get("title"), "protocol.title") or "", tuple(passages), identity)


def _criteria(raw: Any, protocol: Protocol, check: _Check) -> CriterionSet | None:
    fields = check.fields(raw, "criteria", ("format", "criterion_set_id", "version", "protocol", "interpreter",
                                            "questions", "criteria"))
    if fields is None:
        return None
    check.format(fields, "criteria", "criteria")
    set_id = check.identifier(fields["criterion_set_id"], "criteria.criterion_set_id")
    version = check.text(fields["version"], "criteria.version", limit=64)
    reference = check.fields(fields["protocol"], "criteria.protocol", ("protocol_id", "version")) or {}
    if reference and (reference["protocol_id"], reference["version"]) != (protocol.protocol_id, protocol.version):
        check.add("criteria.protocol", "must name the bundled protocol and version")
    interpreter = check.fields(fields["interpreter"], "criteria.interpreter", ("kind", "name", "version")) or {}
    for key, value in interpreter.items():
        check.text(value, f"criteria.interpreter.{key}", limit=200)
    questions: dict[str, str] = {}
    if not isinstance(fields["questions"], list):
        check.add("criteria.questions", "must be a list")
    else:
        for index, entry in enumerate(fields["questions"]):
            item = check.fields(entry, f"criteria.questions[{index}]", ("question_id", "statement")) or {}
            if item:
                question = check.identifier(item["question_id"], f"criteria.questions[{index}].question_id")
                if question in questions:
                    check.add("criteria.questions", f"duplicate question {question}")
                questions[question] = check.text(item["statement"], f"criteria.questions[{index}].statement",
                                                 limit=1000)
    passages = {passage.anchor: passage.text for passage in protocol.passages}
    criteria = []
    if not isinstance(fields["criteria"], list) or not fields["criteria"]:
        check.add("criteria.criteria", "must be a non-empty list")
        return None
    for index, entry in enumerate(fields["criteria"]):
        path = f"criteria.criteria[{index}]"
        item = check.fields(entry, path, ("criterion_id", "category", "text", "source", "review_state",
                                          "interpretation"))
        if item is None:
            continue
        criterion_id = check.identifier(item["criterion_id"], f"{path}.criterion_id")
        if item["category"] not in ("inclusion", "exclusion"):
            check.add(f"{path}.category", "must be inclusion or exclusion")
        if item["review_state"] not in ("approved", "pending", "rejected"):
            check.add(f"{path}.review_state", "must be approved, pending or rejected")
        text = check.text(item["text"], f"{path}.text", limit=MAX_TEXT)
        source = check.fields(item["source"], f"{path}.source", ("anchor",)) or {}
        anchor = source.get("anchor")
        if source and (not isinstance(anchor, str) or anchor not in passages):
            check.add(f"{path}.source.anchor", f"unknown anchor {anchor!r}"[:200])
        elif source and text and text not in passages[anchor]:
            check.add(f"{path}.text", "does not quote its anchored passage exactly")
        try:
            interpretation = parse_interpretation(item["interpretation"], questions=questions,
                                                  path=f"{path}.interpretation")
        except EligibilityError as exc:
            check.problems.extend(exc.problems)
            continue
        criteria.append(_criterion(criterion_id, item["category"], text, anchor, item["review_state"],
                                   interpretation, {q: questions[q] for q in questions_of(interpretation)}))
    check.unique((c.criterion_id for c in criteria), "criteria.criteria", "criterion")
    if check.problems:
        return None
    return _criterion_set(set_id, version, protocol.protocol_id, protocol.version, interpreter, questions,
                          tuple(criteria))


def _value(concept: str, raw: Any, observed_on: date, path: str, check: _Check) -> Any:
    kind = CONCEPTS[concept].kind
    if kind == "date":
        value = check.date(raw, path)
        if value > observed_on:
            check.add(path, f"{concept} cannot be later than the date it was recorded")
        return value
    if kind == "code":
        return check.text(raw, path, limit=64)
    if kind == "assertion":
        if raw not in ("present", "absent"):
            check.add(path, "must be present or absent")
        return raw == "present"
    if kind == "ordinal":
        low, high = CONCEPTS[concept].minimum, CONCEPTS[concept].maximum
        if type(raw) is not int or not low <= raw <= high:
            check.add(path, f"{concept} must be an integer from {low} to {high}")
            return 0
        return raw
    if kind == "quantity":
        item = check.fields(raw, path, ("amount", "unit")) or {}
        if not item:
            return Quantity(Decimal(0), None)
        amount = item["amount"]
        if not isinstance(amount, str) or not DECIMAL.fullmatch(amount):
            check.add(f"{path}.amount", "must be a non-negative decimal string")
            amount = "0"
        unit = check.text(item["unit"], f"{path}.unit", limit=32, nullable=True)
        return Quantity(Decimal(amount), unit)
    item = check.fields(raw, path, ("regimen_id", "state", "start_on", "last_dose_on")) or {}
    if not item:
        return Regimen("", "completed", observed_on, None)
    if item["state"] not in ("ongoing", "completed"):
        check.add(f"{path}.state", "must be ongoing or completed")
    start = check.date(item["start_on"], f"{path}.start_on")
    last = None if item["last_dose_on"] is None else check.date(item["last_dose_on"], f"{path}.last_dose_on")
    if start > observed_on:
        check.add(f"{path}.start_on", "cannot be later than the date it was recorded")
    if item["state"] == "ongoing" and last is not None:
        check.add(f"{path}.last_dose_on", "an ongoing regimen records no last dose")
    if last is not None and not start <= last <= observed_on:
        check.add(f"{path}.last_dose_on", "must fall between start_on and the date it was recorded")
    return Regimen(check.identifier(item["regimen_id"], f"{path}.regimen_id"), item["state"], start, last)


def _cohort(raw: Any, check: _Check) -> tuple[Cohort | None, dict[str, Patient]]:
    fields = check.fields(raw, "cohort", ("format", "cohort_id", "version", "patients"))
    if fields is None:
        return None, {}
    check.format(fields, "cohort", "cohort")
    if not isinstance(fields["patients"], list) or not fields["patients"]:
        check.add("cohort.patients", "must be a non-empty list")
        return None, {}
    patients: dict[str, Patient] = {}
    evidence_ids: set[str] = set()
    note_ids: set[str] = set()
    for index, entry in enumerate(fields["patients"]):
        path = f"cohort.patients[{index}]"
        item = check.fields(entry, path, ("patient_id", "evidence", "notes"))
        if item is None:
            continue
        patient_id = check.identifier(item["patient_id"], f"{path}.patient_id")
        if patient_id in patients:
            check.add(path, f"duplicate patient {patient_id}")
        evidence = []
        for position, raw_item in enumerate(item["evidence"] if isinstance(item["evidence"], list) else []):
            where = f"{path}.evidence[{position}]"
            record = check.fields(raw_item, where, ("evidence_id", "concept", "observed_on", "encounter_id",
                                                    "status", "value", "provenance"))
            if record is None:
                continue
            evidence_id = check.identifier(record["evidence_id"], f"{where}.evidence_id")
            if evidence_id in evidence_ids:
                check.add(where, f"duplicate evidence {evidence_id}")
            evidence_ids.add(evidence_id)
            if not isinstance(record["concept"], str) or record["concept"] not in CONCEPTS:
                check.add(f"{where}.concept", f"unknown concept {record['concept']!r}"[:200])
                continue
            if record["status"] not in ("final", "entered_in_error"):
                check.add(f"{where}.status", "must be final or entered_in_error")
            observed_on = check.date(record["observed_on"], f"{where}.observed_on")
            provenance = check.fields(record["provenance"], f"{where}.provenance", ("source_kind", "origin")) or {}
            if provenance and provenance["source_kind"] != "structured":
                check.add(f"{where}.provenance.source_kind", "must be structured")
            evidence.append(Evidence(evidence_id, record["concept"], observed_on,
                                     check.identifier(record["encounter_id"], f"{where}.encounter_id", nullable=True),
                                     record["status"],
                                     _value(record["concept"], record["value"], observed_on, f"{where}.value", check),
                                     check.text(provenance.get("origin"), f"{where}.provenance.origin", limit=200)))
        if not isinstance(item["evidence"], list):
            check.add(f"{path}.evidence", "must be a list")
        notes = []
        for position, raw_note in enumerate(item["notes"] if isinstance(item["notes"], list) else []):
            where = f"{path}.notes[{position}]"
            record = check.fields(raw_note, where, ("note_id", "written_on", "encounter_id", "text", "provenance"))
            if record is None:
                continue
            note_id = check.identifier(record["note_id"], f"{where}.note_id")
            if note_id in note_ids:
                check.add(where, f"duplicate note {note_id}")
            note_ids.add(note_id)
            provenance = check.fields(record["provenance"], f"{where}.provenance", ("source_kind", "origin")) or {}
            if provenance and provenance["source_kind"] != "note":
                check.add(f"{where}.provenance.source_kind", "must be note")
            notes.append(Note(note_id, check.date(record["written_on"], f"{where}.written_on"),
                              check.identifier(record["encounter_id"], f"{where}.encounter_id", nullable=True),
                              check.text(record["text"], f"{where}.text", limit=MAX_TEXT),
                              check.text(provenance.get("origin"), f"{where}.provenance.origin", limit=200)))
        if not isinstance(item["notes"], list):
            check.add(f"{path}.notes", "must be a list")
        identity = digest({"patient_id": patient_id,
                           "evidence": sorted((e for e in item["evidence"] if isinstance(e, dict)),
                                              key=lambda e: str(e.get("evidence_id"))),
                           "notes": sorted((n for n in item["notes"] if isinstance(n, dict)),
                                           key=lambda n: str(n.get("note_id")))}) if not check.problems else ""
        patients[patient_id] = Patient(patient_id, tuple(evidence), tuple(notes), identity)
    if check.problems:
        return None, patients
    ordered = tuple(patients[patient_id] for patient_id in sorted(patients))
    identity = digest({"cohort_id": fields["cohort_id"], "version": fields["version"],
                       "patients": [[p.patient_id, p.digest] for p in ordered]})
    return Cohort(check.identifier(fields["cohort_id"], "cohort.cohort_id"),
                  check.text(fields["version"], "cohort.version", limit=64), ordered, identity), patients


def _narrative(raw: Any, patients: Mapping[str, Patient], questions: Mapping[str, str],
               check: _Check) -> NarrativeSource | None:
    fields = check.fields(raw, "narrative", ("format", "source", "decisions"))
    if fields is None:
        return None
    check.format(fields, "narrative", "narrative")
    source = check.fields(fields["source"], "narrative.source", ("kind", "description")) or {}
    kind = source.get("kind")
    if source and kind not in ("reference", "model"):
        check.add("narrative.source.kind", "must be reference or model")
    if source:
        check.text(source["description"], "narrative.source.description", limit=1000)
    if not isinstance(fields["decisions"], list):
        check.add("narrative.decisions", "must be a list")
        return None
    decisions: dict[tuple[str, str, date, int], NarrativeDecision] = {}
    raw_by_patient: dict[str, list[dict[str, Any]]] = {}
    for index, entry in enumerate(fields["decisions"]):
        path = f"narrative.decisions[{index}]"
        item = check.fields(entry, path, ("decision_id", "patient_id", "question_id", "evaluation_date",
                                          "window_days", "considered_note_ids", "value", "reason",
                                          "supporting_note_ids", "input_sha256"))
        if item is None:
            continue
        decision_id = check.identifier(item["decision_id"], f"{path}.decision_id")
        patient = patients.get(item["patient_id"]) if isinstance(item["patient_id"], str) else None
        if patient is None:
            check.add(f"{path}.patient_id", "must name a patient of the cohort")
            continue
        question = item["question_id"] if isinstance(item["question_id"], str) else ""
        if question not in questions:
            check.add(f"{path}.question_id", "unknown question")
        window = item["window_days"]
        if type(window) is not int or not 0 <= window <= 36_500:
            check.add(f"{path}.window_days", "must be an integer from 0 to 36500")
            window = -1
        own_notes = {note.note_id for note in patient.notes}
        considered, supporting = (_names(item[key]) for key in ("considered_note_ids", "supporting_note_ids"))
        for key, notes in (("considered_note_ids", considered), ("supporting_note_ids", supporting)):
            if notes is None or len(set(notes)) != len(notes) or not set(notes) <= own_notes:
                check.add(f"{path}.{key}", "must list distinct notes of the same patient")
        if considered is not None and not considered:
            check.add(f"{path}.considered_note_ids", "a decision considers at least one note")
        if considered is not None and supporting is not None and not set(supporting) <= set(considered):
            check.add(f"{path}.supporting_note_ids", "supporting notes must be among the considered notes")
        value, reason = item["value"], item["reason"]
        if value in ("yes", "no") and supporting is not None and not supporting:
            check.add(f"{path}.supporting_note_ids", "a decided answer must cite at least one considered note")
        binding = item["input_sha256"]
        if not isinstance(binding, str) or not SHA256.fullmatch(binding):
            check.add(f"{path}.input_sha256", "must be a lower-case SHA-256 digest")
        if value not in ("yes", "no", "undetermined"):
            check.add(f"{path}.value", "must be yes, no or undetermined")
        if (value == "undetermined") != (reason is not None) or (reason is not None and reason not in
                                                                   NARRATIVE_REASONS):
            check.add(f"{path}.reason", "an undetermined decision gives one of "
                                        f"{', '.join(NARRATIVE_REASONS)}; others give null")
        if reason == "model_abstention" and kind != "model":
            check.add(f"{path}.reason", "model_abstention comes only from a model source")
        evaluation_date = check.date(item["evaluation_date"], f"{path}.evaluation_date")
        key = (patient.patient_id, question, evaluation_date, window)
        if key in decisions:
            check.add(path, f"duplicate decision for {patient.patient_id} {question} on that date")
        if any(d.decision_id == decision_id for d in decisions.values()):
            check.add(path, f"duplicate decision {decision_id}")
        if considered is not None and supporting is not None:
            actual_binding = narrative_binding(patient.patient_id, question, questions.get(question), evaluation_date,
                                               window, (note for note in patient.notes if note.note_id in considered))
            decisions[key] = NarrativeDecision(decision_id, patient.patient_id, question, evaluation_date, window,
                                               frozenset(considered), value, reason, tuple(sorted(supporting)),
                                               binding, binding == actual_binding)
        raw_by_patient.setdefault(patient.patient_id, []).append(entry)
    if check.problems:
        return None
    patient_digests = {patient_id: digest({"kind": kind, "decisions": sorted(entries,
                                                                            key=lambda d: d["decision_id"])})
                       for patient_id, entries in raw_by_patient.items()}
    identity = digest({"kind": kind, "description": source["description"],
                       "patients": sorted([p, d] for p, d in patient_digests.items())})
    return NarrativeSource(kind, source["description"], MappingProxyType(decisions),
                           MappingProxyType(patient_digests), identity)


def _names(raw: Any) -> list[str] | None:
    return raw if isinstance(raw, list) and all(isinstance(name, str) for name in raw) else None


def _scenarios(raw: Any, criteria: CriterionSet, check: _Check) -> tuple[Scenario, ...]:
    fields = check.fields(raw, "scenarios", ("format", "scenarios")) or {}
    if fields:
        check.format(fields, "scenarios", "scenarios")
        if not isinstance(fields["scenarios"], list):
            check.add("scenarios.scenarios", "must be a list")
    scenarios = []
    for index, entry in enumerate(fields.get("scenarios") if isinstance(fields.get("scenarios"), list) else []):
        path = f"scenarios.scenarios[{index}]"
        item = check.fields(entry, path, ("scenario_id", "title", "author", "edits"))
        if item is None:
            continue
        scenario_id = check.identifier(item["scenario_id"], f"{path}.scenario_id")
        if scenario_id == BASELINE:
            check.add(f"{path}.scenario_id", "baseline is reserved for the unedited criteria")
        edits = []
        if not isinstance(item["edits"], list):
            check.add(f"{path}.edits", "must be a list")
        for position, raw_edit in enumerate(item["edits"] if isinstance(item["edits"], list) else []):
            edit = check.fields(raw_edit, f"{path}.edits[{position}]", ("criterion_id", "parameter", "value"))
            if edit is not None:
                edits.append(Edit(edit["criterion_id"], edit["parameter"], edit["value"]))
        scenarios.append(Scenario(scenario_id, check.text(item["title"], f"{path}.title"),
                                  check.text(item["author"], f"{path}.author", limit=200), tuple(edits)))
    check.unique((s.scenario_id for s in scenarios), "scenarios.scenarios", "scenario")
    return tuple(scenarios)


def parse_bundle(documents: Mapping[str, Any]) -> Bundle:
    """A validated bundle from its parsed documents (`manifest` and each input by name)."""
    check = _Check()
    manifest = check.fields(documents.get("manifest"), "manifest",
                            ("format", "bundle_id", "bundle_version", "reference_date", "inputs")) or {}
    if manifest:
        check.format(manifest, "manifest", "manifest")
    bundle_id = check.identifier(manifest.get("bundle_id"), "manifest.bundle_id")
    bundle_version = check.text(manifest.get("bundle_version"), "manifest.bundle_version", limit=64)
    _manifest_inputs(manifest.get("inputs"), check)
    protocol = _protocol(documents.get("protocol"), check)
    criteria = _criteria(documents.get("criteria"), protocol, check)
    cohort, patients = _cohort(documents.get("cohort"), check)
    narrative = _narrative(documents.get("narrative"), patients,
                           criteria.questions if criteria is not None else {}, check)
    scenarios = _scenarios(documents.get("scenarios"), criteria, check) if criteria is not None else ()
    reference_date = check.date(manifest.get("reference_date"), "manifest.reference_date")
    if check.problems or criteria is None or cohort is None or narrative is None:
        raise EligibilityError("bundle_invalid", "the bundle does not match its contract", check.problems)
    for scenario in scenarios:
        criteria.apply(scenario.edits)  # Refuses protected, unknown, mistyped and out-of-bounds edits.
    return Bundle(bundle_id, bundle_version, reference_date,
                  protocol, criteria, cohort, narrative, scenarios)


def _manifest_inputs(raw: Any, check: _Check) -> dict[str, Any]:
    inputs = check.fields(raw, "manifest.inputs", INPUTS) or {}
    for name, entry in inputs.items():
        path = f"manifest.inputs.{name}"
        fields = check.fields(entry, path, ("file", "sha256", "bytes"))
        if fields is None:
            continue
        if not isinstance(fields["file"], str) or not FILENAME.fullmatch(fields["file"]):
            check.add(f"{path}.file", "must be a plain JSON file name")
        if not isinstance(fields["sha256"], str) or not SHA256.fullmatch(fields["sha256"]):
            check.add(f"{path}.sha256", "must be a lower-case SHA-256 digest")
        if type(fields["bytes"]) is not int or not 0 <= fields["bytes"] <= MAX_FILE_BYTES:
            check.add(f"{path}.bytes", f"must be an integer from 0 to {MAX_FILE_BYTES}")
    return inputs


def _read(path: Path, label: str) -> bytes:
    """A bounded regular file, never followed through a symlink, unchanged while read."""
    flags = os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0)
    try:
        if not stat.S_ISREG(path.lstat().st_mode):
            raise EligibilityError("bundle_integrity", f"{label} must be a regular file, not a symlink or device")
        with os.fdopen(os.open(path, flags), "rb") as handle:
            before = os.fstat(handle.fileno())
            if not stat.S_ISREG(before.st_mode) or before.st_size > MAX_FILE_BYTES:
                raise EligibilityError("bundle_integrity", f"{label} is not a regular file within the size limit")
            data = handle.read(MAX_FILE_BYTES + 1)
            after = os.fstat(handle.fileno())
    except OSError:
        raise EligibilityError("bundle_integrity", f"{label} is missing, unreadable or a symlink") from None
    if len(data) != before.st_size or (before.st_size, before.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise EligibilityError("bundle_integrity", f"{label} changed while it was read")
    return data


def _json(data: bytes, label: str) -> Any:
    try:
        return strict_loads(data)
    except (UnicodeDecodeError, ValueError, RecursionError) as exc:
        raise EligibilityError("bundle_invalid", f"{label} is not strict UTF-8 JSON: {exc}"[:300]) from None


def read_document(path: Path, label: str) -> tuple[bytes, Any]:
    """The bytes and strict JSON document of a bounded regular file that is not a symlink."""
    data = _read(path, label)
    return data, _json(data, label)


def with_narrative(documents: Mapping[str, Any], narrative: Any) -> dict[str, Any]:
    """The bundle documents with `narrative` as their narrative source, its manifest entry rehashed."""
    replaced = {**documents, "narrative": narrative,
                "manifest": {**documents["manifest"], "inputs": dict(documents["manifest"]["inputs"])}}
    try:
        data = canonical_json(narrative)
    except (TypeError, ValueError) as exc:
        raise EligibilityError("bundle_invalid", f"the narrative document cannot be encoded: {exc}"[:300]) from None
    replaced["manifest"]["inputs"]["narrative"] = {**documents["manifest"]["inputs"]["narrative"],
                                                   "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
    return replaced


def load_documents(directory: Path) -> tuple[dict[str, Any], str]:
    """The documents of the bundle in `directory`, after checking every input file against the manifest, and the
    manifest file's SHA-256."""
    manifest_bytes, manifest = read_document(directory / "manifest.json", "manifest.json")
    check = _Check()
    inputs = _manifest_inputs(manifest.get("inputs") if isinstance(manifest, dict) else None, check)
    if check.problems:
        raise EligibilityError("bundle_invalid", "manifest.json has invalid inputs", check.problems)
    documents: dict[str, Any] = {"manifest": manifest}
    for name in INPUTS:
        entry = inputs[name]
        data = _read(directory / entry["file"], entry["file"])
        if len(data) != entry["bytes"] or hashlib.sha256(data).hexdigest() != entry["sha256"]:
            raise EligibilityError("bundle_integrity", f"{entry['file']} does not match its manifest SHA-256 "
                                                       "and size")
        documents[name] = _json(data, entry["file"])
    return documents, hashlib.sha256(manifest_bytes).hexdigest()


def load_bundle(directory: Path) -> Bundle:
    """The bundle in `directory`, after checking every input file against the manifest."""
    return parse_bundle(load_documents(directory)[0])
