"""`eligibility-lab`: validate a bundle, evaluate a run, compare a scenario with the baseline, time recalculation, and
export narrative inputs and validate model replies to them without calling any model.

`narrative-inputs` writes every narrative input of a bundle as the narrative question contract presents it to a model,
with none of the bundle's narrative decisions. `narrative-answers` validates the final replies a caller collected for
those inputs and writes each input's outcome with the model narrative source of the accepted replies;
`evaluate --narrative` and `compare --narrative` then run the bundle on that source instead of its own.

Outputs are canonical JSON written once to a new owner-only file. Output lines hold identities and counts. Exit codes:
0 done; 1 written, but a run has execution failures (incomplete coverage); 2 refused, with the stable code.
"""
from __future__ import annotations

import argparse
from datetime import date
import hashlib
import os
from pathlib import Path
import re
import sys
import tempfile
from typing import Any, Sequence

from eligibility_lab import __version__, narrative
from eligibility_lab.canonical import canonical_json
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import ISO_DATE, Bundle, Edit, load_documents, parse_bundle, read_document, with_narrative
from eligibility_lab.rules import Executable
from eligibility_lab.run import DEFAULT_WORKSPACE, benchmark, compare, evaluate

EDIT = re.compile(r"([A-Za-z0-9][A-Za-z0-9._:-]*)\.([a-z][a-z0-9_]*)=(.+)")


def _write(path: Path, document: dict[str, Any]) -> None:
    """Create `path` once, owner-only, from a complete synced temporary file; an existing path is refused."""
    if path.exists() or path.is_symlink():
        raise EligibilityError("output_exists", f"{path.name} already exists; choose a new output path")
    if not path.parent.is_dir():
        raise EligibilityError("output_unwritable", f"{path.parent} is not an existing folder")
    descriptor, temporary = tempfile.mkstemp(prefix=".eligibility-lab-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(canonical_json(document))
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary, 0o600)
        try:
            os.link(temporary, path)  # Linking a complete file is atomic and fails if the destination exists.
        except FileExistsError:
            raise EligibilityError("output_exists", f"{path.name} appeared while it was written") from None
    finally:
        os.unlink(temporary)


def _edits(bundle: Bundle, raw: Sequence[str]) -> list[Edit] | None:
    """`criterion.parameter=value` edits; integers are read as integers for integer parameters."""
    if not raw:
        return None
    edits = []
    for text in raw:
        match = EDIT.fullmatch(text)
        if match is None:
            raise EligibilityError("invalid_scenario",
                                   f"an edit is written criterion.parameter=value, not {text!r}"[:200])
        criterion_id, parameter, value = match.groups()
        known = next((c for c in bundle.criteria.criteria if c.criterion_id == criterion_id), None)
        interpretation = known.interpretation if known is not None else None
        if isinstance(interpretation, Executable) and parameter in interpretation.parameters and \
                interpretation.parameters[parameter].type == "integer" and re.fullmatch(r"-?[0-9]+", value):
            edits.append(Edit(criterion_id, parameter, int(value)))
        else:
            edits.append(Edit(criterion_id, parameter, value))
    return edits


def _date(raw: str | None) -> date | None:
    if raw is None:
        return None
    try:
        if ISO_DATE.fullmatch(raw):
            return date.fromisoformat(raw)
    except ValueError:
        pass
    raise EligibilityError("invalid_run", "the evaluation date must be an ISO date YYYY-MM-DD")


def _summary(counts: dict[str, int]) -> str:
    return (f"{counts['passing']} passing, {counts['failing']} failing, {counts['unresolved']} unresolved of "
            f"{counts['total']}")


def _bundle(args: argparse.Namespace) -> tuple[Bundle, str]:
    """The bundle, run on the `--narrative` source when one is named, and its manifest file's SHA-256."""
    documents, manifest_sha256 = load_documents(args.bundle)
    if getattr(args, "narrative", None) is not None:
        documents = with_narrative(documents, read_document(args.narrative, args.narrative.name)[1])
    return parse_bundle(documents), manifest_sha256


def _run(args: argparse.Namespace) -> int:
    bundle, manifest_sha256 = _bundle(args)
    if args.command in ("narrative-inputs", "narrative-answers"):
        on = _date(args.evaluation_date) or bundle.reference_date
        if args.command == "narrative-inputs":
            document = narrative.inputs_document(bundle, manifest_sha256, on)
            _write(args.output, document)
            print(f"Narrative inputs: {len(document['inputs'])} for {bundle.bundle_id} {bundle.bundle_version} on {on}"
                  f"; prompt {document['contract']['prompt']}; no narrative decision exported")
            return 0
        data, outputs = read_document(args.outputs, args.outputs.name)
        document = narrative.answers_document(bundle, manifest_sha256, on, outputs, hashlib.sha256(data).hexdigest(),
                                              args.description)
        _write(args.output, document)
        counts = document["counts"]
        print(f"Narrative answers: {counts['answered']} of {counts['inputs']} accepted; "
              + ", ".join(f"{code} {counts[code]}" for code in narrative.OUTCOMES[1:]))
        return 0
    if args.command == "validate":
        print(f"Bundle {bundle.bundle_id} {bundle.bundle_version}: {len(bundle.cohort.patients)} patients, "
              f"{len(bundle.criteria.criteria)} criteria, {len(bundle.scenarios)} saved scenarios; reference date "
              f"{bundle.reference_date}; cohort {bundle.cohort.digest}; criteria {bundle.criteria.digest}")
        return 0
    if args.command == "benchmark":
        report = benchmark(bundle, repeat=args.repeat, workspace=args.workspace)
        _write(args.output, report)
        for entry in report["scenarios"]:
            print(f"{entry['scenario_id']}: full recalculation median {entry['full_recalculation_us']['median']} us, "
                  f"deterministic {str(entry['deterministic']).lower()}")
        return 0 if all(entry["deterministic"] for entry in report["scenarios"]) else 1
    edits = _edits(bundle, args.edit)
    if edits is not None and args.scenario is not None:
        raise EligibilityError("invalid_scenario", "use --scenario or --edit, not both")
    on = _date(args.evaluation_date)
    if args.command == "evaluate":
        result = evaluate(bundle, scenario=args.scenario, edits=edits, author=args.author, evaluation_date=on,
                          order=args.order.split(",") if args.order else None, workspace=args.workspace)
        _write(args.output, result)
        complete = result["coverage"]["complete"]
        print(f"Run {result['run_id']}: {_summary(result['counts'])}; coverage "
              f"{'complete' if complete else 'incomplete'}; content {result['content_digest']}")
        return 0 if complete else 1
    if edits is None and args.scenario is None:
        raise EligibilityError("invalid_scenario", "compare needs --scenario or --edit")
    comparison = compare(bundle, scenario=args.scenario, edits=edits, author=args.author, evaluation_date=on,
                         workspace=args.workspace)
    _write(args.output, comparison)
    before, after = comparison["baseline"]["counts"], comparison["scenario"]["counts"]
    print(f"Comparison {comparison['content_digest']}: passing {before['passing']} -> {after['passing']} "
          f"({comparison['passing_delta']:+d}) of {after['total']}")
    return 0 if comparison["complete"] else 1


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="eligibility-lab", description=__doc__.splitlines()[0])
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    commands = parser.add_subparsers(dest="command", required=True)
    validate = commands.add_parser("validate", help="Check a bundle's integrity and contract and print its identities")
    run = commands.add_parser("evaluate", help="Evaluate the baseline, a saved scenario or custom edits")
    versus = commands.add_parser("compare", help="Compare a saved scenario or custom edits with the baseline")
    timing = commands.add_parser("benchmark", help="Time recalculation of the baseline and every saved scenario")
    inputs = commands.add_parser("narrative-inputs", help="Export every narrative input as a model is given it, "
                                                          "without the bundle's narrative decisions")
    answers = commands.add_parser("narrative-answers", help="Validate model replies to the narrative inputs and "
                                                            "build their model narrative source")
    for command in (validate, run, versus, timing, inputs, answers):
        command.add_argument("--bundle", required=True, type=Path, help="A bundle folder holding manifest.json")
    for command in (run, versus, timing, inputs, answers):
        command.add_argument("--output", required=True, type=Path, help="A new JSON file")
    for command in (run, versus, timing):
        command.add_argument("--workspace", default=DEFAULT_WORKSPACE, help="The workspace the run belongs to")
    for command in (inputs, answers):
        command.add_argument("--evaluation-date", dest="evaluation_date", help="YYYY-MM-DD; the bundle's reference "
                                                                               "date when omitted")
    answers.add_argument("--outputs", required=True, type=Path,
                         help=f"A {narrative.OUTPUTS_FORMAT} document: the final reply per input")
    answers.add_argument("--description", required=True, help="Who produced the replies, for the narrative source")
    for command in (run, versus):
        command.add_argument("--narrative", type=Path, help="A narrative document to run instead of the bundle's")
        command.add_argument("--scenario", help="A saved scenario id; the baseline when omitted from evaluate")
        command.add_argument("--edit", action="append", default=[], metavar="CRITERION.PARAMETER=VALUE",
                             help="Edit an editable parameter; repeat for several")
        command.add_argument("--author", help="Who made the --edit changes")
        command.add_argument("--evaluation-date", dest="evaluation_date", help="YYYY-MM-DD; the bundle's reference "
                                                                               "date when omitted")
    run.add_argument("--order", help="Comma-separated criterion ids for the waterfall; the protocol order when omitted")
    timing.add_argument("--repeat", type=int, default=25, help="Repetitions per scenario (1 to 1000)")
    args = parser.parse_args(argv)
    try:
        return _run(args)
    except EligibilityError as exc:
        print(f"Refused: {exc}", file=sys.stderr)
        for problem in exc.problems[:20]:
            print(f"  {problem}", file=sys.stderr)
        if len(exc.problems) > 20:
            print(f"  ... {len(exc.problems) - 20} more", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"Refused: output_unwritable: {exc.strerror or type(exc).__name__}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
