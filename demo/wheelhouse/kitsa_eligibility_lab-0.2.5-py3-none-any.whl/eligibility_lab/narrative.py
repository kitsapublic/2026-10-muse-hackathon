"""Narrative inputs: the notes each narrative leaf of a criterion set reads, and the binding a decision needs.

A narrative leaf reads the patient's notes written inside its window: on or before the evaluation date and no earlier
than `window_days` before it. With no such note the leaf is insufficient evidence and needs no decision. Otherwise
the decision must consider exactly those notes and carry their `input_sha256` (`model.narrative_binding`), so any
change to the patient, question statement, date, window or a considered note's content leaves it stale.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from eligibility_lab.model import Cohort, CriterionSet, Note, Patient, narrative_binding
from eligibility_lab.rules import narratives_of


@dataclass(frozen=True)
class NarrativeInput:
    patient_id: str
    question_id: str
    statement: str
    evaluation_date: date
    window_days: int
    notes: tuple[Note, ...]  # sorted by note_id
    input_sha256: str


def notes_in_window(patient: Patient, evaluation_date: date, window_days: int) -> tuple[Note, ...]:
    first = evaluation_date - timedelta(days=window_days)
    return tuple(sorted((note for note in patient.notes if first <= note.written_on <= evaluation_date),
                        key=lambda note: note.note_id))


def narrative_inputs(criteria: CriterionSet, cohort: Cohort, evaluation_date: date) -> tuple[NarrativeInput, ...]:
    """Every patient, question and window the criteria read that has notes to decide on, sorted by patient,
    question and window."""
    leaves = sorted({(leaf.question, leaf.window_days) for criterion in criteria.criteria
                     for leaf in narratives_of(criterion.interpretation)})
    inputs = []
    for patient in sorted(cohort.patients, key=lambda p: p.patient_id):
        for question, window in leaves:
            notes = notes_in_window(patient, evaluation_date, window)
            if notes:
                statement = criteria.questions[question]
                inputs.append(NarrativeInput(patient.patient_id, question, statement, evaluation_date, window, notes,
                                             narrative_binding(patient.patient_id, question, statement,
                                                               evaluation_date, window, notes)))
    return tuple(inputs)
