"""Durable jobs: submission, the state machine, claims, cancellation, resume and explicit retries.

A job is a durable submission with its own identifier, separate from the engine's content-derived run identifier. Its
inputs are pinned when it is accepted: the installed bundle, the approved interpretation set, the evaluation date, the
mode, the configuration that decides its answers and cost (see `configuration`) and, for a scenario, the baseline job
and parameter edits. The fingerprint is the digest of the normalized request; the same idempotency key with the same
fingerprint returns the existing job, and with a different one is refused.

States are `queued`, `running`, `succeeded`, `partial` (a result was committed, but some provider work or some cells
failed), `failed` (no result) and `cancelled`. A worker claims a queued job, or a running job whose lease expired, in
one transaction that increments its generation and takes ownership; each later step checks that generation and owner,
so a superseded worker can never dispatch, record its answer on the item or finalize. Reclaiming marks work that was
dispatched but never settled `ambiguous`; it is never resent automatically. Cancelling a queued job ends it at once;
cancelling a running job stops new dispatch and its worker ends it as cancelled, without a result. Resuming a
cancelled, partial or failed job requeues only work known not to have been sent. Ambiguous or failed provider work is
redone only by an explicit retry, which makes a new attempt linked to the previous one with its own reservation and
always asks again. Resume and retry are refused, before anything is reopened, unless the service still runs the
job's pinned configuration. A baseline that a scenario pins cannot be resumed or retried, so the scenario's comparison
stays reproducible.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass
from datetime import date
import hashlib
from typing import Any, Iterable, Mapping, Sequence

from eligibility_lab.canonical import canonical_json, digest
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import FORMATS, IDENTIFIER, Edit, parse_bundle
from eligibility_lab.service import configuration, provider
from eligibility_lab.service.catalog import Installed, load_installed
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.interpretations import current_set_reviews, interpretation_set
from eligibility_lab.service.store import Store, dumps, loads, new_id

MODES = ("reference", "recorded", "live")
TERMINAL = ("succeeded", "partial", "failed", "cancelled")
MODE_LABELS = {"reference": "Reference: authored reference interpretations and narrative decisions",
               "recorded": "Recorded model: retained genuine model responses, revalidated and rerun",
               "live": "Live model: new provider requests"}


@dataclass(frozen=True)
class Claim:
    job_id: str
    generation: int
    worker: str


def _key(raw: Any) -> str:
    if not isinstance(raw, str) or not IDENTIFIER.fullmatch(raw):
        raise Refusal("invalid_idempotency_key", "the idempotency key must be 1-128 letters, digits and . _ : -")
    return raw


def _date(raw: Any, default: date) -> str:
    if raw is None:
        return default.isoformat()
    try:
        if isinstance(raw, str) and len(raw) == 10:
            return date.fromisoformat(raw).isoformat()
    except ValueError:
        pass
    raise Refusal("invalid_evaluation_date", "the evaluation date must be YYYY-MM-DD")


def _recordings_exist(connection, audiences: Sequence[str]) -> bool:
    """Whether a pinned job of these audiences accepted a genuine narrative answer that recorded mode can replay."""
    return connection.execute(
        "SELECT 1 FROM items JOIN attempts ON attempts.attempt_id = items.answer_attempt JOIN jobs ON jobs.job_id = "
        "attempts.job_id JOIN bundles ON bundles.bundle_key = jobs.bundle_key WHERE items.kind = 'narrative' AND "
        f"attempts.transport = ? AND attempts.configuration = ? AND jobs.configuration IS NOT NULL AND bundles.audience IN "
        f"({','.join('?' * len(audiences))}) LIMIT 1", (provider.GENUINE_TRANSPORT, dumps(provider.configuration("narrative")), *audiences)).fetchone() is not None


def mode_availability(connection, live_experiment: str | None,
                      audiences: Sequence[str] = ("public",)) -> dict[str, dict[str, Any]]:
    live_reason = None
    if live_experiment is None:
        live_reason = "Live mode is disabled: the service was not started with live mode enabled."
    else:
        experiment = connection.execute("SELECT enabled FROM experiments WHERE experiment_id = ?",
                                        (live_experiment,)).fetchone()
        if experiment is None or not experiment["enabled"]:
            live_reason = "Live mode is disabled: its experiment is not enabled for spending."
    recorded = _recordings_exist(connection, audiences)
    return {"reference": {"available": True, "reason": None, "label": MODE_LABELS["reference"]},
            "recorded": {"available": recorded, "label": MODE_LABELS["recorded"],
                         "reason": None if recorded else "No genuine model responses match the current provider configuration."},
            "live": {"available": live_reason is None, "reason": live_reason, "label": MODE_LABELS["live"],
                     "experiment_id": live_experiment if live_reason is None else None}}


def _require_mode(connection, mode: Any, live_experiment: str | None, request: Mapping[str, Any],
                  audiences: Sequence[str], transport: str | None) -> None:
    if mode not in MODES:
        raise Refusal("invalid_mode", "mode must be reference, recorded or live")
    availability = mode_availability(connection, live_experiment, audiences)[mode]
    if not availability["available"]:
        raise Refusal(f"{mode}_mode_unavailable", availability["reason"], status=409)
    if mode == "live":
        if transport is None:
            raise Refusal("live_mode_unavailable", "Live mode is disabled: the service has no provider client.",
                          status=409)
        if request.get("experiment_id") != live_experiment:
            raise Refusal("experiment_mismatch", "name the experiment the service enabled for live mode", status=409)
        if request.get("confirm_spend") is not True:
            raise Refusal("spend_not_confirmed", "a live job must confirm that it may spend from the experiment",
                          status=409)


def _edits(raw: Any) -> list[dict[str, Any]]:
    if not isinstance(raw, list) or not raw or len(raw) > 10:
        raise Refusal("invalid_scenario", "a scenario edits between one and ten parameters")
    edits = []
    for entry in raw:
        if not isinstance(entry, dict) or set(entry) != {"criterion_id", "parameter", "value"} \
                or not isinstance(entry["criterion_id"], str) or not isinstance(entry["parameter"], str) \
                or type(entry["value"]) not in (int, str):
            raise Refusal("invalid_scenario", "an edit has exactly criterion_id, parameter and value")
        edits.append({"criterion_id": entry["criterion_id"][:64], "parameter": entry["parameter"][:64],
                      "value": entry["value"]})
    return sorted(edits, key=lambda e: (e["criterion_id"], e["parameter"]))


def normalize(request: Mapping[str, Any]) -> dict[str, Any]:
    """The request's canonical form, whose digest is its fingerprint. Validation against stored state follows."""
    kind = request.get("kind")
    if kind == "baseline":
        ids = request.get("proposal_ids")
        if not isinstance(ids, list) or not all(isinstance(i, str) for i in ids) or len(ids) > 200:
            raise Refusal("invalid_interpretation_set", "proposal_ids lists one approved proposal per criterion")
        return {"kind": kind, "bundle_key": str(request.get("bundle_key"))[:200], "mode": request.get("mode"),
                "evaluation_date": request.get("evaluation_date"), "proposal_ids": sorted(ids),
                "experiment_id": request.get("experiment_id"), "confirm_spend": request.get("confirm_spend") is True}
    if kind == "scenario":
        saved, edits = request.get("scenario_id"), request.get("edits")
        if (saved is None) == (edits is None):
            raise Refusal("invalid_scenario", "name a saved scenario or give edits, not both")
        title = request.get("title")
        if title is not None and (not isinstance(title, str) or not title.strip() or len(title) > 200):
            raise Refusal("invalid_scenario", "a title is 1-200 characters")
        return {"kind": kind, "baseline_job_id": str(request.get("baseline_job_id"))[:64],
                "scenario_id": None if saved is None else str(saved)[:128],
                "edits": None if edits is None else _edits(edits), "title": title}
    if kind == "interpretation":
        criteria = request.get("criterion_ids")
        if not isinstance(criteria, list) or not criteria or not all(isinstance(c, str) for c in criteria) \
                or len(set(criteria)) != len(criteria) or len(criteria) > 100:
            raise Refusal("invalid_request", "criterion_ids lists distinct criteria to interpret")
        return {"kind": kind, "bundle_key": str(request.get("bundle_key"))[:200], "mode": "live",
                "criterion_ids": sorted(criteria), "experiment_id": request.get("experiment_id"),
                "confirm_spend": request.get("confirm_spend") is True, "retry": request.get("retry") is True}
    raise Refusal("invalid_request", "kind must be baseline, scenario or interpretation")


def _job(connection, job_id: str, keys: Sequence[str] | None):
    row = connection.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
    if row is None or (keys is not None and row["bundle_key"] not in keys):
        raise Refusal("job_not_found", "no job has that identity", status=404)
    return row


def _visible(connection, audiences: Sequence[str]) -> list[str]:
    return [row["bundle_key"] for row in connection.execute(
        f"SELECT bundle_key FROM bundles WHERE audience IN ({','.join('?' * len(audiences))})", tuple(audiences))]


def job_documents(installed: Installed, criteria_document: Mapping[str, Any],
                  narrative_document: Mapping[str, Any]) -> dict[str, Any]:
    """The bundle documents a job runs: the installed protocol and cohort, the interpretation set's criteria, the
    narrative source and the saved scenarios that apply to those criteria, with a manifest hashing what changed."""
    documents = {name: copy.deepcopy(installed.documents[name]) for name in ("manifest", "protocol", "cohort")}
    documents.update(criteria=copy.deepcopy(dict(criteria_document)), narrative=copy.deepcopy(dict(narrative_document)),
                     scenarios={"format": FORMATS["scenarios"], "scenarios": []})
    criteria = parse_bundle(documents).criteria
    applicable = []
    for scenario, raw in zip(installed.bundle.scenarios, installed.documents["scenarios"]["scenarios"]):
        try:
            criteria.apply(scenario.edits)
            applicable.append(copy.deepcopy(raw))
        except EligibilityError:
            continue
    documents["scenarios"] = {**copy.deepcopy(installed.documents["scenarios"]), "scenarios": applicable}
    for name in ("criteria", "narrative", "scenarios"):
        if documents[name] != installed.documents[name]:
            data = canonical_json(documents[name])
            documents["manifest"]["inputs"][name] = {"file": f"{name}.json", "sha256": hashlib.sha256(data).hexdigest(),
                                                     "bytes": len(data)}
    return documents


def empty_model_narrative() -> dict[str, Any]:
    return {"format": FORMATS["narrative"], "decisions": [],
            "source": {"kind": "model", "description": f"Narrative decisions from {provider.MODEL}."}}


def scenario_edits(installed: Installed, criteria_document: Mapping[str, Any], spec: Mapping[str, Any]) -> list[Edit]:
    """The scenario's edits, refused unless every edit is a policy-editable parameter within its bounds."""
    try:
        bundle = parse_bundle(job_documents(installed, criteria_document, installed.documents["narrative"]))
        if spec["scenario_id"] is not None:
            edits = list(bundle.scenario(spec["scenario_id"]).edits)
        else:
            edits = [Edit(e["criterion_id"], e["parameter"], e["value"]) for e in spec["edits"]]
        bundle.criteria.apply(edits)
        for edit in edits:
            if (edit.criterion_id, edit.parameter) not in installed.policy:
                raise Refusal("protected_parameter", f"{edit.criterion_id}.{edit.parameter} is not a permitted "
                                                     "scenario parameter")
    except EligibilityError as exc:
        raise Refusal.from_engine(exc, status=404 if exc.code == "unknown_scenario" else 422) from None
    return edits


def submit(store: Store, request: Mapping[str, Any], idempotency_key: Any, *, operator: str,
           audiences: Sequence[str] = ("public",), live_experiment: str | None = None,
           transport: str | None = None) -> tuple[dict, bool]:
    """The job for this request: newly queued, or the existing one for the same key and request. `transport` labels
    the provider client that would answer live work; the job pins it with the rest of its configuration."""
    # Keys of the HTTP API and of the operator commands are separate namespaces, so an HTTP request can never reach
    # an operator job, such as a private benchmark run, through its key.
    key = f"{'http' if tuple(audiences) == ('public',) else 'operator'}:{_key(idempotency_key)}"
    normalized = normalize(request)
    fingerprint = digest(normalized)
    with store.write() as connection:
        existing = connection.execute("SELECT * FROM jobs WHERE idempotency_key = ?", (key,)).fetchone()
        if existing is not None:
            if existing["fingerprint"] != fingerprint:
                raise Refusal("idempotency_conflict", "this idempotency key was used for a different request",
                              status=409)
            return describe(connection, existing), False
        visible = _visible(connection, audiences)
        values: dict[str, Any] = {"set_id": None, "baseline_job_id": None, "experiment_id": None}
        if normalized["kind"] in ("baseline", "interpretation"):
            if normalized["bundle_key"] not in visible:
                raise Refusal("bundle_not_found", "no installed bundle has that identity", status=404)
            installed = load_installed(store, normalized["bundle_key"], connection)
            _require_mode(connection, normalized["mode"], live_experiment, normalized, audiences, transport)
            values.update(bundle_key=installed.key, mode=normalized["mode"],
                          experiment_id=normalized["experiment_id"] if normalized["mode"] == "live" else None,
                          configuration=configuration.current(normalized["kind"], normalized["mode"], transport))
            if normalized["kind"] == "baseline":
                values["evaluation_date"] = _date(normalized["evaluation_date"], installed.bundle.reference_date)
                values["set_id"] = interpretation_set(connection, store, installed,
                                                      normalized["proposal_ids"])["set_id"]
            else:
                criteria = {c["criterion_id"] for c in installed.documents["criteria"]["criteria"]}
                unknown = [c for c in normalized["criterion_ids"] if c not in criteria]
                if unknown:
                    raise Refusal("unknown_criterion", "the bundle has no such criterion", status=404,
                                  problems=unknown)
                values["evaluation_date"] = installed.bundle.reference_date.isoformat()
        else:
            baseline = _job(connection, normalized["baseline_job_id"], visible)
            if baseline["kind"] != "baseline" or baseline["state"] not in ("succeeded", "partial"):
                raise Refusal("baseline_not_ready", "a scenario needs a finished baseline job with a result",
                              status=409)
            stale = current_set_reviews(connection, baseline["set_id"])
            if stale:
                raise Refusal("interpretation_review_changed", "the baseline's interpretations were reviewed again; "
                              "run a new baseline", status=409, problems=stale)
            pinned = loads(baseline["configuration"])
            configuration.check(pinned, "scenario", baseline["mode"], None)
            installed = load_installed(store, baseline["bundle_key"], connection)
            document = loads(connection.execute("SELECT criteria_document FROM interpretation_sets WHERE set_id = ?",
                                                (baseline["set_id"],)).fetchone()["criteria_document"])
            scenario_edits(installed, document, normalized)
            values.update(bundle_key=baseline["bundle_key"], mode=baseline["mode"], set_id=baseline["set_id"],
                          baseline_job_id=baseline["job_id"], configuration=pinned,
                          evaluation_date=loads(baseline["request"])["evaluation_date"])
        snapshot = {**normalized, "evaluation_date": values["evaluation_date"], "operator": operator}
        job_id, now = new_id("job"), store.timestamp()
        connection.execute(
            "INSERT INTO jobs (job_id, kind, mode, bundle_key, set_id, baseline_job_id, experiment_id, request, "
            "fingerprint, idempotency_key, state, configuration, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'queued', ?, ?, ?)",
            (job_id, normalized["kind"], values["mode"], values["bundle_key"], values["set_id"],
             values["baseline_job_id"], values["experiment_id"], dumps(snapshot), fingerprint, key,
             dumps(values["configuration"]), now, now))
        return describe(connection, _job(connection, job_id, None)), True


def describe(connection, row) -> dict[str, Any]:
    progress = {state: 0 for state in ("pending", "dispatched", "answered", "failed", "ambiguous", "skipped")}
    for item in connection.execute("SELECT state, COUNT(*) AS n FROM items WHERE job_id = ? GROUP BY state",
                                   (row["job_id"],)):
        progress[item["state"]] = item["n"]
    progress["total"] = sum(progress.values())
    result = connection.execute("SELECT run_id, content_digest, document, metrics FROM results WHERE job_id = ?",
                                (row["job_id"],)).fetchone()
    summary = None
    if result is not None:
        document = loads(result["document"])
        summary = {"run_id": result["run_id"], "content_digest": result["content_digest"],
                   "counts": document["counts"], "coverage_complete": document["coverage"]["complete"],
                   "metrics": loads(result["metrics"])}
    request = loads(row["request"])
    scenario = None
    if row["kind"] == "scenario":
        scenario = {"scenario_id": request["scenario_id"], "edits": request["edits"], "title": request["title"]}
    return {"job_id": row["job_id"], "kind": row["kind"], "mode": row["mode"], "mode_label": MODE_LABELS[row["mode"]],
            "bundle_key": row["bundle_key"], "set_id": row["set_id"], "baseline_job_id": row["baseline_job_id"],
            "experiment_id": row["experiment_id"], "evaluation_date": request["evaluation_date"],
            "configuration_sha256": None if row["configuration"] is None else digest(loads(row["configuration"])),
            "scenario": scenario, "criterion_ids": request.get("criterion_ids"), "state": row["state"],
            "cancel_requested": bool(row["cancel_requested"]), "generation": row["generation"],
            "error": loads(row["error"]), "progress": progress, "result": summary,
            "created_at": row["created_at"], "updated_at": row["updated_at"], "finished_at": row["finished_at"]}


def get(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    with store.read() as connection:
        return describe(connection, _job(connection, job_id, _visible(connection, audiences)))


def list_jobs(store: Store, bundle_key: str | None = None, *, audiences: Sequence[str] = ("public",),
              limit: int = 100) -> list[dict[str, Any]]:
    with store.read() as connection:
        rows = connection.execute(
            f"SELECT jobs.* FROM jobs JOIN bundles USING (bundle_key) WHERE bundles.audience IN "
            f"({','.join('?' * len(audiences))}) AND (? IS NULL OR jobs.bundle_key = ?) "
            "ORDER BY jobs.created_at DESC, jobs.job_id LIMIT ?",
            (*audiences, bundle_key, bundle_key, max(1, min(limit, 500)))).fetchall()
        return [describe(connection, row) for row in rows]


def cancel(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",)) -> dict[str, Any]:
    with store.write() as connection:
        row = _job(connection, job_id, _visible(connection, audiences))
        now = store.timestamp()
        if row["state"] == "queued":
            connection.execute("UPDATE jobs SET state = 'cancelled', finished_at = ?, updated_at = ? WHERE job_id = ?",
                               (now, now, job_id))
        elif row["state"] == "running":
            connection.execute("UPDATE jobs SET cancel_requested = 1, updated_at = ? WHERE job_id = ?", (now, job_id))
        else:
            raise Refusal("job_finished", f"the job has already ended ({row['state']})", status=409)
        return describe(connection, _job(connection, job_id, None))


def _reopen(connection, store: Store, row, transport: str | None) -> None:
    if row["state"] not in ("cancelled", "partial", "failed"):
        raise Refusal("job_not_resumable", f"a {row['state']} job cannot be resumed", status=409)
    if connection.execute("SELECT 1 FROM jobs WHERE baseline_job_id = ? LIMIT 1", (row["job_id"],)).fetchone():
        raise Refusal("baseline_pinned", "a scenario pins this baseline; submit a new baseline instead", status=409)
    configuration.check(loads(row["configuration"]), row["kind"], row["mode"], transport)
    now = store.timestamp()
    _settle_unrecorded(connection, row["job_id"])
    connection.execute("DELETE FROM results WHERE job_id = ?", (row["job_id"],))
    connection.execute("UPDATE jobs SET state = 'queued', cancel_requested = 0, error = NULL, finished_at = NULL, "
                       "owner = NULL, lease_expires = NULL, updated_at = ? WHERE job_id = ?", (now, row["job_id"]))


def _settle_unrecorded(connection, job_id: str) -> None:
    """Requests still marked sent when their job stops were sent, or may have been: they become ambiguous."""
    outcome = dumps({"code": "ambiguous", "detail": "still marked sent when the job stopped; never resent "
                                                    "automatically"})
    connection.execute("UPDATE attempts SET state = 'ambiguous', outcome = ? WHERE job_id = ? AND state = 'dispatched'",
                       (outcome, job_id))
    connection.execute("UPDATE items SET state = 'ambiguous', outcome = ? WHERE job_id = ? AND state = 'dispatched'",
                       (outcome, job_id))


def resume(store: Store, job_id: str, *, audiences: Sequence[str] = ("public",),
           transport: str | None = None) -> dict[str, Any]:
    """Requeue a stopped job; only work known not to have been sent is done again. `transport` labels the provider
    client that would answer it, which must be the one the job pinned."""
    with store.write() as connection:
        row = _job(connection, job_id, _visible(connection, audiences))
        _reopen(connection, store, row, transport)
        connection.execute("UPDATE items SET state = 'pending', outcome = NULL WHERE job_id = ? AND (state = 'skipped'"
                           " OR (state = 'failed' AND json_extract(outcome, '$.code') = 'not_sent'))", (job_id,))
        return describe(connection, _job(connection, job_id, None))


def retry(store: Store, job_id: str, item_ids: Iterable[str], *, audiences: Sequence[str] = ("public",),
          transport: str | None = None) -> dict[str, Any]:
    """Explicitly redo failed or ambiguous provider work: each item gets a new attempt linked to its previous one, and
    asks again even when another job has an answer to reuse. A late response to the earlier attempt is reconciled as
    a receipt and never becomes the item's answer."""
    item_ids = list(item_ids)
    if not item_ids or len(item_ids) > 1000 or not all(isinstance(i, str) for i in item_ids):
        raise Refusal("invalid_retry", "name the failed or ambiguous items to retry")
    with store.write() as connection:
        row = _job(connection, job_id, _visible(connection, audiences))
        if row["mode"] != "live":
            raise Refusal("invalid_retry", "only live provider work can be retried", status=409)
        items = {item["item_id"]: item for item in connection.execute(
            f"SELECT * FROM items WHERE job_id = ? AND item_id IN ({','.join('?' * len(item_ids))})",
            (job_id, *item_ids))}
        problems = [i for i in item_ids if i not in items or items[i]["state"] not in ("failed", "ambiguous")]
        if problems:
            raise Refusal("invalid_retry", "only failed or ambiguous items of this job can be retried", status=409,
                          problems=problems)
        _reopen(connection, store, row, transport)
        connection.execute("UPDATE items SET state = 'skipped', outcome = ? WHERE job_id = ? AND state = 'pending'",
                           (dumps({"code": "not_retried", "detail": "not named in the retry; resume sends it"}),
                            job_id))
        for item_id, item in items.items():
            connection.execute("UPDATE items SET state = 'pending', retry_of = current_attempt, current_attempt = NULL,"
                               " outcome = NULL WHERE item_id = ?", (item_id,))
        return describe(connection, _job(connection, job_id, None))


# Worker-side transitions. Each checks the claim, so a superseded worker changes nothing.

def claim(store: Store, worker: str, lease_seconds: float, *, job_id: str | None = None) -> Claim | None:
    """Take the oldest ready job (only `job_id` when given): queued, or running with an expired lease."""
    with store.write() as connection:
        now = store.clock()
        row = connection.execute("SELECT * FROM jobs WHERE (state = 'queued' OR (state = 'running' AND "
                                 "lease_expires < ?)) AND (? IS NULL OR job_id = ?) ORDER BY created_at, job_id "
                                 "LIMIT 1", (now, job_id, job_id)).fetchone()
        if row is None:
            return None
        generation = row["generation"] + 1
        connection.execute("UPDATE jobs SET state = 'running', owner = ?, generation = ?, lease_expires = ?, "
                           "updated_at = ? WHERE job_id = ?",
                           (worker, generation, now + lease_seconds, store.timestamp(), row["job_id"]))
        if row["state"] == "running":
            outcome = dumps({"code": "ambiguous", "detail": "dispatched by a worker that stopped before recording "
                                                            "the response; never resent automatically"})
            connection.execute("UPDATE attempts SET state = 'ambiguous', outcome = ? WHERE job_id = ? AND "
                               "state = 'dispatched'", (outcome, row["job_id"]))
            connection.execute("UPDATE items SET state = 'ambiguous', outcome = ? WHERE job_id = ? AND "
                               "state = 'dispatched'", (outcome, row["job_id"]))
        return Claim(row["job_id"], generation, worker)


def _owned(connection, claim: Claim):
    row = connection.execute("SELECT * FROM jobs WHERE job_id = ?", (claim.job_id,)).fetchone()
    if row is None or row["generation"] != claim.generation or row["owner"] != claim.worker \
            or row["state"] != "running":
        return None
    return row


def heartbeat(store: Store, claim: Claim, lease_seconds: float) -> tuple[bool, bool]:
    """Whether the claim still owns the job, and whether cancellation was requested."""
    with store.write() as connection:
        row = _owned(connection, claim)
        if row is None:
            return False, False
        connection.execute("UPDATE jobs SET lease_expires = ? WHERE job_id = ?",
                           (store.clock() + lease_seconds, claim.job_id))
        return True, bool(row["cancel_requested"])


def finalize(store: Store, claim: Claim, state: str, *, result: Mapping[str, Any] | None = None,
             narrative_document: Mapping[str, Any] | None = None, metrics: Mapping[str, Any] | None = None,
             error: Mapping[str, str] | None = None) -> str | None:
    """Commit the terminal state and result together; the state committed, or None when the claim was superseded.
    A cancellation requested before this transaction wins over a result."""
    with store.write() as connection:
        row = _owned(connection, claim)
        if row is None:
            return None
        if row["cancel_requested"]:
            state, result, error = "cancelled", None, None
        _settle_unrecorded(connection, claim.job_id)
        now = store.timestamp()
        if result is not None:
            connection.execute("INSERT OR REPLACE INTO results (job_id, run_id, content_digest, document, "
                               "narrative_document, metrics, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                               (claim.job_id, result["run_id"], result["content_digest"], dumps(result),
                                dumps(narrative_document), dumps(metrics or {}), now))
        _set_terminal(connection, claim.job_id, state, error, now)
        return state


def _set_terminal(connection, job_id: str, state: str, error: Mapping[str, str] | None, now: str) -> None:
    connection.execute("UPDATE jobs SET state = ?, error = ?, finished_at = ?, updated_at = ?, owner = NULL, "
                       "lease_expires = NULL WHERE job_id = ?",
                       (state, None if error is None else dumps(dict(error)), now, now, job_id))
