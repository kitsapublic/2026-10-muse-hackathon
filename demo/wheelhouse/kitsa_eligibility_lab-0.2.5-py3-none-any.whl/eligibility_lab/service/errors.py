"""Bounded refusals: a stable code, a short message, the problems found and the HTTP status they map to."""
from __future__ import annotations

from typing import Iterable

from eligibility_lab.errors import EligibilityError

MAX_PROBLEMS = 50
MAX_TEXT = 300


class Refusal(Exception):
    def __init__(self, code: str, message: str, *, status: int = 422, problems: Iterable[str] = ()):
        self.code = code
        self.message = message[:MAX_TEXT]
        self.status = status
        self.problems = tuple(str(problem)[:MAX_TEXT] for problem in list(problems)[:MAX_PROBLEMS])
        super().__init__(f"{code}: {self.message}")

    @classmethod
    def from_engine(cls, error: EligibilityError, *, status: int = 422) -> "Refusal":
        return cls(error.code, str(error).split(": ", 1)[-1], status=status, problems=error.problems)

    def document(self) -> dict:
        return {"error": {"code": self.code, "message": self.message, "problems": list(self.problems)}}
