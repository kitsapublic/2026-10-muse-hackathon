"""Portable public reference-rule recordings, imported only into a new standalone store.

This is a bounded history export, not a database backup or a general report importer. It carries one successful
public baseline and its direct accepted narrative receipts, reference approvals and result. There are no credentials,
private jobs, unrelated rows or active spending authorization. Imports require a separately trusted file digest;
hashes check integrity, not provider authenticity. The provider request and response are revalidated on import and
again whenever recorded mode uses them. The original source evaluator identity is preserved across service releases.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import sqlite3
import stat
from typing import Any

from eligibility_lab.canonical import canonical_json, digest, strict_loads
from eligibility_lab.errors import EligibilityError
from eligibility_lab.service import configuration, interpretations, jobs, provider, work_items
from eligibility_lab.service.catalog import load_installed
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.store import SCHEMA, Store, dumps, loads

FORMAT = "kitsa/eligibility-lab-recordings/1"
MAX_BYTES = 16 * 1024 * 1024
TABLES = ("proposals", "reviews", "interpretation_sets", "experiments", "jobs", "items", "attempts", "results")
BLOBS = ("request_body", "response_body")


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise Refusal("invalid_recordings", message)


def _one(rows):
    _require(isinstance(rows, list) and len(rows) == 1, "expected one source history row")
    return rows[0]


def _validate(connection, installed, document: dict[str, Any]) -> None:
    """Validate a closed snapshot against the installed public bundle and the running provider contract."""
    _require(isinstance(document, dict) and set(document) == {"format", "schema", "bundle", "tables"},
             "invalid recording envelope")
    _require(document["format"] == FORMAT and type(document["schema"]) is int
             and document["schema"] == len(SCHEMA), "unsupported recording format or store schema")
    _require(document["bundle"] == {"key": installed.key, "manifest_sha256": installed.manifest_sha256},
             "the recording does not bind this exact installed public bundle")
    tables = document["tables"]
    _require(isinstance(tables, dict) and set(tables) == set(TABLES), "unexpected recording history tables")
    for table in TABLES:
        columns = {r["name"] for r in connection.execute(f"PRAGMA table_info({table})")}
        rows = tables[table]
        _require(isinstance(rows, list) and 0 < len(rows) <= 5000, "invalid recording history size")
        for row in rows:
            _require(isinstance(row, dict) and set(row) == columns, "unexpected recording history fields")
            _require(all(v is None or type(v) in (str, int) for v in row.values()), "invalid history field type")
    job, result = _one(tables["jobs"]), _one(tables["results"])
    selected, experiment = _one(tables["interpretation_sets"]), _one(tables["experiments"])
    _require(job["kind"] == "baseline" and job["mode"] == "live" and job["state"] == "succeeded"
             and job["bundle_key"] == installed.key and job["baseline_job_id"] is None
             and job["owner"] is None and job["lease_expires"] is None and job["cancel_requested"] == 0
             and job["error"] is None and job["finished_at"] is not None, "only a finished public live baseline is portable")
    request, pinned = loads(job["request"]), loads(job["configuration"])
    expected = configuration.current("baseline", "live", provider.GENUINE_TRANSPORT)
    _require(isinstance(pinned, dict) and set(pinned) == set(expected)
             and isinstance(pinned["evaluator"], dict) and set(pinned["evaluator"]) == set(expected["evaluator"]),
             "source evaluator identity is missing")
    # Replaying the same provider answers on a new evaluator is a new run; never relabel the old run's evaluator.
    _require({**pinned, "evaluator": expected["evaluator"]} == expected, "provider configuration no longer matches")
    _require(job["fingerprint"] in {digest(jobs.normalize(request)),
                                  digest(jobs.normalize({**request, "evaluation_date": None}))}
             and request["kind"] == "baseline"
             and request["mode"] == "live" and request["bundle_key"] == installed.key
             and request["experiment_id"] == experiment["experiment_id"] == job["experiment_id"],
             "source request or experiment mismatch")
    _require(selected["set_id"] == job["set_id"] and selected["bundle_key"] == installed.key,
             "source interpretation set mismatch")
    members = loads(selected["members"])
    proposals = tables["proposals"]
    _require(len(proposals) == len(members) == len(installed.bundle.criteria.criteria), "incomplete reference review")
    _require({p["proposal_id"] for p in proposals} == set(request["proposal_ids"])
             == {m["proposal_id"] for m in members}, "unexpected proposals")
    for proposal in proposals:
        local = connection.execute("SELECT * FROM proposals WHERE proposal_id = ?", (proposal["proposal_id"],)).fetchone()
        _require(local is not None and proposal["content"] == local["content"]
                 and proposal["origin"] == "reference" and proposal["valid"] == 1
                 and proposal["bundle_key"] == installed.key and proposal["parent_id"] is None
                 and proposal["attempt_id"] is None, "only installed reference proposals may be imported")
    reviews = {r["review_id"]: r for r in tables["reviews"]}
    _require(len(reviews) == len(members) == len(tables["reviews"]), "unexpected reviews")
    for member in members:
        review = reviews.get(member["review_id"])
        _require(review is not None and review["proposal_id"] == member["proposal_id"]
                 and review["decision"] == "approved" and member["origin"] == "reference", "invalid source approval")
    criteria = loads(selected["criteria_document"])
    _require(criteria == installed.documents["criteria"], "only unchanged reviewed reference rules are portable")
    _require(selected["set_id"] == "set-" + digest({"bundle_key": installed.key, "members": members,
                                                   "criteria": criteria})[:24], "interpretation set identity mismatch")
    entries, notes = work_items.narrative_work(installed, criteria, request["evaluation_date"], pinned)
    items, attempts = tables["items"], tables["attempts"]
    _require(len(items) == len(entries) == len(attempts), "recording coverage is incomplete")
    by_attempt = {a["attempt_id"]: a for a in attempts}
    _require(len(by_attempt) == len(attempts), "duplicate attempts")
    decisions = []
    for position, (item, entry) in enumerate(zip(items, entries)):
        _require(item["position"] == position and item["job_id"] == job["job_id"]
                 and item["item_id"] == f"{job['job_id']}.{position}"
                 and all(item[k] == entry[k] for k in ("kind", "item_key", "cache_key"))
                 and loads(item["input"]) == entry["input"] and item["state"] == "answered"
                 and item["retry_of"] is None and item["current_attempt"] == item["answer_attempt"],
                 "source work item does not match the exact bound inputs")
        attempt = by_attempt.get(item["answer_attempt"])
        _require(attempt is not None and attempt["item_id"] == item["item_id"]
                 and attempt["job_id"] == job["job_id"] and attempt["generation"] == job["generation"]
                 and attempt["retry_of"] is None and attempt["experiment_id"] == experiment["experiment_id"]
                 and attempt["transport"] == provider.GENUINE_TRANSPORT
                 and attempt["provider"] == provider.PROVIDER and attempt["model"] == provider.MODEL
                 and loads(attempt["configuration"]) == pinned["provider"] and attempt["http_status"] == 200
                 and attempt["state"] == "completed" and attempt["reservation"] == "settled"
                 and type(attempt["latency_ms"]) is int and attempt["latency_ms"] >= 0
                 and attempt["dispatched_at"] is not None and attempt["completed_at"] is not None
                 and type(attempt["charged_microusd"]) is int and attempt["charged_microusd"] >= 0
                 and attempt["response_headers"] is None, "only direct accepted settled genuine responses are portable")
        built = work_items.request_for("narrative", entry["input"], notes)
        _require(attempt["request_sha256"] == built.sha256 and attempt["request_body"].encode() == built.body,
                 "retained request differs from the reconstructed request")
        outcome = provider.validate_response(built, 200, attempt["response_body"].encode(), {}, attempt["latency_ms"])
        _require(outcome.code == "answered" and dict(outcome.answer) == loads(attempt["answer"])
                 and loads(attempt["usage"]) == outcome.usage and attempt["response_id"] == outcome.response_id
                 and attempt["charged_microusd"] == outcome.charge_microusd
                 and attempt["reserved_microusd"] == built.reserve_microusd,
                 "retained response no longer validates to its accepted answer and usage")
        _require((loads(attempt["outcome"]) or {}).get("code") == "answered"
                 and not (loads(attempt["outcome"]) or {}).get("late")
                 and (loads(item["outcome"]) or {}).get("code") == "answered", "source answer was not accepted")
        spec, answer = entry["input"], outcome.answer
        decisions.append({"decision_id": f"nd-{digest([job['job_id'], item['item_key']])[:24]}",
                          "patient_id": spec["patient_id"], "question_id": spec["question_id"],
                          "evaluation_date": spec["evaluation_date"], "window_days": spec["window_days"],
                          "considered_note_ids": spec["note_ids"], "input_sha256": spec["input_sha256"],
                          "value": answer["value"], "reason": answer["reason"],
                          "supporting_note_ids": answer["supporting_note_ids"]})
    _require(result["job_id"] == job["job_id"]
             and loads(result["narrative_document"])["decisions"] == decisions,
             "source narrative differs from the accepted receipts")
    historical = loads(result["document"])
    _require(historical["run_id"] == result["run_id"] == digest(historical["run"])
             and historical["content_digest"] == result["content_digest"]
             == digest({k: v for k, v in historical.items() if k not in ("execution_metrics", "content_digest")}),
             "source result identity mismatch")
    total = sum(a["charged_microusd"] for a in attempts)
    _require(experiment["enabled"] == 0 and experiment["max_requests"] == len(attempts)
             and experiment["ceiling_microusd"] == max(1, total)
             and experiment["provider"] == provider.PROVIDER and experiment["model"] == provider.MODEL
             and loads(experiment["pricing"]) == {**provider.PRICING, "unit": "micro-USD per million tokens"},
             "the imported source ledger must be disabled and exhausted")


def _export_recordings(store: Store, job_id: str) -> bytes:
    with store.read() as connection:
        row = connection.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
        _require(row is not None, "source job is missing")
        installed = load_installed(store, row["bundle_key"], audiences=("public",))
        selected = connection.execute("SELECT * FROM interpretation_sets WHERE set_id = ?", (row["set_id"],)).fetchone()
        _require(selected is not None, "source interpretation set is missing")
        members = loads(selected["members"])
        tables = {"jobs": [dict(row)], "interpretation_sets": [dict(selected)]}
        for table, field, ids in (("proposals", "proposal_id", [m["proposal_id"] for m in members]),
                                  ("reviews", "review_id", [m["review_id"] for m in members]),
                                  ("experiments", "experiment_id", [row["experiment_id"]])):
            tables[table] = [dict(connection.execute(f"SELECT * FROM {table} WHERE {field} = ?", (i,)).fetchone())
                             for i in ids]
        for table in ("items", "attempts", "results"):
            order = "position" if table == "items" else "attempt_id" if table == "attempts" else "job_id"
            tables[table] = [dict(r) for r in connection.execute(
                f"SELECT * FROM {table} WHERE job_id = ? ORDER BY {order}", (job_id,))]
        for attempt in tables["attempts"]:
            for field in BLOBS:
                _require(isinstance(attempt[field], bytes), "missing retained request or response")
                attempt[field] = attempt[field].decode("utf-8")
            attempt["response_headers"] = None  # Response headers are unnecessary for replay and are not portable.
        experiment = _one(tables["experiments"])
        experiment.update(enabled=0, max_requests=len(tables["attempts"]),
                          ceiling_microusd=max(1, sum(a["charged_microusd"] or 0 for a in tables["attempts"])))
        document = {"format": FORMAT, "schema": len(SCHEMA),
                    "bundle": {"key": installed.key, "manifest_sha256": installed.manifest_sha256}, "tables": tables}
        _validate(connection, installed, document)
    data = canonical_json(document) + b"\n"
    _require(len(data) <= MAX_BYTES, "recording exceeds the portable size limit")
    return data


def export_recordings(store: Store, job_id: str) -> bytes:
    try:
        return _export_recordings(store, job_id)
    except Refusal:
        raise
    except (ValueError, TypeError, KeyError, AttributeError, RecursionError, EligibilityError, sqlite3.Error):
        raise Refusal("invalid_recordings", "only a complete direct public reference-rule baseline is portable") from None


def import_recordings(store: Store, path: Path, expected_sha256: str) -> dict[str, Any]:
    """Atomically initialize recording history; a repeated identical import never reapproves or overwrites work."""
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as handle:
            info = os.fstat(handle.fileno())
            _require(stat.S_ISREG(info.st_mode) and info.st_size <= MAX_BYTES, "recording must be a bounded regular file")
            data = handle.read(MAX_BYTES + 1)
        identity = hashlib.sha256(data).hexdigest()
        _require(len(data) <= MAX_BYTES and identity == expected_sha256, "recording SHA-256 mismatch")
        document = strict_loads(data)
        installed = load_installed(store, document["bundle"]["key"], audiences=("public",))
        with store.write() as connection:
            _validate(connection, installed, document)
            key = "recording:" + identity
            existing = connection.execute("SELECT value FROM store_info WHERE key = ?", (key,)).fetchone()
            source = _one(document["tables"]["jobs"])["job_id"]
            if existing is not None:
                _require(existing["value"] == source, "recording receipt mismatch")
                return {"sha256": identity, "source_job_id": source, "imported": False}
            for table in TABLES[1:]:
                _require(connection.execute(f"SELECT 1 FROM {table} LIMIT 1").fetchone() is None,
                         "recordings initialize a new store; choose a fresh store to preserve existing work")
            _require(connection.execute("SELECT COUNT(*) FROM bundles").fetchone()[0] == 1,
                     "recordings initialize a store containing only their public bundle")
            _require(connection.execute("SELECT COUNT(*) FROM proposals").fetchone()[0]
                     == len(document["tables"]["proposals"]), "existing interpretations must not be replaced")
            connection.execute("PRAGMA defer_foreign_keys = ON")
            for table in TABLES[1:]:  # Installed reference proposals are already identical; keep their local rows.
                for raw in document["tables"][table]:
                    row = dict(raw)
                    if table == "attempts":
                        for field in BLOBS:
                            row[field] = row[field].encode("utf-8")
                    names = list(row)
                    connection.execute(f"INSERT INTO {table} ({','.join(names)}) VALUES ({','.join('?' for _ in names)})",
                                       [row[n] for n in names])
            source_set = _one(document["tables"]["interpretation_sets"])
            resolved = interpretations.resolve_set(connection, installed,
                                                   [p["proposal_id"] for p in document["tables"]["proposals"]])
            _require(resolved["set_id"] == source_set["set_id"], "imported reviews do not reproduce the source set")
            _require(not connection.execute("PRAGMA foreign_key_check").fetchall(), "broken recording history references")
            connection.execute("INSERT INTO store_info (key, value) VALUES (?, ?)", (key, source))
        return {"sha256": identity, "source_job_id": source, "imported": True}
    except Refusal:
        raise
    except (OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError, EligibilityError, sqlite3.Error):
        raise Refusal("invalid_recordings", "malformed or incompatible recording; no history was imported") from None
