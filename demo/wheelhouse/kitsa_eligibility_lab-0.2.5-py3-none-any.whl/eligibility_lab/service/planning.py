"""No-spend request plans, using the worker's request construction and response-reuse checks.

A plan creates no job, interpretation set, receipt or reservation. Its identity pins inputs, reviewed interpretations,
date and configuration; cache availability and ledger headroom are observations that may change before execution.
"""
from __future__ import annotations

from typing import Any, Sequence

from eligibility_lab.canonical import digest
from eligibility_lab.service import configuration, interpretations, ledger, provider, work_items
from eligibility_lab.service.catalog import AUDIENCES, load_installed
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.store import Store


def choose_proposals(store: Store, bundle_key: str) -> list[str]:
    """Latest approved proposal per criterion, falling back to the reference proposal for the review refusal."""
    chosen = {}
    for proposal in interpretations.list_proposals(store, bundle_key):
        approved = proposal['review'] is not None and proposal['review']['decision'] == 'approved'
        if approved or (proposal['origin'] == 'reference' and proposal['criterion_id'] not in chosen):
            chosen[proposal['criterion_id']] = proposal['proposal_id']
    return list(chosen.values())


def plan(store: Store, bundle_key: str, *, task: str = 'baseline', mode: str = 'live',
         proposal_ids: Sequence[str] | None = None, criterion_ids: Sequence[str] | None = None,
         experiment_id: str | None = None, retry: bool = False,
         transport: str = provider.GENUINE_TRANSPORT) -> dict[str, Any]:
    if task not in ('baseline', 'interpretation') or mode not in ('reference', 'live', 'recorded') \
            or (task == 'interpretation' and mode != 'live'):
        raise Refusal('invalid_plan', 'interpretation plans are live; baseline plans are reference, live or recorded')
    if task == 'baseline' and (criterion_ids is not None or retry):
        raise Refusal('invalid_plan', '--criterion and --retry apply only to interpretation plans')
    installed = load_installed(store, bundle_key, audiences=AUDIENCES)
    pinned = configuration.current(task, mode, transport)
    evaluation_date = installed.bundle.reference_date.isoformat()
    resolved, notes = None, {}
    if task == 'baseline':
        ids = choose_proposals(store, bundle_key) if proposal_ids is None else list(proposal_ids)
        with store.read() as connection:
            resolved = interpretations.resolve_set(connection, installed, ids)
        entries, notes = ([], {}) if mode == 'reference' else work_items.narrative_work(
            installed, resolved['criteria_document'], evaluation_date, pinned)
    else:
        ids = sorted(criterion_ids if criterion_ids is not None else
                     [c['criterion_id'] for c in installed.documents['criteria']['criteria']])
        if not ids or len(set(ids)) != len(ids):
            raise Refusal('invalid_plan', 'name distinct criteria to interpret')
        entries = work_items.interpretation_work(installed, ids, pinned)
    requests = []
    available = []
    for entry in entries:
        try:
            request = work_items.request_for(entry['kind'], entry['input'], notes)
        except ValueError as exc:
            raise Refusal('request_too_large', str(exc)) from None
        requests.append({'item_key': entry['item_key'], 'cache_key': entry['cache_key'],
                         'request_sha256': request.sha256, 'body_bytes': len(request.body),
                         'reserve_microusd': request.reserve_microusd})
        source = None if retry else work_items.reusable(work_items.sources(
            store, installed.audience, entry['cache_key'], pinned['transport']), request)
        available.append(source is not None)
    identity = {'bundle_key': bundle_key, 'manifest_sha256': installed.manifest_sha256,
                'evaluation_date': evaluation_date, 'task': task, 'mode': mode, 'retry': retry,
                'set_id': None if resolved is None else resolved['set_id'], 'configuration': pinned,
                'requests': requests}
    required = [r for r, cached in zip(requests, available) if not cached]
    maximum = sum(r['reserve_microusd'] for r in requests) if mode == 'live' else 0
    uncached = sum(r['reserve_microusd'] for r in required) if mode == 'live' else 0
    budget = None if experiment_id is None else ledger.summary(store, experiment_id)
    return {'format': 'kitsa/eligibility-lab-request-plan/1', 'plan_sha256': digest(identity), **identity,
            'configuration_sha256': digest(pinned), 'items': len(requests), 'reusable_answers': sum(available),
            'missing_recordings': len(required) if mode == 'recorded' else 0,
            'maximum_requests': len(requests) if mode == 'live' else 0,
            'uncached_requests': len(required) if mode == 'live' else 0,
            'maximum_reservation_microusd': maximum, 'uncached_reservation_microusd': uncached,
            'budget': budget, 'fits_current_limits': None if budget is None else (
                uncached <= budget['remaining_microusd'] and
                (len(required) if mode == 'live' else 0) + budget['requests'] <= budget['max_requests']),
            'note': 'No request sent or credit reserved. Reservations use the configured rates and template '
                    'allowance; provider billing is unverified. Recheck before execution.'}
