"""Request construction shared by the durable worker and the no-spend planner."""
from __future__ import annotations

from datetime import date
from typing import Any, Mapping, Sequence

from eligibility_lab.model import parse_bundle
from eligibility_lab.narrative import narrative_inputs
from eligibility_lab.service import provider
from eligibility_lab.service.catalog import Installed
from eligibility_lab.service.interpretations import criterion_pin
from eligibility_lab.service.jobs import empty_model_narrative, job_documents
from eligibility_lab.service.store import Store, loads


def reusable(sources, request: provider.ProviderRequest):
    """The first accepted source whose retained request is `request` and whose retained response still validates to
    the answer it gave, or None."""
    for source in sources:
        if source["request_sha256"] != request.sha256 or source["answer"] is None:
            continue
        replayed = provider.validate_response(request, 200, source["response_body"] or b"", {}, 0)
        if replayed.code == "answered" and dict(replayed.answer) == loads(source["answer"]):
            return source
    return None


def conventions(installed: Installed) -> list[str]:
    """Protocol passages that are not a criterion's own text: section headings and assessment conventions."""
    anchors = {c["source"]["anchor"] for c in installed.documents["criteria"]["criteria"]}
    return [p["text"] for p in installed.documents["protocol"]["passages"]
            if p["anchor"] not in anchors and p["anchor"] != "title"]


def narrative_work(installed: Installed, criteria_document: Mapping[str, Any], evaluation_date: str,
                   pinned: Mapping[str, Any]):
    bundle = parse_bundle(job_documents(installed, criteria_document, empty_model_narrative()))
    inputs = narrative_inputs(bundle.criteria, bundle.cohort, date.fromisoformat(evaluation_date))
    notes = {n.note_id: n for p in bundle.cohort.patients for n in p.notes}
    entries = [{"kind": "narrative", "item_key": f"{i.patient_id}|{i.question_id}|{i.window_days}",
                "cache_key": provider.narrative_cache_key(i.input_sha256, pinned["provider"], pinned["transport"]),
                "input": {"patient_id": i.patient_id, "question_id": i.question_id, "statement": i.statement,
                          "evaluation_date": i.evaluation_date.isoformat(), "window_days": i.window_days,
                          "note_ids": [n.note_id for n in i.notes], "input_sha256": i.input_sha256}}
               for i in inputs]
    return entries, notes


def interpretation_work(installed: Installed, criterion_ids: Sequence[str], pinned: Mapping[str, Any]):
    passages = conventions(installed)
    entries = []
    for criterion_id in criterion_ids:
        pin = criterion_pin(installed, criterion_id)
        names = sorted(name for (criterion, name) in installed.policy if criterion == criterion_id)
        entries.append({"kind": "interpretation", "item_key": criterion_id,
                        "cache_key": provider.interpretation_cache_key(pin, passages, names, pinned["provider"],
                                                                       pinned["transport"]),
                        "input": {"criterion": pin, "conventions": passages, "parameter_names": names}})
    return entries


def request_for(kind: str, spec: Mapping[str, Any], notes: Mapping[str, Any] | None = None):
    if kind == "interpretation":
        return provider.interpretation_request(spec["criterion"], spec["conventions"],
                                               {name: "scenario-editable threshold"
                                                for name in spec["parameter_names"]})
    first = date.fromisoformat(spec["evaluation_date"]).toordinal() - spec["window_days"]
    return provider.narrative_request(
        spec["statement"], spec["evaluation_date"], date.fromordinal(first).isoformat(),
        [{"note_id": n, "written_on": notes[n].written_on.isoformat(), "text": notes[n].text}
         for n in spec["note_ids"]])


def sources(store: Store, audience: str, cache_key: str, transport: str):
    """Accepted answers from pinned jobs of the same audience and transport, earliest first."""
    with store.read() as connection:
        return connection.execute(
            "SELECT DISTINCT attempts.* FROM items JOIN attempts ON attempts.attempt_id = items.answer_attempt "
            "JOIN jobs ON jobs.job_id = attempts.job_id JOIN bundles ON bundles.bundle_key = jobs.bundle_key "
            "WHERE items.cache_key = ? AND attempts.transport = ? AND bundles.audience = ? AND "
            "jobs.configuration IS NOT NULL ORDER BY attempts.completed_at, attempts.attempt_id",
            (cache_key, transport, audience)).fetchall()
