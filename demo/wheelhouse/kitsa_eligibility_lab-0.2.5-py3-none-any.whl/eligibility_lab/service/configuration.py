"""The configuration a job pins when it is accepted, and the check that whatever runs it still matches.

A job's configuration names everything that decides its answers and its cost: the evaluator (the engine's name and
version) and, for model work, the provider request configuration (provider, endpoint, model, reasoning, token limit,
prompt, schema and adapter version), the transport that answers (the genuine API or a synthetic test fixture) and the
accounting (prices and the chat-template allowance). A reference job pins only the evaluator. A recorded job pins the
genuine transport and no accounting, because it spends nothing. A scenario pins its baseline's configuration.

Execution, resume, retry, recorded replay and comparison compare the pinned configuration with the running service's
and refuse any difference, so retained answers are never relabelled with another configuration. Work under a changed
release needs a new job.
"""
from __future__ import annotations

import json
from typing import Any, Mapping

from eligibility_lab import run
from eligibility_lab.service import provider
from eligibility_lab.service.errors import Refusal

FORMAT = "kitsa/eligibility-lab-configuration/1"


def current(kind: str, mode: str, transport: str | None) -> dict[str, Any]:
    """The configuration a baseline or interpretation job of this mode pins now, answered through `transport`."""
    model = kind == "interpretation" or mode in ("live", "recorded")
    live = mode == "live"
    return {"format": FORMAT, "evaluator": dict(run.EVALUATOR),
            "provider": provider.configuration("interpretation" if kind == "interpretation" else "narrative")
            if model else None,
            "transport": (transport if live else provider.GENUINE_TRANSPORT) if model else None,
            "accounting": {"pricing": dict(provider.PRICING),
                           "template_allowance_tokens": provider.TEMPLATE_ALLOWANCE_TOKENS} if live else None}


def _text(value: Any) -> str:
    if value is None:
        return "none"
    return (json.dumps(value, sort_keys=True) if isinstance(value, (dict, list)) else str(value))[:80]


def differences(pinned: Mapping[str, Any], now: Mapping[str, Any], path: str = "") -> list[str]:
    problems = []
    for key in sorted(set(pinned) | set(now)):
        before, after = pinned.get(key), now.get(key)
        if isinstance(before, dict) and isinstance(after, dict):
            problems += differences(before, after, f"{path}{key}.")
        elif before != after:
            problems.append(f"{path}{key}: pinned {_text(before)}, now {_text(after)}")
    return problems


def check(pinned: Mapping[str, Any] | None, kind: str, mode: str, transport: str | None) -> None:
    """Refuse unless a service answering through `transport` runs exactly the configuration `pinned`."""
    if pinned is None:
        raise Refusal("configuration_unpinned", "the job was accepted before configurations were pinned; it is kept as "
                                                "history and cannot run again; submit a new job", status=409)
    if kind == "scenario":  # A scenario sends nothing; its engine must be its baseline's.
        now = {**pinned, "evaluator": dict(run.EVALUATOR)}
    else:
        if mode == "live" and transport is None:
            raise Refusal("live_mode_unavailable", "the service has no provider client; live mode is disabled",
                          status=409)
        now = current(kind, mode, transport)
    problems = differences(pinned, now)
    if problems:
        raise Refusal("configuration_changed", "the service no longer runs the configuration this job pinned; submit "
                                               "a new job", status=409, problems=problems)
