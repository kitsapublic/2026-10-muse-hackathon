"""Eligibility Lab's optional local service: installed bundles, reviewed interpretations, durable jobs, the Muse
provider adapter with its request and cost ledger, exports and the `/v1` HTTP API.

Installed with the `service` extra. The calculation core never imports this package; this package calls the core for
every validation and calculation and never reimplements eligibility logic.
"""
