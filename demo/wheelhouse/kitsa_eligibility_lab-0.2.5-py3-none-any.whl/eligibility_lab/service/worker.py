"""The local worker: claims jobs, does their provider work with bounded concurrency, runs the engine and commits the
result with the terminal state.

Reference jobs read the installed bundle's authored narrative decisions. A live baseline asks the model one narrative
question per patient, question and window that has notes, supplying every note inside the window; a recorded baseline
revalidates retained genuine responses for exactly the same requests instead of sending them. Either way the server
builds each narrative decision's binding from the notes it supplied, and the engine evaluates the result: model work
that failed leaves its cells as execution failures, never as clinical answers. A scenario job never asks the model: it
reruns the engine on its baseline's narrative decisions with the edited thresholds.

A job runs only on the configuration it pinned (see `configuration`); anything else fails it before any work. Before
each request the worker confirms it still owns the job and cancellation was not requested, and records the receipt and
cost reservation in one transaction. A response is accepted only in the transaction that confirms the claim still owns
the job and the attempt is still the item's dispatched attempt: the item then references that attempt, whose
validated answer it uses from then on. A response that arrives later, after its job was reclaimed or retried, is still
reconciled in the ledger and retained, but it answers nothing, proposes nothing and is never reused.

Reuse never chooses a result afterwards: an item is settled once from an answer some item already accepted, for the
same request key (the bound inputs, the pinned request configuration and the transport), from a pinned job of the same
audience and transport, earliest first, after its retained request and response are checked to reproduce that answer.
Live work reuses such answers instead of asking again, except an explicit retry, which always asks again; recorded
mode accepts only genuine ones.
"""
from __future__ import annotations

from concurrent.futures import FIRST_COMPLETED, Future, ThreadPoolExecutor, wait
from dataclasses import replace
from datetime import date
import logging
import secrets
import statistics
import threading
import time
from typing import Any, Mapping

from eligibility_lab.canonical import digest
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import BASELINE, FORMATS, Edit, parse_bundle
from eligibility_lab.run import DEFAULT_WORKSPACE, DecisionCache, evaluate
from eligibility_lab.service import configuration, jobs, provider, work_items
from eligibility_lab.service.catalog import AUDIENCES, Installed, load_installed
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.interpretations import (current_set_reviews, namespace_rule,
                                                     namespaced_questions, proposal_content, record_proposal)
from eligibility_lab.service.jobs import job_documents
from eligibility_lab.service.ledger import refusal_to_reserve
from eligibility_lab.service.store import Store, dumps, loads, new_id

log = logging.getLogger("eligibility_lab.service")


class _Stopped(Exception):
    """The claim was superseded or the job was cancelled; the worker stops without finalizing a result."""


class Worker:
    def __init__(self, store: Store, *, client: Any = None, concurrency: int = 4, lease_seconds: float = 30.0,
                 poll_seconds: float = 0.25, worker_id: str | None = None):
        if not 1 <= concurrency <= 16:
            raise ValueError("provider concurrency must be from 1 to 16")
        self.store = store
        self.client = client
        self.concurrency = concurrency
        self.lease_seconds = lease_seconds
        self.heartbeat_seconds = max(0.05, lease_seconds / 4)
        self.poll_seconds = poll_seconds
        self.worker_id = worker_id or f"worker-{secrets.token_hex(6)}"
        self.cache = DecisionCache()
        self._stop = threading.Event()
        self._wake = threading.Event()
        self._thread: threading.Thread | None = None

    # Lifecycle ---------------------------------------------------------------------------------------------------

    def start(self) -> None:
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, name="eligibility-lab-worker", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 30.0) -> None:
        self._stop.set()
        self._wake.set()
        if self._thread is not None:
            self._thread.join(timeout)

    def wake(self) -> None:
        self._wake.set()

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                worked = self.run_once()
            except Exception:
                log.exception("worker step failed")
                worked = False
            if not worked:
                self._wake.wait(self.poll_seconds)
                self._wake.clear()

    def run_once(self, job_id: str | None = None) -> bool:
        """Claim and process one job (only `job_id` when given); False when none is ready."""
        if self._stop.is_set():
            return False
        claim = jobs.claim(self.store, self.worker_id, self.lease_seconds, job_id=job_id)
        if claim is None:
            return False
        self._process(claim)
        return True

    def run_until_idle(self, limit: int = 1000, *, job_id: str | None = None) -> int:
        processed = 0
        while processed < limit and self.run_once(job_id):
            processed += 1
        return processed

    # Jobs --------------------------------------------------------------------------------------------------------

    def _process(self, claim: jobs.Claim) -> None:
        started = time.monotonic()
        with self.store.read() as connection:
            job = connection.execute("SELECT jobs.*, bundles.audience FROM jobs JOIN bundles USING (bundle_key) "
                                     "WHERE job_id = ?", (claim.job_id,)).fetchone()
        request = loads(job["request"])
        try:
            pinned = loads(job["configuration"])
            configuration.check(pinned, job["kind"], job["mode"],
                                None if self.client is None else self.client.transport_label)
            installed = load_installed(self.store, job["bundle_key"], audiences=AUDIENCES)
            if job["kind"] == "interpretation":
                self._interpret(claim, job, pinned, request, installed)
                return
            with self.store.read() as connection:
                stale = current_set_reviews(connection, job["set_id"])
                criteria_document = loads(connection.execute(
                    "SELECT criteria_document FROM interpretation_sets WHERE set_id = ?",
                    (job["set_id"],)).fetchone()["criteria_document"])
                baseline = None if job["kind"] != "scenario" else connection.execute(
                    "SELECT narrative_document FROM results WHERE job_id = ?", (job["baseline_job_id"],)).fetchone()
            if stale:  # Review is required before execution, not only before submission.
                raise Refusal("interpretation_review_changed", "an interpretation was reviewed again after this job "
                              "was submitted; submit a new job", status=409, problems=stale)
            provider_metrics: dict[str, Any] = {}
            items_complete = True
            if job["kind"] == "scenario":
                if baseline is None:
                    raise Refusal("baseline_not_ready", "the baseline has no committed result", status=409)
                narrative_document = loads(baseline["narrative_document"])
            elif job["mode"] == "reference":
                narrative_document = dict(installed.documents["narrative"])
            else:
                narrative_document, items_complete, provider_metrics = self._model_narrative(
                    claim, job, pinned, request, installed, criteria_document)
            documents = job_documents(installed, criteria_document, narrative_document)
            bundle = parse_bundle(documents)
            evaluation_date = date.fromisoformat(request["evaluation_date"])
            if job["kind"] == "scenario" and request["scenario_id"] is not None:
                result = evaluate(bundle, scenario=request["scenario_id"], evaluation_date=evaluation_date,
                                  workspace=DEFAULT_WORKSPACE, cache=self.cache)
            elif job["kind"] == "scenario":
                result = evaluate(bundle, edits=[Edit(e["criterion_id"], e["parameter"], e["value"])
                                                 for e in request["edits"]],
                                  author=request["operator"], evaluation_date=evaluation_date,
                                  workspace=DEFAULT_WORKSPACE, cache=self.cache)
            else:
                result = evaluate(bundle, scenario=BASELINE, evaluation_date=evaluation_date,
                                  workspace=DEFAULT_WORKSPACE, cache=self.cache)
            state = "succeeded" if items_complete and result["coverage"]["complete"] else "partial"
            metrics = {"processing_ms": int((time.monotonic() - started) * 1000),
                       "engine": result["execution_metrics"], "provider": provider_metrics or None}
            jobs.finalize(self.store, claim, state, result=result, narrative_document=narrative_document,
                          metrics=metrics)
        except _Stopped:
            jobs.finalize(self.store, claim, "cancelled")
        except Refusal as exc:
            jobs.finalize(self.store, claim, "failed", error=exc.document()["error"])
        except EligibilityError as exc:
            jobs.finalize(self.store, claim, "failed", error={"code": exc.code, "message": str(exc)[:300]})
        except Exception as exc:
            log.exception("job %s failed", claim.job_id)
            jobs.finalize(self.store, claim, "failed",
                          error={"code": "internal_error", "message": type(exc).__name__})

    def _items(self, claim: jobs.Claim, entries: list[dict[str, Any]]) -> list[Any]:
        """The job's work items, created on its first claim."""
        with self.store.write() as connection:
            if jobs._owned(connection, claim) is None:
                raise _Superseded()
            existing = connection.execute("SELECT * FROM items WHERE job_id = ? ORDER BY position",
                                          (claim.job_id,)).fetchall()
            if existing:
                return existing
            for position, entry in enumerate(entries):
                connection.execute("INSERT INTO items (item_id, job_id, position, kind, item_key, cache_key, input, "
                                   "state, retry_of) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)",
                                   (f"{claim.job_id}.{position}", claim.job_id, position, entry["kind"],
                                    entry["item_key"], entry["cache_key"], dumps(entry["input"]),
                                    entry.get("retry_of")))
            return connection.execute("SELECT * FROM items WHERE job_id = ? ORDER BY position",
                                      (claim.job_id,)).fetchall()

    def _model_narrative(self, claim: jobs.Claim, job, pinned: Mapping[str, Any], request: Mapping[str, Any],
                         installed: Installed, criteria_document: Mapping[str, Any]
                         ) -> tuple[dict[str, Any], bool, dict[str, Any]]:
        entries, notes = work_items.narrative_work(installed, criteria_document, request["evaluation_date"], pinned)
        items = self._items(claim, entries)

        def request_for(item) -> provider.ProviderRequest:
            return work_items.request_for("narrative", loads(item["input"]), notes)

        if job["mode"] == "recorded":
            self._replay(claim, job, pinned, items, request_for)
        else:
            self._dispatch(claim, job, pinned, items, request_for, reuse=True)
        with self.store.read() as connection:  # Each answered item's own accepted answer, never a lookup by key.
            settled = connection.execute(
                "SELECT items.*, attempts.answer FROM items LEFT JOIN attempts ON attempts.attempt_id = "
                "items.answer_attempt WHERE items.job_id = ? ORDER BY items.position", (claim.job_id,)).fetchall()
        decisions = []
        for item in settled:
            if item["state"] != "answered" or item["answer"] is None:
                continue
            spec, answer = loads(item["input"]), loads(item["answer"])
            decisions.append({"decision_id": f"nd-{digest([claim.job_id, item['item_key']])[:24]}",
                              "patient_id": spec["patient_id"], "question_id": spec["question_id"],
                              "evaluation_date": spec["evaluation_date"], "window_days": spec["window_days"],
                              "considered_note_ids": spec["note_ids"], "value": answer["value"],
                              "reason": answer["reason"], "supporting_note_ids": answer["supporting_note_ids"],
                              "input_sha256": spec["input_sha256"]})
        settings = pinned["provider"]
        narrative_document = {"format": FORMATS["narrative"], "decisions": decisions, "source": {
            "kind": "model",
            "description": (f"{'Recorded' if job['mode'] == 'recorded' else 'Live'} narrative decisions from "
                            f"{settings['model']} ({settings['provider']}), reasoning {settings['reasoning_effort']},"
                            f" prompt {settings['prompt'][:16]}, schema {settings['schema'][:16]}, adapter "
                            f"{settings['adapter']}, transport {pinned['transport']}; validated locally and bound to "
                            "the notes supplied.")}}
        complete = all(item["state"] == "answered" for item in settled)
        return narrative_document, complete, self._provider_metrics(claim.job_id, settled)

    def _provider_metrics(self, job_id: str, items) -> dict[str, Any]:
        with self.store.read() as connection:
            attempts = connection.execute("SELECT * FROM attempts WHERE job_id = ?", (job_id,)).fetchall()
        latencies = sorted(a["latency_ms"] for a in attempts if a["latency_ms"] is not None)
        usage = [loads(a["usage"]) for a in attempts if a["usage"] is not None]
        states = [item["state"] for item in items]
        return {"items": len(states), **{state: states.count(state) for state in
                                         ("answered", "failed", "ambiguous", "skipped", "pending")},
                "requests": sum(a["state"] != "not_sent" for a in attempts),
                "charged_microusd": sum(a["charged_microusd"] or 0 for a in attempts if a["reservation"] == "settled"),
                "held_microusd": sum(a["reserved_microusd"] for a in attempts if a["reservation"] == "held"),
                "tokens": {key: sum(u.get(key) or 0 for u in usage)
                           for key in ("prompt_tokens", "completion_tokens", "reasoning_tokens", "cached_tokens")},
                "latency_ms": None if not latencies else {
                    "median": int(statistics.median(latencies)), "max": latencies[-1],
                    "p95": latencies[max(0, -(-95 * len(latencies) // 100) - 1)]}}

    def _interpret(self, claim: jobs.Claim, job, pinned: Mapping[str, Any], request: Mapping[str, Any],
                   installed: Installed) -> None:
        entries = work_items.interpretation_work(installed, request["criterion_ids"], pinned)
        if request["retry"]:  # An explicit retry links each new attempt to the accepted answer it asks again for.
            for entry in entries:
                previous = work_items.sources(self.store, job["audience"], entry["cache_key"], pinned["transport"])
                entry["retry_of"] = previous[0]["attempt_id"] if previous else None
        items = self._items(claim, entries)

        def request_for(item) -> provider.ProviderRequest:
            return work_items.request_for("interpretation", loads(item["input"]))

        self._dispatch(claim, job, pinned, items, request_for, reuse=not request["retry"], installed=installed)
        with self.store.read() as connection:
            states = [row["state"] for row in connection.execute("SELECT state FROM items WHERE job_id = ?",
                                                                 (claim.job_id,))]
            provider_metrics = self._provider_metrics(claim.job_id, connection.execute(
                "SELECT * FROM items WHERE job_id = ?", (claim.job_id,)).fetchall())
        jobs.finalize(self.store, claim, "succeeded" if all(s == "answered" for s in states) else "partial",
                      metrics={"provider": provider_metrics})

    # Provider work -----------------------------------------------------------------------------------------------

    def _check(self, claim: jobs.Claim) -> None:
        owned, cancelled = jobs.heartbeat(self.store, claim, self.lease_seconds)
        if not owned:
            raise _Superseded()
        if cancelled or self._stop.is_set():
            raise _Stopped()

    def _replay(self, claim: jobs.Claim, job, pinned: Mapping[str, Any], items, request_for) -> None:
        for item in items:
            if item["state"] != "pending":
                continue
            self._check(claim)
            request = request_for(item)
            sources = work_items.sources(self.store, job["audience"], item["cache_key"], pinned["transport"])
            source = work_items.reusable(sources, request)
            if source is not None:
                self._accept(claim, item, source["attempt_id"], "replayed")
                continue
            outcome = ({"code": "recording_mismatch", "detail": "the retained request or response does not "
                                                                "reproduce this answer"} if sources else
                       {"code": "recording_missing", "detail": "no genuine retained response for this request"})
            with self.store.write() as connection:
                if jobs._owned(connection, claim) is None:
                    raise _Superseded()
                connection.execute("UPDATE items SET state = 'failed', outcome = ? WHERE item_id = ? AND "
                                   "state = 'pending'", (dumps(outcome), item["item_id"]))

    def _accept(self, claim: jobs.Claim, item, attempt_id: str, code: str) -> None:
        """Settle a pending item from another job's accepted answer, referencing that attempt."""
        with self.store.write() as connection:
            if jobs._owned(connection, claim) is None:
                raise _Superseded()
            connection.execute("UPDATE items SET state = 'answered', answer_attempt = ?, outcome = ? WHERE "
                               "item_id = ? AND state = 'pending'",
                               (attempt_id, dumps({"code": code, "detail": "", "attempt_id": attempt_id}),
                                item["item_id"]))

    def _dispatch(self, claim: jobs.Claim, job, pinned: Mapping[str, Any], items, request_for, *, reuse: bool,
                  installed: Installed | None = None) -> None:
        pending = [item for item in items if item["state"] == "pending"]
        stop_code: str | None = None
        in_flight: set[Future] = set()

        def settle(done: set[Future]) -> None:
            nonlocal stop_code
            for future in done:
                outcome = future.result()  # Re-raises a crash of the sending thread.
                if outcome is not None and outcome.stop_dispatch and stop_code is None:
                    stop_code = f"stopped_after_{outcome.code}"

        with ThreadPoolExecutor(self.concurrency, thread_name_prefix="eligibility-lab-provider") as pool:
            try:
                for item in pending:
                    while len(in_flight) >= self.concurrency:
                        done, in_flight = wait(in_flight, timeout=self.heartbeat_seconds,
                                               return_when=FIRST_COMPLETED)
                        settle(done)
                        self._check(claim)
                    self._check(claim)
                    if stop_code is not None:
                        break
                    try:
                        request = request_for(item)
                    except ValueError as exc:
                        self._fail_item(claim, item, "request_too_large", str(exc))
                        continue
                    if dict(request.configuration) != pinned["provider"]:
                        raise Refusal("configuration_changed", "the service's configuration changed during the run; "
                                      "submit a new job", status=409, problems=configuration.differences(
                                          pinned["provider"], request.configuration, "provider."))
                    if reuse and item["retry_of"] is None:  # An explicit retry always asks again.
                        source = work_items.reusable(work_items.sources(self.store, job["audience"], item["cache_key"], pinned["transport"]), request)
                        if source is not None:
                            self._accept(claim, item, source["attempt_id"], "cached")
                            continue
                    status, attempt_id = self._reserve(claim, job, item, request)
                    if status == "dispatched":
                        in_flight.add(pool.submit(self._send, claim, item, attempt_id, request, installed))
                    elif status != "not_pending":  # A budget or request-limit refusal stops further dispatch.
                        stop_code = status
                        break
            finally:
                while in_flight:
                    done, in_flight = wait(in_flight, timeout=self.heartbeat_seconds, return_when=FIRST_COMPLETED)
                    jobs.heartbeat(self.store, claim, self.lease_seconds)
                    settle(done)
        if stop_code is not None:
            with self.store.write() as connection:
                if jobs._owned(connection, claim) is not None:
                    connection.execute("UPDATE items SET state = 'skipped', outcome = ? WHERE job_id = ? AND "
                                       "state = 'pending'",
                                       (dumps({"code": stop_code, "detail": "not sent"}), claim.job_id))
        self._check(claim)

    def _fail_item(self, claim: jobs.Claim, item, code: str, detail: str) -> None:
        with self.store.write() as connection:
            if jobs._owned(connection, claim) is not None:
                connection.execute("UPDATE items SET state = 'failed', outcome = ? WHERE item_id = ?",
                                   (dumps({"code": code, "detail": detail[:300]}), item["item_id"]))

    def _reserve(self, claim: jobs.Claim, job, item, request: provider.ProviderRequest) -> tuple[str, str | None]:
        """Record the receipt and reservation and mark the item dispatched, or say why not."""
        with self.store.write() as connection:
            row = jobs._owned(connection, claim)
            if row is None:
                raise _Superseded()
            if row["cancel_requested"] or self._stop.is_set():
                raise _Stopped()
            current = connection.execute("SELECT state, retry_of FROM items WHERE item_id = ?",
                                         (item["item_id"],)).fetchone()
            if current["state"] != "pending":
                return "not_pending", None
            refusal = refusal_to_reserve(connection, job["experiment_id"], request.reserve_microusd)
            if refusal is not None:
                return refusal, None
            attempt_id = new_id("att")
            connection.execute(
                "INSERT INTO attempts (attempt_id, item_id, job_id, generation, retry_of, experiment_id, transport, "
                "provider, model, configuration, request_sha256, request_body, reserved_microusd, reservation, state,"
                " dispatched_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'held', 'dispatched', ?)",
                (attempt_id, item["item_id"], claim.job_id, claim.generation, current["retry_of"],
                 job["experiment_id"], self.client.transport_label, provider.PROVIDER, provider.MODEL,
                 dumps(dict(request.configuration)), request.sha256, request.body, request.reserve_microusd,
                 self.store.timestamp()))
            connection.execute("UPDATE items SET state = 'dispatched', current_attempt = ? WHERE item_id = ?",
                               (attempt_id, item["item_id"]))
            return "dispatched", attempt_id

    def _send(self, claim: jobs.Claim, item, attempt_id: str, request: provider.ProviderRequest,
              installed: Installed | None) -> provider.Outcome:
        """Send, then always reconcile the attempt: a response that cannot be checked is a failed answer with its
        cost kept, and one that cannot be recorded leaves the request ambiguous and reserved."""
        try:
            outcome = self.client.send(request)
        except Exception as exc:  # Anything after the request may have left is ambiguous.
            outcome = provider.Outcome("ambiguous", "ambiguous", f"{type(exc).__name__} while sending", "held", None,
                                       stop_dispatch=True)
        proposal = None
        if outcome.code == "answered" and item["kind"] == "interpretation" and installed is not None:
            try:
                proposal = self._model_proposal(installed, item, attempt_id, request, outcome)
            except Exception as exc:
                outcome = replace(outcome, code="invalid_answer", answer=None,
                                  detail=f"the answer could not be checked ({type(exc).__name__})")
        try:
            self._record(claim, item, attempt_id, outcome, proposal)
        except Exception:
            log.exception("recording attempt %s failed", attempt_id)
            outcome = provider.Outcome("ambiguous", "unrecorded_response", "the response could not be recorded; it "
                                       "may have been billed", "held", None, stop_dispatch=True)
            self._record(claim, item, attempt_id, outcome, None)
        return outcome

    def _model_proposal(self, installed: Installed, item, attempt_id: str, request: provider.ProviderRequest,
                        outcome: provider.Outcome) -> dict[str, Any]:
        criterion_id = loads(item["input"])["criterion"]["criterion_id"]
        return proposal_content(
            installed, criterion_id, origin="model",
            interpreter={"kind": "model", "name": f"{provider.PROVIDER}/{provider.MODEL}",
                         "version": digest(dict(request.configuration)), "transport": self.client.transport_label},
            interpretation=namespace_rule(criterion_id, outcome.answer["interpretation"]),
            questions=namespaced_questions(criterion_id, outcome.answer["questions"]), attempt_id=attempt_id)

    def _record(self, claim: jobs.Claim, item, attempt_id: str, outcome: provider.Outcome,
                proposal: Mapping[str, Any] | None) -> None:
        """Reconcile the attempt's receipt and cost, and accept its outcome for the item only while this claim owns
        the job and the attempt is still the item's dispatched attempt."""
        item_state = {"completed": "answered" if outcome.code == "answered" else "failed", "failed": "failed",
                      "ambiguous": "ambiguous", "not_sent": "failed"}[outcome.attempt_state]
        answer = None if outcome.code != "answered" else dumps(dict(outcome.answer))
        with self.store.write() as connection:
            current = connection.execute("SELECT current_attempt, state FROM items WHERE item_id = ?",
                                         (item["item_id"],)).fetchone()
            accepted = jobs._owned(connection, claim) is not None and current["current_attempt"] == attempt_id \
                and current["state"] == "dispatched"
            detail = {"code": outcome.code, "detail": outcome.detail, "attempt_id": attempt_id, "late": not accepted}
            connection.execute(
                "UPDATE attempts SET state = ?, reservation = ?, charged_microusd = ?, outcome = ?, http_status = ?, "
                "response_id = ?, response_headers = ?, response_body = ?, usage = ?, answer = ?, completed_at = ?, "
                "latency_ms = ? WHERE attempt_id = ? AND state IN ('dispatched', 'ambiguous')",
                (outcome.attempt_state, outcome.reservation, outcome.charge_microusd, dumps(detail),
                 outcome.http_status, outcome.response_id,
                 None if outcome.headers is None else dumps(dict(outcome.headers)), outcome.body,
                 None if outcome.usage is None else dumps(dict(outcome.usage)), answer, self.store.timestamp(),
                 outcome.latency_ms, attempt_id))
            if not accepted:  # A late response: retained and reconciled, but it answers and proposes nothing.
                return
            if proposal is not None:
                record_proposal(connection, self.store, proposal, f"{provider.PROVIDER}/{provider.MODEL}")
            connection.execute("UPDATE items SET state = ?, outcome = ?, answer_attempt = ? WHERE item_id = ?",
                               (item_state, dumps(detail), attempt_id if answer is not None else None,
                                item["item_id"]))


class _Superseded(_Stopped):
    """Another worker owns the job now."""
