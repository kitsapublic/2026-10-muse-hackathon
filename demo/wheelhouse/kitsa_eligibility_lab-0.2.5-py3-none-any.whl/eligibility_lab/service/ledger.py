"""The experiment cost ledger: ceilings, request limits, reservations and reconciliation.

An experiment is the unit of live spending authority: a provider, model, prices, a ceiling across every run and retry,
and a request limit. All experiments in one store together may allocate at most $15. It starts disabled; enabling it is the operator's explicit spending action, and
the service must also be started with live mode enabled. Every provider attempt reserves its worst-case cost in the
same transaction that records its receipt, before anything is sent. The experiment's exposure is the sum of held
reservations and settled charges, so concurrent reservations can never together exceed the ceiling. A reservation is
settled at the reconciled charge when the provider answered, released only when the request is known not to have been
sent, and otherwise held: HTTP errors have undocumented billing, so they keep their reservations too.
"""
from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any

from eligibility_lab.model import IDENTIFIER
from eligibility_lab.service import provider
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.store import Store, dumps, loads

MAX_CEILING_MICROUSD = 15_000_000
MAX_REQUESTS = 5_000


def create_experiment(store: Store, experiment_id: str, *, ceiling_usd: str, max_requests: int,
                      operator: str) -> dict[str, Any]:
    if not isinstance(experiment_id, str) or not IDENTIFIER.fullmatch(experiment_id):
        raise Refusal("invalid_experiment", "the experiment id must be an identifier")
    try:
        ceiling = Decimal(ceiling_usd) * 1_000_000
    except (InvalidOperation, TypeError):
        raise Refusal("invalid_experiment", "the ceiling must be a decimal number of US dollars") from None
    if ceiling != ceiling.to_integral_value() or not 0 < ceiling <= MAX_CEILING_MICROUSD:
        raise Refusal("invalid_experiment", "the ceiling must be more than $0 and at most $15, in whole micro-dollars")
    if type(max_requests) is not int or not 0 < max_requests <= MAX_REQUESTS:
        raise Refusal("invalid_experiment", f"the request limit must be from 1 to {MAX_REQUESTS}")
    with store.write() as connection:
        if connection.execute("SELECT 1 FROM experiments WHERE experiment_id = ?", (experiment_id,)).fetchone():
            raise Refusal("experiment_exists", "an experiment with that id exists; its ceiling cannot change",
                          status=409)
        committed = connection.execute("SELECT COALESCE(SUM(ceiling_microusd), 0) FROM experiments").fetchone()[0]
        if committed + ceiling > MAX_CEILING_MICROUSD:
            raise Refusal("ceiling_exceeds_store_limit", "all experiments in a store together may spend at most $15; "
                          f"${committed / 1_000_000:.2f} is already allocated", status=409)
        connection.execute(
            "INSERT INTO experiments (experiment_id, provider, model, ceiling_microusd, max_requests, pricing, enabled,"
            " created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?)",
            (experiment_id, provider.PROVIDER, provider.MODEL, int(ceiling), max_requests,
             dumps({**provider.PRICING, "unit": "micro-USD per million tokens"}), operator, store.timestamp()))
    return summary(store, experiment_id)


def set_enabled(store: Store, experiment_id: str, enabled: bool) -> dict[str, Any]:
    with store.write() as connection:
        if connection.execute("UPDATE experiments SET enabled = ? WHERE experiment_id = ?",
                              (int(enabled), experiment_id)).rowcount != 1:
            raise Refusal("experiment_not_found", "no experiment has that id", status=404)
    return summary(store, experiment_id)


def exposure(connection, experiment_id: str) -> tuple[int, int, int, int]:
    """Held reservations, settled charges and requests made (sent or possibly sent)."""
    row = connection.execute(
        "SELECT COALESCE(SUM(CASE WHEN reservation = 'held' THEN reserved_microusd ELSE 0 END), 0) AS held, "
        "COALESCE(SUM(CASE WHEN reservation = 'settled' THEN charged_microusd ELSE 0 END), 0) AS settled, "
        "COALESCE(SUM(CASE WHEN state != 'not_sent' THEN 1 ELSE 0 END), 0) AS requests, "
        "COALESCE(SUM(CASE WHEN state = 'ambiguous' THEN 1 ELSE 0 END), 0) AS ambiguous "
        "FROM attempts WHERE experiment_id = ?", (experiment_id,)).fetchone()
    return row["held"], row["settled"], row["requests"], row["ambiguous"]


def refusal_to_reserve(connection, experiment_id: str, amount: int) -> str | None:
    """Why `amount` cannot be reserved now, or None; call inside the transaction that records the attempt."""
    experiment = connection.execute("SELECT * FROM experiments WHERE experiment_id = ?", (experiment_id,)).fetchone()
    if experiment is None or not experiment["enabled"]:
        return "experiment_disabled"
    if amount <= 0:
        return "reservation_unbounded"
    held, settled, requests, _ = exposure(connection, experiment_id)
    if requests + 1 > experiment["max_requests"]:
        return "request_limit_reached"
    if held + settled + amount > experiment["ceiling_microusd"]:
        return "budget_exhausted"
    return None


def summary(store: Store, experiment_id: str) -> dict[str, Any]:
    with store.read() as connection:
        experiment = connection.execute("SELECT * FROM experiments WHERE experiment_id = ?",
                                        (experiment_id,)).fetchone()
        if experiment is None:
            raise Refusal("experiment_not_found", "no experiment has that id", status=404)
        held, settled, requests, ambiguous = exposure(connection, experiment_id)
        tokens = connection.execute("SELECT usage FROM attempts WHERE experiment_id = ? AND usage IS NOT NULL",
                                    (experiment_id,)).fetchall()
    usage = [loads(row["usage"]) for row in tokens]
    return {"experiment_id": experiment_id, "provider": experiment["provider"], "model": experiment["model"],
            "enabled": bool(experiment["enabled"]), "ceiling_microusd": experiment["ceiling_microusd"],
            "max_requests": experiment["max_requests"], "pricing": loads(experiment["pricing"]),
            "held_microusd": held, "settled_microusd": settled, "exposure_microusd": held + settled,
            "remaining_microusd": max(0, experiment["ceiling_microusd"] - held - settled), "requests": requests,
            "ambiguous_requests": ambiguous,
            "tokens": {key: sum(u.get(key) or 0 for u in usage)
                       for key in ("prompt_tokens", "completion_tokens", "reasoning_tokens", "cached_tokens")}}


def experiments(store: Store) -> list[dict[str, Any]]:
    with store.read() as connection:
        ids = [row["experiment_id"] for row in connection.execute(
            "SELECT experiment_id FROM experiments ORDER BY experiment_id")]
    return [summary(store, experiment_id) for experiment_id in ids]
