"""The `/v1` HTTP API and the same-origin showcase assets.

The service binds to loopback only. Every request must name an allowed loopback Host, which defeats DNS rebinding.
A state change additionally needs the per-process action token from `GET /v1/session` in the
`X-Eligibility-Lab-Action` header, and is refused when its Origin is not the service's own (or a configured loopback
development origin) or when the browser reports a cross-site request. No CORS headers are ever sent, so another site's
script cannot read the token. Requests select installed bundles, proposals and jobs by identity; they never supply a
path, URL, upload, SQL or executable rule. Every refusal is a bounded `{"error": {...}}` document.

The fixed synthetic workspace and local operator identity describe this local tool; they do not claim a production
tenant's authorization.
"""
from __future__ import annotations

from contextlib import asynccontextmanager
import hmac
from pathlib import Path
import secrets
from typing import Annotated, Any, Literal, Sequence, Union

from fastapi import FastAPI, Header, Query, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
from pydantic import BaseModel, ConfigDict, Field

from eligibility_lab import __version__
from eligibility_lab.run import DEFAULT_WORKSPACE, EVALUATOR
from eligibility_lab.service import catalog, exports, interpretations, jobs, ledger
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.store import Store, loads

OPERATOR = "local-operator"
ACTION_HEADER = "x-eligibility-lab-action"
PUBLIC = ("public",)
SECURITY_HEADERS = {"X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
                    "Cross-Origin-Opener-Policy": "same-origin", "Cross-Origin-Resource-Policy": "same-origin",
                    "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self'; "
                                               "img-src 'self' data:; connect-src 'self'; font-src 'self'; "
                                               "object-src 'none'; base-uri 'none'; form-action 'self'; "
                                               "frame-ancestors 'none'"}


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", populate_by_name=True)


# Errors and session ------------------------------------------------------------------------------------------------

class ErrorDetail(Model):
    code: str
    message: str
    problems: list[str]


class ErrorBody(Model):
    error: ErrorDetail


class ModeState(Model):
    available: bool
    reason: str | None
    label: str
    experiment_id: str | None = None


class Modes(Model):
    reference: ModeState
    recorded: ModeState
    live: ModeState


class Session(Model):
    action_token: str
    operator: str
    workspace: str
    service_version: str
    evaluator: dict[str, str]
    modes: Modes


# Bundles -----------------------------------------------------------------------------------------------------------

class Identities(Model):
    protocol: str
    criteria: str
    cohort: str
    narrative: str
    patients: int
    criteria_count: int
    reference_date: str


class BundleSummary(Model):
    bundle_key: str
    bundle_id: str
    bundle_version: str
    manifest_sha256: str
    identities: Identities
    installed_at: str


class Passage(Model):
    anchor: str
    heading: str | None
    text: str


class ProtocolView(Model):
    protocol_id: str
    version: str
    title: str
    passages: list[Passage]


class CriterionView(Model):
    criterion_id: str
    category: Literal["inclusion", "exclusion"]
    text: str
    anchor: str


class Question(Model):
    question_id: str
    statement: str


class EditSpec(Model):
    criterion_id: str = Field(max_length=64)
    parameter: str = Field(max_length=64)
    value: int | str


class SavedScenario(Model):
    scenario_id: str
    title: str
    author: str
    edits: list[EditSpec]


class ScenarioParameter(Model):
    criterion_id: str
    parameter: str
    type: Literal["integer", "decimal"]
    value: int | str
    minimum: int | str
    maximum: int | str


class CohortView(Model):
    cohort_id: str
    version: str
    patients: int
    digest: str


class NarrativeSourceView(Model):
    kind: Literal["reference", "model"]
    description: str


class BundleDetail(BundleSummary):
    protocol: ProtocolView
    criteria: list[CriterionView]
    questions: list[Question]
    scenarios: list[SavedScenario]
    scenario_parameters: list[ScenarioParameter]
    cohort: CohortView
    narrative_source: NarrativeSourceView


# Interpretations ---------------------------------------------------------------------------------------------------

class Review(Model):
    review_id: str
    decision: Literal["approved", "rejected"]
    reviewer: str
    created_at: str


class CriterionPin(Model):
    bundle_key: str
    criterion_id: str
    category: Literal["inclusion", "exclusion"]
    text: str
    anchor: str
    protocol: dict[str, str]
    criterion_set: dict[str, str]


class Proposal(Model):
    proposal_id: str
    criterion_id: str
    origin: Literal["reference", "model", "edit"]
    interpreter: dict[str, str]
    interpretation: dict[str, Any]
    questions: dict[str, str]
    valid: bool
    problems: list[str]
    parent_id: str | None
    attempt_id: str | None
    author: str
    created_at: str
    criterion: CriterionPin
    review: Review | None


class ReviewRequest(Model):
    decision: Literal["approved", "rejected"]


class EditRequest(Model):
    interpretation: dict[str, Any]


# Jobs --------------------------------------------------------------------------------------------------------------

class Progress(Model):
    pending: int
    dispatched: int
    answered: int
    failed: int
    ambiguous: int
    skipped: int
    total: int


class Counts(Model):
    passing: int
    failing: int
    unresolved: int
    total: int


class ResultSummary(Model):
    run_id: str
    content_digest: str
    counts: Counts
    coverage_complete: bool
    metrics: dict[str, Any]


class JobError(Model):
    code: str
    message: str
    problems: list[str] = Field(default_factory=list)


class ScenarioSpec(Model):
    scenario_id: str | None
    edits: list[EditSpec] | None
    title: str | None


class Job(Model):
    job_id: str
    kind: Literal["baseline", "scenario", "interpretation"]
    mode: Literal["reference", "recorded", "live"]
    mode_label: str
    bundle_key: str
    set_id: str | None
    baseline_job_id: str | None
    experiment_id: str | None
    evaluation_date: str
    configuration_sha256: str | None
    scenario: ScenarioSpec | None
    criterion_ids: list[str] | None
    state: Literal["queued", "running", "succeeded", "partial", "failed", "cancelled"]
    cancel_requested: bool
    generation: int
    error: JobError | None
    progress: Progress
    result: ResultSummary | None
    created_at: str
    updated_at: str
    finished_at: str | None


class BaselineJobRequest(Model):
    kind: Literal["baseline"]
    bundle_key: str = Field(max_length=200)
    mode: Literal["reference", "recorded", "live"]
    proposal_ids: list[Annotated[str, Field(max_length=64)]] = Field(max_length=200)
    evaluation_date: str | None = Field(default=None, max_length=10)
    experiment_id: str | None = Field(default=None, max_length=128)
    confirm_spend: bool = False


class ScenarioJobRequest(Model):
    kind: Literal["scenario"]
    baseline_job_id: str = Field(max_length=64)
    scenario_id: str | None = Field(default=None, max_length=128)
    edits: list[EditSpec] | None = Field(default=None, max_length=10)
    title: str | None = Field(default=None, max_length=200)


class InterpretationJobRequest(Model):
    kind: Literal["interpretation"]
    bundle_key: str = Field(max_length=200)
    criterion_ids: list[Annotated[str, Field(max_length=64)]] = Field(max_length=100)
    experiment_id: str | None = Field(default=None, max_length=128)
    confirm_spend: bool = False
    retry: bool = False


JobRequest = Annotated[Union[BaselineJobRequest, ScenarioJobRequest, InterpretationJobRequest],
                       Field(discriminator="kind")]


class RetryRequest(Model):
    item_ids: list[Annotated[str, Field(max_length=128)]] = Field(min_length=1, max_length=1000)


class Item(Model):
    item_id: str
    position: int
    kind: Literal["narrative", "interpretation"]
    item_key: str
    state: Literal["pending", "dispatched", "answered", "failed", "ambiguous", "skipped"]
    outcome: dict[str, Any] | None
    current_attempt: str | None
    retry_of: str | None
    answer_attempt: str | None


# Results -----------------------------------------------------------------------------------------------------------

class Cell(Model):
    outcome: Literal["decision", "execution_failure"]
    value: Literal["yes", "no", "undetermined"] | None
    reasons: list[str]
    failures: list[str]
    applicability: Literal["unconditional", "applicable", "not_applicable", "undetermined"]
    evidence: list[str]
    narrative_decisions: list[str]
    sources: list[str]


class PatientResult(Model):
    patient_id: str
    classification: Literal["passing", "failing", "unresolved"]
    failing_criteria: list[str]
    unresolved_criteria: list[str]
    cells: dict[str, Cell]


class ResultCriterion(Model):
    criterion_id: str
    category: Literal["inclusion", "exclusion"]
    text: str
    anchor: str
    interpretation: Literal["executable", "unsupported"]
    parameters: dict[str, int | str]
    rule_digest: str
    baseline_rule_digest: str


class CriterionCoverage(Model):
    yes: int
    no: int
    undetermined: int
    execution_failure: int


class Coverage(Model):
    cells: int
    decided: int
    undetermined: int
    execution_failures: int
    complete: bool
    by_criterion: dict[str, CriterionCoverage]
    undetermined_reasons: dict[str, int]


class WaterfallStep(Model):
    criterion_id: str
    passing: int
    failing: int
    unresolved: int
    newly_failing: int


class Waterfall(Model):
    order: list[str]
    denominator: int
    steps: list[WaterfallStep]


class Impact(Model):
    criterion_id: str
    failing: int
    passing_if_waived: int
    gain: int
    gained_patients: list[str]


class GroupSummary(Model):
    patients: int
    age_bands: dict[str, int]
    sex: dict[str, int]


class EngineMetrics(Model):
    elapsed_us: int
    decisions_computed: int
    decisions_reused: int
    patients: int
    criteria: int
    cells: int


class RunScenario(Model):
    scenario_id: str
    title: str
    author: str | None
    edits: list[EditSpec]


class RunRecord(Model):
    bundle: dict[str, str]
    protocol: dict[str, str]
    criterion_set: dict[str, str]
    cohort: dict[str, str | int]
    narrative: dict[str, str]
    evaluation_date: str
    scenario: RunScenario
    waterfall_order: list[str]
    interpreter: dict[str, str]
    normalizer: dict[str, str]
    evaluator: dict[str, str]
    workspace: str


class Result(Model):
    format: str
    run_id: str
    run: RunRecord
    criteria: list[ResultCriterion]
    patients: list[PatientResult]
    counts: Counts
    coverage: Coverage
    waterfall: Waterfall
    criterion_impact: list[Impact]
    summaries: dict[str, GroupSummary]
    content_digest: str
    execution_metrics: EngineMetrics


class JobResult(Model):
    job: Job
    result: Result


class RunCounts(Model):
    run_id: str
    content_digest: str
    counts: Counts


class ScenarioRun(RunCounts):
    scenario_id: str
    title: str
    author: str | None
    edits: list[EditSpec]


class ParameterChange(Model):
    parameter: str
    from_: int | str = Field(alias="from")
    to: int | str


class ChangedCriterion(Model):
    criterion_id: str
    edits: list[ParameterChange]
    baseline_rule_digest: str
    scenario_rule_digest: str


class CriterionChange(Model):
    criterion_id: str
    from_: str = Field(alias="from")
    to: str


class ChangedPatient(Model):
    patient_id: str
    from_: Literal["passing", "failing", "unresolved"] = Field(alias="from")
    to: Literal["passing", "failing", "unresolved"]
    changed_criteria: list[CriterionChange]


class ComparisonSummaries(Model):
    baseline: dict[str, GroupSummary]
    scenario: dict[str, GroupSummary]


class ComparisonMetrics(Model):
    elapsed_us: int
    baseline: EngineMetrics
    scenario: EngineMetrics


class Comparison(Model):
    format: str
    baseline: RunCounts
    scenario: ScenarioRun
    evaluation_date: str
    complete: bool
    changed_criteria: list[ChangedCriterion]
    passing_delta: int
    transitions: dict[str, int]
    changed_patients: list[ChangedPatient]
    summaries: ComparisonSummaries
    content_digest: str
    execution_metrics: ComparisonMetrics


class JobComparison(Model):
    job: Job
    baseline_job_id: str
    comparison: Comparison


class Experiment(Model):
    experiment_id: str
    provider: str
    model: str
    enabled: bool
    ceiling_microusd: int
    max_requests: int
    pricing: dict[str, int | str]
    held_microusd: int
    settled_microusd: int
    exposure_microusd: int
    remaining_microusd: int
    requests: int
    ambiguous_requests: int
    tokens: dict[str, int]


# Application -------------------------------------------------------------------------------------------------------

def loopback_hosts(port: int) -> set[str]:
    return {f"127.0.0.1:{port}", f"localhost:{port}", f"[::1]:{port}"}


def create_app(store: Store, *, port: int, worker: Any = None, assets: Path | None = None,
               extra_origins: Sequence[str] = (), live_experiment: str | None = None,
               action_token: str | None = None) -> FastAPI:
    token = action_token or secrets.token_urlsafe(32)
    transport = None if worker is None or worker.client is None else worker.client.transport_label
    hosts = loopback_hosts(port)
    origins = {f"http://{host}" for host in hosts} | set(extra_origins)
    assets = None if assets is None else Path(assets).resolve()

    @asynccontextmanager
    async def lifespan(_: FastAPI):
        if worker is not None:
            worker.start()
        try:
            yield
        finally:
            if worker is not None:
                worker.stop()

    app = FastAPI(title="Eligibility Lab", version=__version__, openapi_url="/v1/openapi.json", docs_url=None,
                  redoc_url=None, lifespan=lifespan,
                  description="Local Eligibility Lab service: installed synthetic bundles, reviewed interpretations, "
                              "durable jobs, comparisons and exports. Loopback only.")

    def refusal(code: str, message: str, status: int, problems: Sequence[str] = ()) -> JSONResponse:
        return JSONResponse(Refusal(code, message, status=status, problems=problems).document(), status_code=status,
                            headers={**SECURITY_HEADERS, "Cache-Control": "no-store"})

    @app.middleware("http")
    async def boundary(request: Request, call_next):
        if request.headers.get("host") not in hosts:
            return refusal("host_not_allowed", "the service answers only its loopback address", 421)
        api = request.url.path.startswith("/v1/")
        site = request.headers.get("sec-fetch-site")
        if api and site is not None and site not in ("same-origin", "none"):
            return refusal("cross_origin_refused", "the API answers only its own origin", 403)
        if request.method not in ("GET", "HEAD"):
            origin = request.headers.get("origin")
            if origin is not None and origin not in origins:
                return refusal("cross_origin_refused", "the API answers only its own origin", 403)
            supplied = request.headers.get(ACTION_HEADER, "")
            if not hmac.compare_digest(supplied.encode(), token.encode()):
                return refusal("action_token_required", "changes need the session's action token", 403)
        response = await call_next(request)
        response.headers.update(SECURITY_HEADERS)
        if api:
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.exception_handler(Refusal)
    async def refused(_: Request, exc: Refusal):
        return JSONResponse(exc.document(), status_code=exc.status)

    @app.exception_handler(RequestValidationError)
    async def invalid(_: Request, exc: RequestValidationError):
        problems = [f"{'.'.join(str(p) for p in error.get('loc', ()))}: {error.get('msg', '')}"
                    for error in exc.errors()]
        return JSONResponse(Refusal("invalid_request", "the request does not match the API schema",
                                    problems=problems).document(), status_code=422)

    errors = {404: {"model": ErrorBody}, 409: {"model": ErrorBody}, 422: {"model": ErrorBody, "description": "Unprocessable Content"},
              403: {"model": ErrorBody}}

    @app.get("/v1/session", response_model=Session, responses=errors, tags=["session"])
    def session() -> Any:
        with store.read() as connection:
            modes = jobs.mode_availability(connection, live_experiment)
        return {"action_token": token, "operator": OPERATOR, "workspace": DEFAULT_WORKSPACE,
                "service_version": __version__, "evaluator": dict(EVALUATOR), "modes": modes}

    @app.get("/v1/bundles", response_model=list[BundleSummary], tags=["bundles"])
    def bundles() -> Any:
        return [{key: value for key, value in bundle.items() if key != "audience"}
                for bundle in catalog.list_bundles(store, PUBLIC)]

    @app.get("/v1/bundles/{bundle_key}", response_model=BundleDetail, responses=errors, tags=["bundles"])
    def bundle(bundle_key: str) -> Any:
        installed = catalog.load_installed(store, bundle_key, audiences=PUBLIC)
        with store.read() as connection:
            summary = catalog.describe(connection, bundle_key)
        summary.pop("audience")
        docs = installed.documents
        criteria = docs["criteria"]
        return {**summary,
                "protocol": {key: docs["protocol"][key] for key in ("protocol_id", "version", "title", "passages")},
                "criteria": [{"criterion_id": c["criterion_id"], "category": c["category"], "text": c["text"],
                              "anchor": c["source"]["anchor"]} for c in criteria["criteria"]],
                "questions": criteria["questions"], "scenarios": docs["scenarios"]["scenarios"],
                "scenario_parameters": [{"criterion_id": c, "parameter": p, **spec}
                                        for (c, p), spec in sorted(installed.policy.items())],
                "cohort": {"cohort_id": installed.bundle.cohort.cohort_id,
                           "version": installed.bundle.cohort.version,
                           "patients": len(installed.bundle.cohort.patients),
                           "digest": installed.bundle.cohort.digest},
                "narrative_source": docs["narrative"]["source"]}

    @app.get("/v1/bundles/{bundle_key}/proposals", response_model=list[Proposal], responses=errors,
             tags=["interpretations"])
    def proposals(bundle_key: str) -> Any:
        catalog.load_installed(store, bundle_key, audiences=PUBLIC)
        return interpretations.list_proposals(store, bundle_key)

    def public_keys() -> list[str]:
        return [b["bundle_key"] for b in catalog.list_bundles(store, PUBLIC)]

    @app.post("/v1/proposals/{proposal_id}/reviews", response_model=Proposal, responses=errors,
              tags=["interpretations"])
    def review(proposal_id: str, body: ReviewRequest) -> Any:
        return interpretations.review(store, proposal_id, body.decision, OPERATOR, public_keys())

    @app.post("/v1/proposals/{proposal_id}/edits", response_model=Proposal, status_code=201, responses=errors,
              tags=["interpretations"])
    def edit(proposal_id: str, body: EditRequest) -> Any:
        with store.read() as connection:
            row = connection.execute("SELECT bundle_key FROM proposals WHERE proposal_id = ?",
                                     (proposal_id,)).fetchone()
        if row is None or row["bundle_key"] not in public_keys():
            raise Refusal("proposal_not_found", "no proposal has that identity", status=404)
        installed = catalog.load_installed(store, row["bundle_key"], audiences=PUBLIC)
        return interpretations.edit(store, installed, proposal_id, body.interpretation, OPERATOR)

    @app.post("/v1/jobs", response_model=Job, status_code=202, responses=errors, tags=["jobs"])
    def submit(body: JobRequest, response: Response,
               idempotency_key: Annotated[str, Header(alias="Idempotency-Key", max_length=128)]) -> Any:
        job, created = jobs.submit(store, body.model_dump(by_alias=True), idempotency_key, operator=OPERATOR,
                                   audiences=PUBLIC, live_experiment=live_experiment, transport=transport)
        if not created:
            response.status_code = 200
        elif worker is not None:
            worker.wake()
        return job

    @app.get("/v1/jobs", response_model=list[Job], tags=["jobs"])
    def list_jobs(bundle_key: Annotated[str | None, Query(max_length=200)] = None,
                  limit: Annotated[int, Query(ge=1, le=500)] = 100) -> Any:
        return jobs.list_jobs(store, bundle_key, audiences=PUBLIC, limit=limit)

    @app.get("/v1/jobs/{job_id}", response_model=Job, responses=errors, tags=["jobs"])
    def job(job_id: str) -> Any:
        return jobs.get(store, job_id, audiences=PUBLIC)

    @app.get("/v1/jobs/{job_id}/items", response_model=list[Item], responses=errors, tags=["jobs"])
    def items(job_id: str) -> Any:
        jobs.get(store, job_id, audiences=PUBLIC)
        with store.read() as connection:
            result = []
            for r in connection.execute(
                "SELECT items.*, bundles.audience AS answer_audience FROM items "
                "LEFT JOIN attempts ON attempts.attempt_id = items.answer_attempt "
                "LEFT JOIN jobs ON jobs.job_id = attempts.job_id "
                "LEFT JOIN bundles ON bundles.bundle_key = jobs.bundle_key "
                "WHERE items.job_id = ? ORDER BY items.position", (job_id,)
            ):
                outcome = loads(r["outcome"])
                answer_attempt = r["answer_attempt"]
                # Schema 1 history can retain a cached answer from an operator-only bundle.
                if answer_attempt is not None and r["answer_audience"] not in PUBLIC:
                    if outcome and outcome.get("attempt_id") == answer_attempt:
                        outcome.pop("attempt_id")
                    answer_attempt = None
                result.append({"item_id": r["item_id"], "position": r["position"], "kind": r["kind"],
                               "item_key": r["item_key"], "state": r["state"], "outcome": outcome,
                               "current_attempt": r["current_attempt"], "retry_of": r["retry_of"],
                               "answer_attempt": answer_attempt})
            return result

    @app.post("/v1/jobs/{job_id}/cancel", response_model=Job, responses=errors, tags=["jobs"])
    def cancel(job_id: str) -> Any:
        return jobs.cancel(store, job_id, audiences=PUBLIC)

    @app.post("/v1/jobs/{job_id}/resume", response_model=Job, responses=errors, tags=["jobs"])
    def resume(job_id: str) -> Any:
        resumed = jobs.resume(store, job_id, audiences=PUBLIC, transport=transport)
        if worker is not None:
            worker.wake()
        return resumed

    @app.post("/v1/jobs/{job_id}/retries", response_model=Job, responses=errors, tags=["jobs"])
    def retries(job_id: str, body: RetryRequest) -> Any:
        retried = jobs.retry(store, job_id, body.item_ids, audiences=PUBLIC, transport=transport)
        if worker is not None:
            worker.wake()
        return retried

    @app.get("/v1/jobs/{job_id}/result", response_model=JobResult, responses=errors, tags=["results"])
    def job_result(job_id: str) -> Any:
        return exports.result(store, job_id, audiences=PUBLIC)

    @app.get("/v1/jobs/{job_id}/comparison", response_model=JobComparison, responses=errors, tags=["results"])
    def job_comparison(job_id: str) -> Any:
        return exports.comparison(store, job_id, audiences=PUBLIC)

    def download(name: str) -> dict[str, str]:
        return {"Content-Disposition": f'attachment; filename="{name}"'}

    @app.get("/v1/jobs/{job_id}/report.json", response_model=dict[str, Any], responses=errors, tags=["exports"])
    def report(job_id: str) -> Any:
        return JSONResponse(exports.report(store, job_id, audiences=PUBLIC),
                            headers=download(f"eligibility-lab-{job_id}-report.json"))

    @app.get("/v1/jobs/{job_id}/matrix.csv", response_class=PlainTextResponse, responses=errors, tags=["exports"])
    def matrix(job_id: str) -> Any:
        document = exports.result(store, job_id, audiences=PUBLIC)["result"]
        return PlainTextResponse(exports.matrix_csv(document), media_type="text/csv; charset=utf-8",
                                 headers=download(f"eligibility-lab-{job_id}-matrix.csv"))

    @app.get("/v1/jobs/{job_id}/comparison.csv", response_class=PlainTextResponse, responses=errors,
             tags=["exports"])
    def comparison_csv(job_id: str) -> Any:
        document = exports.comparison(store, job_id, audiences=PUBLIC)["comparison"]
        return PlainTextResponse(exports.comparison_csv(document), media_type="text/csv; charset=utf-8",
                                 headers=download(f"eligibility-lab-{job_id}-comparison.csv"))

    @app.get("/v1/ledger", response_model=list[Experiment], tags=["ledger"])
    def ledger_summary() -> Any:
        return ledger.experiments(store)

    @app.api_route("/v1/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"], include_in_schema=False)
    def unknown(rest: str) -> Any:
        raise Refusal("not_found", "no such API route", status=404)

    if assets is not None:
        index = assets / "index.html"

        @app.get("/{path:path}", include_in_schema=False)
        def showcase(path: str) -> Any:
            candidate = (assets / path).resolve()
            if path and candidate.is_file() and candidate.is_relative_to(assets):
                return FileResponse(candidate)
            return FileResponse(index, headers={"Cache-Control": "no-cache"})

    return app
