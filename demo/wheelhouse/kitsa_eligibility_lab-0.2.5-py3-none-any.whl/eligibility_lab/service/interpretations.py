"""Interpretation proposals, their review and the immutable interpretation sets that jobs run.

A proposal pins one criterion's id, category, text, anchor and protocol and criterion-set versions, the interpreter
that produced it (the bundle's authored reference, a model configuration or a local edit) and its interpretation in
the engine's closed rule language, validated by the engine. Proposals never change: an edit is a new proposal whose
parent is the edited one, and it needs its own review, so editing invalidates the earlier review by construction. The
latest review of a proposal decides its state; only a valid proposal can be approved.

Scenario editability is server policy, not a proposal property. The parameters the installed bundle's reference
criteria mark editable are the only editable ones, with their reference bounds; any other parameter a proposal marks
editable is made protected before validation. Narrative questions a model proposes are namespaced by criterion, so
they never collide with the bundle's questions.

An interpretation set pins one approved proposal per criterion, with the review that approved it, and the criteria
document built from them. A set made only of unmodified reference proposals reproduces the installed criteria
document exactly, so its runs have the engine CLI's run identities.
"""
from __future__ import annotations

import copy
from typing import TYPE_CHECKING, Any, Mapping, Sequence

from eligibility_lab.canonical import canonical_json, digest
from eligibility_lab.errors import EligibilityError
from eligibility_lab.model import IDENTIFIER
from eligibility_lab.rules import parse_interpretation, questions_of
from eligibility_lab.service.errors import Refusal
from eligibility_lab.service.store import Store, dumps, loads, new_id

if TYPE_CHECKING:
    from eligibility_lab.service.catalog import Installed

REVIEWED_SET_INTERPRETER = "kitsa-eligibility-lab/reviewed-set"


def criterion_pin(installed: "Installed", criterion_id: str) -> dict[str, Any]:
    criteria = installed.documents["criteria"]
    for criterion in criteria["criteria"]:
        if criterion["criterion_id"] == criterion_id:
            return {"bundle_key": installed.key, "criterion_id": criterion_id, "category": criterion["category"],
                    "text": criterion["text"], "anchor": criterion["source"]["anchor"],
                    "protocol": dict(criteria["protocol"]),
                    "criterion_set": {"criterion_set_id": criteria["criterion_set_id"],
                                      "version": criteria["version"]}}
    raise Refusal("unknown_criterion", f"the bundle has no criterion {criterion_id[:64]}", status=404)


def _apply_policy(raw: Any, criterion_id: str, policy: Mapping[tuple[str, str], Mapping[str, Any]]) -> Any:
    if not isinstance(raw, dict) or raw.get("status") != "executable" or not isinstance(raw.get("parameters"), dict):
        return raw
    parameters = {}
    for name, entry in raw["parameters"].items():
        if not isinstance(entry, dict):
            parameters[name] = entry
            continue
        base = {key: value for key, value in entry.items() if key not in ("editable", "minimum", "maximum")}
        allowed = policy.get((criterion_id, name))
        parameters[name] = ({**base, "editable": True, "minimum": allowed["minimum"], "maximum": allowed["maximum"]}
                            if allowed is not None and entry.get("type") == allowed["type"]
                            else {**base, "editable": False})
    return {**raw, "parameters": parameters}


def proposal_content(installed: "Installed", criterion_id: str, *, origin: str, interpreter: Mapping[str, Any],
                     interpretation: Any, questions: Mapping[str, str], parent_id: str | None = None,
                     attempt_id: str | None = None) -> dict[str, Any]:
    """The immutable content of a proposal, with the engine's validation problems (empty when valid)."""
    pin = criterion_pin(installed, criterion_id)
    bundle_questions = {q["question_id"]: q["statement"] for q in installed.documents["criteria"]["questions"]}
    available = {**bundle_questions, **questions}
    normalized = _apply_policy(interpretation, criterion_id, installed.policy)
    problems: list[str] = []
    used: dict[str, str] = {}
    try:
        parsed = parse_interpretation(normalized, questions=available, path=f"{criterion_id}.interpretation")
        used = {question: available[question] for question in questions_of(parsed)}
    except EligibilityError as exc:
        problems = list(exc.problems) or [str(exc)]
    return {"criterion": pin, "origin": origin, "interpreter": dict(interpreter), "interpretation": normalized,
            "questions": used, "problems": problems[:50], "parent_id": parent_id, "attempt_id": attempt_id}


def record_proposal(connection, store: Store, content: Mapping[str, Any], author: str) -> str:
    """Store `content` once; identical content is the same proposal."""
    proposal_id = f"prp-{digest(content)[:24]}"
    connection.execute(
        "INSERT OR IGNORE INTO proposals (proposal_id, bundle_key, criterion_id, origin, content, valid, parent_id, "
        "attempt_id, author, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (proposal_id, content["criterion"]["bundle_key"], content["criterion"]["criterion_id"], content["origin"],
         dumps(content), int(not content["problems"]), content["parent_id"], content["attempt_id"], author,
         store.timestamp()))
    return proposal_id


def record_reference_proposals(connection, store: Store, installed: "Installed") -> None:
    criteria = installed.documents["criteria"]
    for criterion in criteria["criteria"]:
        content = proposal_content(installed, criterion["criterion_id"], origin="reference",
                                   interpreter=criteria["interpreter"], interpretation=criterion["interpretation"],
                                   questions={})
        record_proposal(connection, store, content, "bundle reference")


def _latest_review(connection, proposal_id: str):
    return connection.execute("SELECT * FROM reviews WHERE proposal_id = ? ORDER BY sequence DESC LIMIT 1",
                              (proposal_id,)).fetchone()


def describe_proposal(connection, row) -> dict[str, Any]:
    content = loads(row["content"])
    review = _latest_review(connection, row["proposal_id"])
    return {"proposal_id": row["proposal_id"], "criterion_id": row["criterion_id"], "origin": row["origin"],
            "interpreter": content["interpreter"], "interpretation": content["interpretation"],
            "questions": content["questions"], "valid": bool(row["valid"]), "problems": content["problems"],
            "parent_id": row["parent_id"], "attempt_id": row["attempt_id"], "author": row["author"],
            "created_at": row["created_at"], "criterion": content["criterion"],
            "review": None if review is None else {"review_id": review["review_id"], "decision": review["decision"],
                                                   "reviewer": review["reviewer"],
                                                   "created_at": review["created_at"]}}


def list_proposals(store: Store, key: str) -> list[dict[str, Any]]:
    with store.read() as connection:
        rows = connection.execute("SELECT * FROM proposals WHERE bundle_key = ? ORDER BY criterion_id, created_at, "
                                  "proposal_id", (key,)).fetchall()
        return [describe_proposal(connection, row) for row in rows]


def _proposal(connection, proposal_id: str, audiences_keys: Sequence[str] | None = None):
    row = connection.execute("SELECT * FROM proposals WHERE proposal_id = ?", (proposal_id,)).fetchone()
    if row is None or (audiences_keys is not None and row["bundle_key"] not in audiences_keys):
        raise Refusal("proposal_not_found", "no proposal has that identity", status=404)
    return row


def review(store: Store, proposal_id: str, decision: str, reviewer: str,
           visible_bundles: Sequence[str] | None = None) -> dict[str, Any]:
    if decision not in ("approved", "rejected"):
        raise Refusal("invalid_review", "a review approves or rejects")
    with store.write() as connection:
        row = _proposal(connection, proposal_id, visible_bundles)
        if decision == "approved" and not row["valid"]:
            raise Refusal("proposal_invalid", "an invalid interpretation cannot be approved", status=409,
                          problems=loads(row["content"])["problems"])
        connection.execute("INSERT INTO reviews (review_id, proposal_id, decision, reviewer, created_at) "
                           "VALUES (?, ?, ?, ?, ?)",
                           (new_id("rev"), proposal_id, decision, reviewer, store.timestamp()))
        return describe_proposal(connection, row)


def edit(store: Store, installed: "Installed", proposal_id: str, interpretation: Any, author: str) -> dict[str, Any]:
    """A new proposal replacing `proposal_id`'s interpretation; it awaits review like any other."""
    try:
        canonical_json(interpretation)
    except (TypeError, ValueError, UnicodeEncodeError, RecursionError):
        raise Refusal("invalid_interpretation", "an interpretation holds integers, decimal strings and text only, "
                                                "never decimals as numbers") from None
    with store.write() as connection:
        parent = _proposal(connection, proposal_id, [installed.key])
        parent_content = loads(parent["content"])
        content = proposal_content(installed, parent["criterion_id"], origin="edit",
                                   interpreter={"kind": "edit", "name": "local-operator", "version": proposal_id},
                                   interpretation=interpretation, questions=parent_content["questions"],
                                   parent_id=proposal_id)
        new = record_proposal(connection, store, content, author)
        return describe_proposal(connection, _proposal(connection, new))


def namespaced_questions(criterion_id: str, raw_questions: Any) -> dict[str, str]:
    """The statements of model-proposed questions, renamed `<criterion>.<question>`."""
    statements = {}
    for entry in raw_questions if isinstance(raw_questions, list) else []:
        if not isinstance(entry, dict):
            continue
        question, statement = entry.get("question_id"), entry.get("statement")
        name = f"{criterion_id}.{question}"
        if isinstance(question, str) and isinstance(statement, str) and IDENTIFIER.fullmatch(name) \
                and statement.strip() and len(statement) <= 1000:
            statements[name] = statement
    return statements


def namespace_rule(criterion_id: str, node: Any) -> Any:
    """A model rule with every narrative question renamed `<criterion>.<question>`, so a question the model did not
    declare can never bind to one of the bundle's questions."""
    if isinstance(node, dict):
        changed = {key: namespace_rule(criterion_id, value) for key, value in node.items()}
        if node.get("op") == "narrative" and isinstance(node.get("question"), str):
            changed["question"] = f"{criterion_id}.{node['question']}"
        return changed
    if isinstance(node, list):
        return [namespace_rule(criterion_id, item) for item in node]
    return node


def resolve_set(connection, installed: "Installed", proposal_ids: Sequence[str]) -> dict:
    """Resolve exactly one approved proposal per criterion without writing to the store."""
    criteria = installed.documents["criteria"]
    expected = [criterion["criterion_id"] for criterion in criteria["criteria"]]
    if not isinstance(proposal_ids, (list, tuple)) or len(proposal_ids) != len(expected) \
            or len(set(proposal_ids)) != len(proposal_ids):
        raise Refusal("invalid_interpretation_set", "name exactly one approved proposal per criterion")
    members, contents, problems, named = {}, {}, [], set()
    for proposal_id in proposal_ids:
        row = _proposal(connection, proposal_id, [installed.key])
        named.add(row["criterion_id"])
        review_row = _latest_review(connection, proposal_id)
        if review_row is None or review_row["decision"] != "approved":
            problems.append(f"{row['criterion_id']}: proposal {proposal_id} is not approved")
        elif row["criterion_id"] in members:
            problems.append(f"{row['criterion_id']}: more than one proposal")
        else:
            members[row["criterion_id"]] = {"criterion_id": row["criterion_id"], "proposal_id": proposal_id,
                                            "review_id": review_row["review_id"], "origin": row["origin"]}
            contents[row["criterion_id"]] = loads(row["content"])
    if problems or set(members) != set(expected):
        problems += [f"{criterion}: no proposal named" for criterion in expected if criterion not in named]
        raise Refusal("criteria_not_reviewed", "every criterion needs exactly one approved interpretation",
                      status=409, problems=problems)
    document = copy.deepcopy(criteria)
    questions = {q["question_id"]: q["statement"] for q in document["questions"]}
    for criterion_id in expected:
        for question, statement in contents[criterion_id]["questions"].items():
            if questions.setdefault(question, statement) != statement:
                raise Refusal("question_conflict", f"question {question} has two statements", status=409)
    document["questions"] = [{"question_id": q, "statement": s} for q, s in questions.items()]
    for criterion in document["criteria"]:
        criterion["interpretation"] = contents[criterion["criterion_id"]]["interpretation"]
        criterion["review_state"] = "approved"
    ordered = [members[criterion_id] for criterion_id in expected]
    if any(member["origin"] != "reference" for member in ordered):
        document["interpreter"] = {"kind": "reviewed", "name": REVIEWED_SET_INTERPRETER,
                                   "version": digest([[m["criterion_id"], m["proposal_id"]] for m in ordered])}
    set_id = f"set-{digest({'bundle_key': installed.key, 'members': ordered, 'criteria': document})[:24]}"
    return {"set_id": set_id, "members": ordered, "criteria_document": document}


def interpretation_set(connection, store: Store, installed: "Installed", proposal_ids: Sequence[str]) -> dict:
    """Persist the resolved set once per distinct content."""
    resolved = resolve_set(connection, installed, proposal_ids)
    connection.execute("INSERT OR IGNORE INTO interpretation_sets (set_id, bundle_key, members, criteria_document, "
                       "created_at) VALUES (?, ?, ?, ?, ?)",
                       (resolved["set_id"], installed.key, dumps(resolved["members"]),
                        dumps(resolved["criteria_document"]), store.timestamp()))
    return resolved



def current_set_reviews(connection, set_id: str) -> list[str]:
    """Members whose approving review is no longer the proposal's latest review."""
    row = connection.execute("SELECT members FROM interpretation_sets WHERE set_id = ?", (set_id,)).fetchone()
    stale = []
    for member in loads(row["members"]):
        latest = _latest_review(connection, member["proposal_id"])
        if latest is None or latest["review_id"] != member["review_id"]:
            stale.append(member["criterion_id"])
    return stale
