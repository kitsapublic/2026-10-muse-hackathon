"""The service's local SQLite store: schema, upgrades, transactions and identifiers.

A store is a directory holding `store.sqlite3` and its installed bundle copies, created owner-only. The schema version
is SQLite's `user_version`; opening a store applies any missing upgrades in one transaction and refuses a store written
by a newer version. A store is never reset to resolve an upgrade problem.

Every change runs in `write()`, an immediate transaction that takes SQLite's write lock before reading, so a
read-check-update sequence (claims, reservations, state transitions) cannot interleave with another writer.
"""
from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
from typing import Any, Callable, Iterator

from eligibility_lab.canonical import canonical_json
from eligibility_lab.service.errors import Refusal

DATABASE = "store.sqlite3"
BUSY_TIMEOUT_MS = 30_000

SCHEMA = (
    """
    CREATE TABLE store_info (key TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT;
    CREATE TABLE bundles (
        bundle_key TEXT PRIMARY KEY, bundle_id TEXT NOT NULL, bundle_version TEXT NOT NULL,
        audience TEXT NOT NULL CHECK (audience IN ('public', 'private')),
        manifest_sha256 TEXT NOT NULL, identities TEXT NOT NULL, installed_at TEXT NOT NULL,
        UNIQUE (bundle_id, bundle_version)) STRICT;
    CREATE TABLE proposals (
        proposal_id TEXT PRIMARY KEY, bundle_key TEXT NOT NULL REFERENCES bundles, criterion_id TEXT NOT NULL,
        origin TEXT NOT NULL CHECK (origin IN ('reference', 'model', 'edit')), content TEXT NOT NULL,
        valid INTEGER NOT NULL CHECK (valid IN (0, 1)), parent_id TEXT REFERENCES proposals, attempt_id TEXT,
        author TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
    CREATE INDEX proposals_by_criterion ON proposals (bundle_key, criterion_id);
    CREATE TABLE reviews (
        sequence INTEGER PRIMARY KEY AUTOINCREMENT, review_id TEXT NOT NULL UNIQUE,
        proposal_id TEXT NOT NULL REFERENCES proposals,
        decision TEXT NOT NULL CHECK (decision IN ('approved', 'rejected')),
        reviewer TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
    CREATE INDEX reviews_by_proposal ON reviews (proposal_id, sequence);
    CREATE TABLE interpretation_sets (
        set_id TEXT PRIMARY KEY, bundle_key TEXT NOT NULL REFERENCES bundles, members TEXT NOT NULL,
        criteria_document TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
    CREATE TABLE experiments (
        experiment_id TEXT PRIMARY KEY, provider TEXT NOT NULL, model TEXT NOT NULL,
        ceiling_microusd INTEGER NOT NULL CHECK (ceiling_microusd > 0),
        max_requests INTEGER NOT NULL CHECK (max_requests > 0), pricing TEXT NOT NULL,
        enabled INTEGER NOT NULL CHECK (enabled IN (0, 1)), created_by TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
    CREATE TABLE jobs (
        job_id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK (kind IN ('baseline', 'scenario', 'interpretation')),
        mode TEXT NOT NULL CHECK (mode IN ('reference', 'recorded', 'live')),
        bundle_key TEXT NOT NULL REFERENCES bundles, set_id TEXT REFERENCES interpretation_sets,
        baseline_job_id TEXT REFERENCES jobs, experiment_id TEXT REFERENCES experiments,
        request TEXT NOT NULL, fingerprint TEXT NOT NULL, idempotency_key TEXT NOT NULL UNIQUE,
        state TEXT NOT NULL CHECK (state IN ('queued', 'running', 'succeeded', 'partial', 'failed', 'cancelled')),
        cancel_requested INTEGER NOT NULL DEFAULT 0 CHECK (cancel_requested IN (0, 1)),
        generation INTEGER NOT NULL DEFAULT 0, owner TEXT, lease_expires REAL, error TEXT,
        created_at TEXT NOT NULL, updated_at TEXT NOT NULL, finished_at TEXT) STRICT;
    CREATE INDEX jobs_by_state ON jobs (state, created_at);
    CREATE INDEX jobs_by_baseline ON jobs (baseline_job_id);
    CREATE TABLE items (
        item_id TEXT PRIMARY KEY, job_id TEXT NOT NULL REFERENCES jobs, position INTEGER NOT NULL,
        kind TEXT NOT NULL CHECK (kind IN ('narrative', 'interpretation')), item_key TEXT NOT NULL,
        cache_key TEXT NOT NULL, input TEXT NOT NULL,
        state TEXT NOT NULL CHECK (state IN ('pending', 'dispatched', 'answered', 'failed', 'ambiguous', 'skipped')),
        current_attempt TEXT, retry_of TEXT, outcome TEXT, UNIQUE (job_id, item_key), UNIQUE (job_id, position)) STRICT;
    CREATE TABLE attempts (
        attempt_id TEXT PRIMARY KEY, item_id TEXT NOT NULL REFERENCES items, job_id TEXT NOT NULL REFERENCES jobs,
        generation INTEGER NOT NULL, retry_of TEXT REFERENCES attempts,
        experiment_id TEXT NOT NULL REFERENCES experiments, transport TEXT NOT NULL, provider TEXT NOT NULL,
        model TEXT NOT NULL, configuration TEXT NOT NULL, request_sha256 TEXT NOT NULL, request_body BLOB NOT NULL,
        reserved_microusd INTEGER NOT NULL CHECK (reserved_microusd > 0), charged_microusd INTEGER,
        reservation TEXT NOT NULL CHECK (reservation IN ('held', 'settled', 'released')),
        state TEXT NOT NULL CHECK (state IN ('dispatched', 'completed', 'failed', 'ambiguous', 'not_sent')),
        outcome TEXT, http_status INTEGER, response_id TEXT, response_headers TEXT, response_body BLOB,
        usage TEXT, dispatched_at TEXT NOT NULL, completed_at TEXT, latency_ms INTEGER) STRICT;
    CREATE INDEX attempts_by_experiment ON attempts (experiment_id, reservation);
    CREATE INDEX attempts_by_item ON attempts (item_id);
    CREATE TABLE answers (
        cache_key TEXT PRIMARY KEY, kind TEXT NOT NULL, attempt_id TEXT NOT NULL REFERENCES attempts,
        answer TEXT NOT NULL, created_at TEXT NOT NULL) STRICT;
    CREATE TABLE results (
        job_id TEXT PRIMARY KEY REFERENCES jobs, run_id TEXT NOT NULL, content_digest TEXT NOT NULL,
        document TEXT NOT NULL, narrative_document TEXT NOT NULL, metrics TEXT NOT NULL,
        created_at TEXT NOT NULL) STRICT;
    """,
    # Each answered item references the attempt whose answer it accepted, and answers live on their attempts.
    # Schema 1 results used the first answer stored for an item's key, so that attempt is the item's reference. Jobs
    # from schema 1 have no pinned configuration: they remain readable history, never executed or reused.
    """
    ALTER TABLE jobs ADD COLUMN configuration TEXT;
    ALTER TABLE attempts ADD COLUMN answer TEXT;
    ALTER TABLE items ADD COLUMN answer_attempt TEXT REFERENCES attempts;
    UPDATE attempts SET answer = (SELECT answers.answer FROM answers WHERE answers.attempt_id = attempts.attempt_id);
    UPDATE items SET answer_attempt = (SELECT answers.attempt_id FROM answers WHERE answers.cache_key = items.cache_key)
        WHERE state = 'answered';
    DROP TABLE answers;
    CREATE INDEX items_by_cache_key ON items (cache_key);
    CREATE INDEX items_by_answer ON items (answer_attempt);
    """,
)


def new_id(prefix: str) -> str:
    return f"{prefix}-{secrets.token_hex(10)}"


def dumps(value: Any) -> str:
    return canonical_json(value).decode("utf-8")


def loads(text: str | None) -> Any:
    return None if text is None else json.loads(text)


class Store:
    """One local store. Connections are opened per transaction, so any thread may use the store."""

    def __init__(self, root: Path, *, clock: Callable[[], float] = time.time,
                 schema: tuple[str, ...] = SCHEMA):
        self.root = Path(root).resolve()
        self.path = self.root / DATABASE
        self.clock = clock
        self._schema = schema

    @classmethod
    def open(cls, root: Path, *, create: bool = False, clock: Callable[[], float] = time.time,
             schema: tuple[str, ...] = SCHEMA) -> "Store":
        store = cls(root, clock=clock, schema=schema)
        if not store.path.is_file():
            if not create:
                raise Refusal("store_missing", f"no store at {store.root}; initialize it first", status=500)
            store.root.mkdir(mode=0o700, parents=True, exist_ok=True)
            os.chmod(store.root, 0o700)
            (store.root / "bundles").mkdir(mode=0o700, exist_ok=True)
        store._upgrade()
        os.chmod(store.path, 0o600)
        return store

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=BUSY_TIMEOUT_MS / 1000, isolation_level=None,
                                     check_same_thread=False)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute(f"PRAGMA busy_timeout = {BUSY_TIMEOUT_MS}")
        return connection

    def _upgrade(self) -> None:
        connection = self._connect()
        try:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.execute("BEGIN IMMEDIATE")
            version = connection.execute("PRAGMA user_version").fetchone()[0]
            if version > len(self._schema):
                connection.execute("ROLLBACK")
                raise Refusal("store_newer", f"the store has schema version {version}; this service knows "
                                             f"{len(self._schema)}. Use a newer service; the store is unchanged.",
                              status=500)
            for number, script in enumerate(self._schema[version:], start=version + 1):
                for statement in (part.strip() for part in script.split(";")):
                    if statement:
                        connection.execute(statement)
                connection.execute(f"PRAGMA user_version = {number}")
            if version == 0:
                connection.execute("INSERT INTO store_info (key, value) VALUES ('store_id', ?), ('created_at', ?)",
                                   (new_id("store"), self.timestamp()))
            connection.execute("COMMIT")
        except BaseException:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        finally:
            connection.close()

    def timestamp(self) -> str:
        return datetime.fromtimestamp(self.clock(), timezone.utc).isoformat(timespec="microseconds")

    @contextmanager
    def write(self) -> Iterator[sqlite3.Connection]:
        """An immediate transaction, committed when the block completes and rolled back on any exception."""
        connection = self._connect()
        try:
            connection.execute("BEGIN IMMEDIATE")
            yield connection
            connection.execute("COMMIT")
        except BaseException:
            if connection.in_transaction:
                connection.execute("ROLLBACK")
            raise
        finally:
            connection.close()

    @contextmanager
    def read(self) -> Iterator[sqlite3.Connection]:
        """A consistent read snapshot."""
        connection = self._connect()
        try:
            connection.execute("BEGIN")
            yield connection
        finally:
            if connection.in_transaction:
                connection.execute("COMMIT")
            connection.close()

    def schema_version(self) -> int:
        with self.read() as connection:
            return connection.execute("PRAGMA user_version").fetchone()[0]
