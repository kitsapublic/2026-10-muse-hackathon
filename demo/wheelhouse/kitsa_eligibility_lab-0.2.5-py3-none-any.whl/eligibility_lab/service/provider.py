"""The Meta Model API (Muse) adapter: requests, strict local validation of responses, and cost accounting.

Requests are text-only Chat Completions to `muse-spark-1.3` with `reasoning_effort: minimal`, a bounded `max_tokens`
(which caps reasoning and visible output together), `store: false` and a strict, closed JSON Schema in
`response_format`. The adapter never retries: the HTTP client has no transport retries, follows no redirects and ignores
proxy settings from the environment. A retry is a separate, separately reserved attempt that only the operator creates.

Every response is validated locally whatever the provider promises: envelope, model, finish status, refusal, JSON,
schema and, for narrative answers, citations, which must name notes that were supplied. The binding of an answer to
its inputs is computed by the server from the notes it supplied, never taken from the model. Outcomes keep three
cases apart: a request known not to have been sent, one the provider answered or rejected, and one whose fate is
unknown (a timeout or broken connection after sending). Only the last is ambiguous.

Costs are integer micro-dollars rounded up. A reservation covers an input bound of the request's UTF-8 byte length
plus a fixed allowance for the provider's chat template, at the uncached input price, and `max_tokens` at the output
price, because reasoning consumes the same limit and is billed as output. A reconciled charge counts prompt tokens at
the uncached price and completion tokens, which include reasoning, at the output price; missing or inconsistent usage
is charged at the full reservation or more, never less.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import time
from typing import Any, Mapping, Sequence

from eligibility_lab.canonical import canonical_json, digest, strict_loads
from eligibility_lab.rules import COMPARATORS, MAX_DEPTH
from eligibility_lab.vocabulary import CONCEPTS, HISTORY_CONCEPTS

PROVIDER = "meta"
ENDPOINT = "https://api.meta.ai/v1/chat/completions"
MODEL = "muse-spark-1.3"
REASONING_EFFORT = "minimal"
ADAPTER_VERSION = "2"
GENUINE_TRANSPORT = "meta-api"
SYNTHETIC_TRANSPORT = "synthetic-fixture"
# Standard-mode Muse Spark prices, micro-dollars per million tokens ($1.25/M input, $4.25/M output).
PRICING = {"input": 1_250_000, "output": 4_250_000}
TEMPLATE_ALLOWANCE_TOKENS = 1024
MAX_TOKENS = {"narrative": 2048, "interpretation": 4096}
MAX_REQUEST_BYTES = 96 * 1024
MAX_RESPONSE_BYTES = 256 * 1024
MAX_JSON_DEPTH = 64
TIMEOUTS = {"connect": 10.0, "read": 120.0, "write": 30.0, "pool": 10.0}
RETAINED_HEADERS = ("x-request-id", "request-id", "retry-after", "x-ratelimit-remaining-requests",
                    "x-ratelimit-remaining-tokens")
FINISH_REASONS = {"stop", "length", "tool_calls", "content_filter", "function_call"}
# All HTTP errors stop dispatch and keep reservations: failed-request billing is undocumented.
REJECTED = {400, 401, 402, 403, 404, 413, 422, 429}

NARRATIVE_SYSTEM = """You decide one eligibility question about one synthetic patient, using only the clinical notes \
supplied.
Answer "yes" when the notes establish that the statement is true on the evaluation date, "no" when they establish \
that it is false, and "undetermined" otherwise.
A condition is absent only when a note states that it is absent; a note that does not mention a condition \
establishes nothing about it.
When the notes disagree and the most recent notes do not resolve the disagreement, answer "undetermined" with \
reason "conflicting_evidence".
When the notes do not address the statement, answer "undetermined" with reason "insufficient_evidence".
When you cannot decide for any other reason, answer "undetermined" with reason "cannot_determine".
For "yes" or "no", give reason "established" and cite every supporting note by its note_id.
Cite only note_ids of the notes supplied. Reply with JSON that matches the schema and nothing else."""

NARRATIVE_SCHEMA = {
    "type": "object", "additionalProperties": False, "required": ["answer", "reason", "supporting_note_ids"],
    "properties": {
        "answer": {"type": "string", "enum": ["yes", "no", "undetermined"]},
        "reason": {"type": "string",
                   "enum": ["established", "insufficient_evidence", "conflicting_evidence", "cannot_determine"]},
        "supporting_note_ids": {"type": "array", "items": {"type": "string", "enum": ["<supplied note ids>"]}}}}
NARRATIVE_REASONS = {"insufficient_evidence": "insufficient_evidence", "conflicting_evidence": "conflicting_evidence",
                     "cannot_determine": "model_abstention"}

INTERPRETATION_SCHEMA = {
    "type": "object", "additionalProperties": False,
    "required": ["status", "unsupported_reason", "rule_json", "questions"],
    "properties": {
        "status": {"type": "string", "enum": ["executable", "unsupported"]},
        "unsupported_reason": {"type": "string"},
        "rule_json": {"type": "string"},
        "questions": {"type": "array", "items": {
            "type": "object", "additionalProperties": False, "required": ["question_id", "statement"],
            "properties": {"question_id": {"type": "string"}, "statement": {"type": "string"}}}}}}


def _vocabulary() -> str:
    lines = []
    for name, concept in CONCEPTS.items():
        detail = concept.kind
        if concept.kind == "quantity":
            detail += f"; units {', '.join(unit for unit, _ in concept.units)}"
        if concept.kind == "code":
            detail += f"; codes {', '.join(concept.codes)}"
        if concept.kind == "ordinal":
            detail += f"; integer {concept.minimum} to {concept.maximum}"
        lines.append(f"- {name}: {detail}")
    return "\n".join(lines)


INTERPRETATION_SYSTEM = f"""You translate one clinical-trial eligibility criterion into Eligibility Lab's closed rule \
language, or declare that it cannot be expressed in it. Reply with JSON that matches the schema and nothing else.

When status is "executable", rule_json is a JSON object encoded as a string, with exactly the fields rule_version \
(the integer 1), parameters, applicability (a rule, or null when the criterion always applies) and requirement \
(a rule), and unsupported_reason is "". When status is "unsupported", rule_json is "" and unsupported_reason says \
why. For an inclusion criterion the requirement states what must be true; for an exclusion criterion it states the \
condition that excludes; applicability states when a conditional criterion applies at all.

A rule is one of these JSON objects and nothing else, nested at most {MAX_DEPTH} levels:
- {{"op": "and" | "or", "args": [two or more rules]}} and {{"op": "not", "arg": rule}}
- {{"op": "age", "comparator": C, "value": V}}: completed years on the assessment date
- {{"op": "measurement", "concept": ordinal or quantity concept, "comparator": C, "value": V, "unit": unit or null \
for ordinals, "window_days": integer or null}}
- {{"op": "code_in", "concept": code concept, "codes": [codes], "window_days": integer or null}}
- {{"op": "assertion", "concept": assertion concept, "window_days": integer or null}}
- {{"op": "regimen_count" | "days_since_last_dose", "concept": "systemic_anticancer_regimen", "comparator": C, \
"value": V, "history": {{"op": "assertion", "concept": "{HISTORY_CONCEPTS[0]}", "window_days": integer}}}}
- {{"op": "narrative", "question": question_id, "window_days": integer}}: a judgement from clinical notes
C is one of {", ".join(COMPARATORS)}. V is a non-negative integer, a non-negative decimal string, or \
{{"param": name}}. window_days counts days before the assessment date, inclusive.
parameters maps each referenced name to {{"type": "integer" | "decimal", "value": integer or decimal string, \
"editable": false}}. Every declared parameter must be referenced.
Concepts:
{_vocabulary()}
Declare every narrative question in questions, with a question_id of lower-case letters, digits and underscores and \
a statement that a reader of the notes can answer yes or no about the patient. Use the assessment conventions \
supplied."""


def _prompt_id(task: str) -> str:
    system, schema = ((NARRATIVE_SYSTEM, NARRATIVE_SCHEMA) if task == "narrative"
                      else (INTERPRETATION_SYSTEM, INTERPRETATION_SCHEMA))
    return digest({"system": system, "user_format": f"{task}/1"}), digest(schema)


def configuration(task: str) -> dict[str, Any]:
    prompt, schema = _prompt_id(task)
    return {"provider": PROVIDER, "endpoint": ENDPOINT, "model": MODEL, "reasoning_effort": REASONING_EFFORT,
            "max_tokens": MAX_TOKENS[task], "prompt": prompt, "schema": schema, "adapter": ADAPTER_VERSION,
            "task": task}


def narrative_cache_key(input_sha256: str, settings: Mapping[str, Any], transport: str) -> str:
    """The identity of one narrative request: its bound inputs, a job's pinned request configuration and transport."""
    return digest({"task": "narrative", "input_sha256": input_sha256, "configuration": dict(settings),
                   "transport": transport})


def interpretation_cache_key(pin: Mapping[str, Any], conventions: Sequence[str], parameter_names: Sequence[str],
                             settings: Mapping[str, Any], transport: str) -> str:
    return digest({"task": "interpretation", "criterion": dict(pin), "conventions": list(conventions),
                   "parameters": list(parameter_names), "configuration": dict(settings), "transport": transport})


def _cost(tokens: int, price: int) -> int:
    return -(-tokens * price // 1_000_000)


def reservation(body_bytes: int, max_tokens: int) -> int:
    return _cost(body_bytes + TEMPLATE_ALLOWANCE_TOKENS, PRICING["input"]) + _cost(max_tokens, PRICING["output"])


@dataclass(frozen=True)
class ProviderRequest:
    task: str
    body: bytes
    sha256: str
    configuration: Mapping[str, Any]
    reserve_microusd: int
    note_ids: tuple[str, ...]  # narrative: the notes supplied, the only citable ones


def _request(task: str, messages: list[dict[str, str]], schema: dict[str, Any],
             note_ids: tuple[str, ...]) -> ProviderRequest:
    settings = configuration(task)
    body = canonical_json({
        "model": MODEL, "messages": messages, "reasoning_effort": REASONING_EFFORT,
        "max_tokens": settings["max_tokens"], "store": False,
        "response_format": {"type": "json_schema",
                            "json_schema": {"name": f"eligibility_lab_{task}", "strict": True, "schema": schema}}})
    if len(body) > MAX_REQUEST_BYTES:
        raise ValueError(f"the {task} request exceeds {MAX_REQUEST_BYTES} bytes")
    return ProviderRequest(task, body, hashlib.sha256(body).hexdigest(), settings,
                           reservation(len(body), settings["max_tokens"]), note_ids)


def narrative_request(statement: str, evaluation_date: str, first_day: str,
                      notes: Sequence[Mapping[str, str]]) -> ProviderRequest:
    """`notes` are the complete notes inside the window: note_id, written_on and text."""
    note_ids = tuple(note["note_id"] for note in notes)
    schema = json.loads(json.dumps(NARRATIVE_SCHEMA))
    schema["properties"]["supporting_note_ids"]["items"]["enum"] = list(note_ids)
    user = canonical_json({"statement": statement, "evaluation_date": evaluation_date,
                           "notes_written_from": first_day, "notes_written_to": evaluation_date,
                           "notes": [{"note_id": n["note_id"], "written_on": n["written_on"], "text": n["text"]}
                                     for n in notes]}).decode("utf-8")
    return _request("narrative", [{"role": "system", "content": NARRATIVE_SYSTEM},
                                  {"role": "user", "content": user}], schema, note_ids)


def interpretation_request(pin: Mapping[str, Any], conventions: Sequence[str],
                           parameter_names: Mapping[str, str]) -> ProviderRequest:
    """`parameter_names` maps a scenario-editable parameter's required name to what it controls."""
    user = canonical_json({"criterion": {"category": pin["category"], "text": pin["text"], "anchor": pin["anchor"]},
                           "assessment_conventions": list(conventions),
                           "required_parameter_names": dict(parameter_names)}).decode("utf-8")
    return _request("interpretation", [{"role": "system", "content": INTERPRETATION_SYSTEM},
                                       {"role": "user", "content": user}], INTERPRETATION_SCHEMA, ())


@dataclass(frozen=True)
class Outcome:
    attempt_state: str  # completed | failed | ambiguous | not_sent
    code: str
    detail: str
    reservation: str  # settled | held | released
    charge_microusd: int | None
    http_status: int | None = None
    response_id: str | None = None
    headers: Mapping[str, str] | None = None
    body: bytes | None = None
    usage: Mapping[str, Any] | None = None
    answer: Mapping[str, Any] | None = None
    latency_ms: int = 0
    stop_dispatch: bool = False


def _usage(raw: Any) -> dict[str, int] | None:
    if not isinstance(raw, dict):
        return None
    values = {"prompt_tokens": raw.get("prompt_tokens"), "completion_tokens": raw.get("completion_tokens"),
              "total_tokens": raw.get("total_tokens")}
    reasoning = raw.get("completion_tokens_details")
    cached = raw.get("prompt_tokens_details")
    values["reasoning_tokens"] = reasoning.get("reasoning_tokens") if isinstance(reasoning, dict) else None
    values["cached_tokens"] = cached.get("cached_tokens") if isinstance(cached, dict) else None
    for key, value in values.items():
        if value is not None and (type(value) is not int or value < 0):
            return None
    if values["prompt_tokens"] is None or values["completion_tokens"] is None:
        return None
    return values


def charge(usage: Mapping[str, Any] | None, reserved: int) -> tuple[int, list[str]]:
    if usage is None:
        return reserved, ["usage_missing"]
    output, flags = usage["completion_tokens"], []
    if usage["reasoning_tokens"] is not None and usage["reasoning_tokens"] > usage["completion_tokens"]:
        output, flags = usage["completion_tokens"] + usage["reasoning_tokens"], ["usage_inconsistent"]
    if (usage.get("cached_tokens") is not None and usage["cached_tokens"] > usage["prompt_tokens"]) or \
            (usage.get("total_tokens") is not None and
             usage["total_tokens"] != usage["prompt_tokens"] + usage["completion_tokens"]):
        flags = ["usage_inconsistent"]
    amount = _cost(usage["prompt_tokens"], PRICING["input"]) + _cost(output, PRICING["output"])
    if flags:
        amount = max(reserved, amount)
    if amount > reserved:
        flags.append("charge_exceeds_reservation")
    return amount, flags


def _well_formed(value: Any, depth: int = 0) -> bool:
    """Nested at most MAX_JSON_DEPTH levels, with text that can be stored (no lone surrogates)."""
    if depth > MAX_JSON_DEPTH:
        return False
    if isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeEncodeError:
            return False
        return True
    if isinstance(value, dict):
        return all(_well_formed(k, depth + 1) and _well_formed(v, depth + 1) for k, v in value.items())
    if isinstance(value, list):
        return all(_well_formed(item, depth + 1) for item in value)
    return True


def _schema_check(value: Any, schema: Mapping[str, Any], path: str = "$") -> list[str]:
    """The closed subset of JSON Schema the adapter sends: object, array, string with optional enum."""
    kind = schema["type"]
    if kind == "object":
        if not isinstance(value, dict):
            return [f"{path}: must be an object"]
        problems = [f"{path}: missing {key}" for key in schema["required"] if key not in value]
        problems += [f"{path}: unexpected {key}" for key in value if key not in schema["properties"]]
        for key, item in value.items():
            if key in schema["properties"]:
                problems += _schema_check(item, schema["properties"][key], f"{path}.{key}")
        return problems
    if kind == "array":
        if not isinstance(value, list):
            return [f"{path}: must be an array"]
        return [problem for i, item in enumerate(value) for problem in _schema_check(item, schema["items"],
                                                                                    f"{path}[{i}]")]
    if not isinstance(value, str):
        return [f"{path}: must be a string"]
    if "enum" in schema and value not in schema["enum"]:
        return [f"{path}: unexpected value"]
    return []


def _narrative_answer(content: Any, note_ids: Sequence[str]) -> tuple[str, str, dict[str, Any] | None]:
    schema = json.loads(json.dumps(NARRATIVE_SCHEMA))
    schema["properties"]["supporting_note_ids"]["items"].pop("enum")
    problems = _schema_check(content, schema)
    if problems:
        return "schema_violation", "; ".join(problems)[:300], None
    cited = content["supporting_note_ids"]
    if len(set(cited)) != len(cited) or not set(cited) <= set(note_ids):
        return "citation_invalid", "citations must name distinct supplied notes", None
    answer, reason = content["answer"], content["reason"]
    if answer in ("yes", "no"):
        if reason != "established":
            return "inconsistent_answer", "a decided answer gives reason established", None
        if not cited:
            return "citation_invalid", "a decided answer cites at least one supporting note", None
        return "answered", "", {"value": answer, "reason": None, "supporting_note_ids": sorted(cited)}
    if reason == "established":
        return "inconsistent_answer", "an undetermined answer gives why", None
    return "answered", "", {"value": "undetermined", "reason": NARRATIVE_REASONS[reason],
                            "supporting_note_ids": sorted(cited)}


def _interpretation_answer(content: Any) -> tuple[str, str, dict[str, Any] | None]:
    problems = _schema_check(content, INTERPRETATION_SCHEMA)
    if problems:
        return "schema_violation", "; ".join(problems)[:300], None
    if content["status"] == "unsupported":
        if not content["unsupported_reason"].strip() or content["rule_json"]:
            return "inconsistent_answer", "an unsupported answer gives a reason and no rule", None
        return "answered", "", {"interpretation": {"status": "unsupported",
                                                   "reason": content["unsupported_reason"][:2000]},
                                "questions": content["questions"]}
    try:
        rule = strict_loads(content["rule_json"].encode("utf-8"))
    except (ValueError, RecursionError, UnicodeEncodeError):
        return "malformed_json", "rule_json is not strict JSON", None
    if not _well_formed(rule):
        return "malformed_json", f"rule_json is nested more than {MAX_JSON_DEPTH} levels or holds unusable text", None
    if not isinstance(rule, dict) or "status" in rule:
        return "schema_violation", "rule_json must be an object without a status", None
    return "answered", "", {"interpretation": {"status": "executable", **rule}, "questions": content["questions"]}


def validate_response(request: ProviderRequest, status: int, body: bytes, headers: Mapping[str, str],
                      latency_ms: int) -> Outcome:
    """The outcome of a received HTTP response; the request was certainly delivered, so even a response that cannot
    be read is a completed, malformed one charged at its full reservation, never a crash."""
    try:
        return _validate(request, status, body, headers, latency_ms)
    except (TypeError, ValueError, KeyError, AttributeError, RecursionError, UnicodeError) as exc:
        return Outcome("completed", "malformed_envelope", f"the response could not be read ({type(exc).__name__})",
                       "settled", request.reserve_microusd, http_status=status, body=body[:MAX_RESPONSE_BYTES],
                       latency_ms=latency_ms)


def _validate(request: ProviderRequest, status: int, body: bytes, headers: Mapping[str, str],
              latency_ms: int) -> Outcome:
    retained = {name: headers[name][:200] for name in RETAINED_HEADERS if name in headers}
    base = {"http_status": status, "headers": retained, "body": body[:MAX_RESPONSE_BYTES], "latency_ms": latency_ms}
    reserved = request.reserve_microusd
    if status != 200:
        if status in REJECTED:
            return Outcome("failed", "rate_limited" if status == 429 else "provider_rejected",
                           f"HTTP {status}; whether it was billed is unknown", "held", None,
                           stop_dispatch=True, **base)
        return Outcome("failed", "provider_error", f"HTTP {status}; whether it was billed is unknown", "held", None,
                       stop_dispatch=True, **base)
    if len(body) > MAX_RESPONSE_BYTES:
        return Outcome("completed", "response_too_large", "the response exceeds the size limit", "settled", reserved,
                       stop_dispatch=True, **base)
    try:
        envelope = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, ValueError, RecursionError):
        return Outcome("completed", "malformed_envelope", "the response is not JSON", "settled", reserved, **base)
    if not _well_formed(envelope):
        return Outcome("completed", "malformed_envelope", "the response is nested too deeply or holds unusable text",
                       "settled", reserved, **base)
    usage = _usage(envelope.get("usage")) if isinstance(envelope, dict) else None
    amount, flags = charge(usage, reserved)
    settled = {"reservation": "settled", "charge_microusd": amount, "usage": None if usage is None else
               {**usage, "flags": flags},
               "stop_dispatch": bool(set(flags) & {"charge_exceeds_reservation", "usage_inconsistent"}), **base}

    def done(code: str, detail: str = "", answer: dict | None = None, response_id: str | None = None) -> Outcome:
        return Outcome("completed", code, detail[:300], answer=answer, response_id=response_id, **settled)

    if not isinstance(envelope, dict) or envelope.get("object") != "chat.completion" \
            or not isinstance(envelope.get("id"), str) or not isinstance(envelope.get("model"), str) \
            or not isinstance(envelope.get("choices"), list):
        return done("malformed_envelope", "the response is not a chat completion")
    response_id = envelope["id"][:200]
    if envelope.get("model") != MODEL:
        return done("model_mismatch", f"the response names model {str(envelope.get('model'))[:60]!r}",
                    response_id=response_id)
    if len(envelope["choices"]) != 1 or not isinstance(envelope["choices"][0], dict) \
            or not isinstance(envelope["choices"][0].get("message"), dict):
        return done("malformed_envelope", "the response must have exactly one choice with a message",
                    response_id=response_id)
    choice = envelope["choices"][0]
    message = choice["message"]
    finish = choice.get("finish_reason")
    if message.get("role") != "assistant" or not isinstance(finish, str) or finish not in FINISH_REASONS:
        return done("malformed_envelope", "unexpected role or finish reason", response_id=response_id)
    refusal = message.get("refusal")
    if refusal not in (None, ""):
        return done("refused", str(refusal), response_id=response_id)
    if finish == "length":
        return done("truncated", "the output reached max_tokens", response_id=response_id)
    if finish == "content_filter":
        return done("content_filtered", "the provider filtered the output", response_id=response_id)
    if finish != "stop":
        return done("unexpected_tool_call", f"finish reason {finish}", response_id=response_id)
    text = message.get("content")
    if not isinstance(text, str) or not text.strip():
        return done("empty_content", "the message has no content", response_id=response_id)
    try:
        content = strict_loads(text.encode("utf-8"))
    except (ValueError, RecursionError, UnicodeEncodeError):
        return done("malformed_json", "the content is not strict JSON", response_id=response_id)
    if not _well_formed(content):
        return done("malformed_json", f"the content is nested more than {MAX_JSON_DEPTH} levels",
                    response_id=response_id)
    code, detail, answer = (_narrative_answer(content, request.note_ids) if request.task == "narrative"
                            else _interpretation_answer(content))
    return done(code, detail, answer, response_id)


class MuseClient:
    """Sends requests to the Meta Model API. Only a client built without a test transport is genuine."""

    def __init__(self, api_key: str, *, transport: Any = None):
        import httpx  # The service extra provides it; the calculation core never imports this module.

        if not api_key:
            raise ValueError("an API key is required")
        self._api_key = api_key
        self.transport_label = GENUINE_TRANSPORT if transport is None else SYNTHETIC_TRANSPORT
        self._httpx = httpx
        self._client = httpx.Client(transport=transport or httpx.HTTPTransport(retries=0),
                                    timeout=httpx.Timeout(**TIMEOUTS), follow_redirects=False, trust_env=False)

    def __repr__(self) -> str:
        return f"MuseClient(transport={self.transport_label})"

    def close(self) -> None:
        self._client.close()

    def send(self, request: ProviderRequest) -> Outcome:
        httpx = self._httpx
        started = time.monotonic()

        def elapsed() -> int:
            return int((time.monotonic() - started) * 1000)

        try:
            with self._client.stream("POST", ENDPOINT, content=request.body,
                                     headers={"Authorization": f"Bearer {self._api_key}",
                                              "Content-Type": "application/json", "Accept": "application/json"}) as response:
                body = bytearray()
                for chunk in response.iter_bytes():
                    body.extend(chunk[:MAX_RESPONSE_BYTES + 1 - len(body)])
                    if len(body) > MAX_RESPONSE_BYTES:
                        break
                return validate_response(request, response.status_code, bytes(body),
                                         {k.lower(): v for k, v in response.headers.items()}, elapsed())
        except (httpx.ConnectError, httpx.ConnectTimeout, httpx.PoolTimeout, httpx.UnsupportedProtocol) as exc:
            return Outcome("not_sent", "not_sent", type(exc).__name__, "released", 0, latency_ms=elapsed())
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            return Outcome("ambiguous", "ambiguous", f"{type(exc).__name__} after sending; the request may have been "
                                                     "processed", "held", None, latency_ms=elapsed(), stop_dispatch=True)
