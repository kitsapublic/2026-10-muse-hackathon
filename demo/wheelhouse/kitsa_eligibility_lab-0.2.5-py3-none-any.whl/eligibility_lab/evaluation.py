"""Criterion decisions for one patient on one evaluation date.

A decision says whether the criterion statement is satisfied, before inclusion/exclusion polarity: `yes`, `no` or
`undetermined`. Evidence qualifies when it is `final` and observed on or before the evaluation date, inside the rule's
window; a window of N days includes the date N days earlier. Selection never prefers an older record: a measurement,
code or assertion reads every qualifying record on its latest date. Records on that date that disagree after unit
normalization are `conflicting_evidence`; a missing or unlisted unit is `unrecognized_unit`; a code outside the
vocabulary is `unrecognized_code`; no qualifying record is `insufficient_evidence`. Birth dates do not change, so any
two different recorded birth dates conflict.

Regimens are counted once per regimen identifier, from the latest record of each. A count is a lower bound, and the
time since the last dose an interval, until a treatment-history completeness assertion within its window establishes
that no regimen is missing: a completed regimen gives its exact last-dose date, an ongoing one a dose on its record's
date or later, a completed one without a date a dose between its start and its record's date, and disagreeing latest
records of one regimen any time. A comparison is decided only when it holds, or fails, for every value it allows.

A narrative leaf reads the patient's notes inside its window. With none, the evidence is insufficient; otherwise it
takes the narrative decision bound to the same patient, question, evaluation date, window and set of notes. A missing
or differently bound decision is an execution failure, never a clinical result.

`and`, `or` and `not` use three-valued logic in which an execution failure counts as unknown: a known `no` (for
`and`) or `yes` (for `or`) still decides, and an undecided result with any failure is an execution failure. A
conditional criterion is normalized explicitly: an inclusion holds when it does not apply (`not applies or
requirement`), an exclusion is absent when it does not apply (`applies and requirement`), and the decision records
whether it applied. Decisions cite the evidence, notes and narrative decisions of every leaf evaluated.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal
from math import inf
from typing import Iterable

from eligibility_lab.model import Criterion, Evidence, NarrativeSource, Patient
from eligibility_lab.narrative import notes_in_window
from eligibility_lab.rules import (AllOf, AnyOf, Age, Assertion, CodeIn, DaysSinceLastDose, Executable, Measurement,
                                   Narrative, Node, Not, RegimenCount, Unsupported)
from eligibility_lab.vocabulary import CONCEPTS, to_canonical

YES, NO, UNDETERMINED, FAILURE = "yes", "no", "undetermined", "failure"
INSUFFICIENT, CONFLICTING = "insufficient_evidence", "conflicting_evidence"


@dataclass(frozen=True)
class Context:
    evaluation_date: date
    narrative: NarrativeSource


@dataclass(frozen=True)
class Truth:
    value: str
    reasons: frozenset[str] = frozenset()
    failures: frozenset[str] = frozenset()
    evidence: frozenset[str] = frozenset()
    narrative: frozenset[str] = frozenset()
    sources: frozenset[str] = frozenset()


@dataclass(frozen=True)
class Cell:
    outcome: str  # decision | execution_failure
    value: str | None  # yes | no | undetermined; None for an execution failure
    reasons: tuple[str, ...]
    failures: tuple[str, ...]
    applicability: str  # unconditional | applicable | not_applicable | undetermined
    evidence: tuple[str, ...]
    narrative: tuple[str, ...]
    sources: tuple[str, ...]


def _union(truths: Iterable[Truth], field: str) -> frozenset[str]:
    return frozenset().union(*(getattr(truth, field) for truth in truths))


def _combine(children: list[Truth], dominant: str, unanimous: str) -> Truth:
    cited = {field: _union(children, field) for field in ("evidence", "narrative", "sources")}
    values = [child.value for child in children]
    if dominant in values:
        return Truth(dominant, **cited)
    if all(value == unanimous for value in values):
        return Truth(unanimous, **cited)
    unknown = [child for child in children if child.value in (UNDETERMINED, FAILURE)]
    failures = _union(unknown, "failures")
    return Truth(FAILURE if failures else UNDETERMINED, _union(unknown, "reasons"), failures, **cited)


def _negate(truth: Truth) -> Truth:
    flipped = {YES: NO, NO: YES}.get(truth.value, truth.value)
    return Truth(flipped, truth.reasons, truth.failures, truth.evidence, truth.narrative, truth.sources)


def _compare(left, comparator: str, right) -> bool:
    return {"lt": left < right, "le": left <= right, "gt": left > right, "ge": left >= right}[comparator]


def _structured(value: str, records: Iterable[Evidence], reasons: Iterable[str] = ()) -> Truth:
    cited = frozenset(record.evidence_id for record in records)
    return Truth(value, frozenset(reasons), evidence=cited, sources=frozenset({"structured"}) if cited else frozenset())


def _qualifying(patient: Patient, concept: str, window_days: int | None, on: date) -> list[Evidence]:
    first = None if window_days is None else on - timedelta(days=window_days)
    return [record for record in patient.evidence if record.concept == concept and record.status == "final"
            and record.observed_on <= on and (first is None or record.observed_on >= first)]


def _latest(records: list[Evidence]) -> list[Evidence]:
    if not records:
        return []
    newest = max(record.observed_on for record in records)
    return [record for record in records if record.observed_on == newest]


def _age(node: Age, patient: Patient, context: Context, rule: Executable) -> Truth:
    records = _qualifying(patient, "birth_date", None, context.evaluation_date)
    births = {record.value for record in records}
    if not births:
        return _structured(UNDETERMINED, records, (INSUFFICIENT,))
    if len(births) > 1:
        return _structured(UNDETERMINED, records, (CONFLICTING,))
    born, on = births.pop(), context.evaluation_date
    age = on.year - born.year - ((on.month, on.day) < (born.month, born.day))
    return _structured(YES if _compare(age, node.comparator, rule.resolve(node.value)) else NO, records)


def _measurement(node: Measurement, patient: Patient, context: Context, rule: Executable) -> Truth:
    candidates = _latest(_qualifying(patient, node.concept, node.window_days, context.evaluation_date))
    if not candidates:
        return _structured(UNDETERMINED, (), (INSUFFICIENT,))
    threshold = rule.resolve(node.value)
    if CONCEPTS[node.concept].kind == "quantity":
        values = [to_canonical(node.concept, record.value.amount, record.value.unit) for record in candidates]
        if any(value is None for value in values):
            return _structured(UNDETERMINED, candidates, ("unrecognized_unit",))
        threshold = to_canonical(node.concept, Decimal(threshold), node.unit)
    else:
        values = [record.value for record in candidates]
    if len(set(values)) > 1:
        return _structured(UNDETERMINED, candidates, (CONFLICTING,))
    return _structured(YES if _compare(values[0], node.comparator, threshold) else NO, candidates)


def _code_in(node: CodeIn, patient: Patient, context: Context, rule: Executable) -> Truth:
    candidates = _latest(_qualifying(patient, node.concept, node.window_days, context.evaluation_date))
    codes = {record.value for record in candidates}
    if not codes:
        return _structured(UNDETERMINED, (), (INSUFFICIENT,))
    if not codes <= set(CONCEPTS[node.concept].codes):
        return _structured(UNDETERMINED, candidates, ("unrecognized_code",))
    if len(codes) > 1:
        return _structured(UNDETERMINED, candidates, (CONFLICTING,))
    return _structured(YES if codes.pop() in node.codes else NO, candidates)


def _assertion(node: Assertion, patient: Patient, context: Context, rule: Executable) -> Truth:
    candidates = _latest(_qualifying(patient, node.concept, node.window_days, context.evaluation_date))
    present = {record.value for record in candidates}
    if not present:
        return _structured(UNDETERMINED, (), (INSUFFICIENT,))
    if len(present) > 1:
        return _structured(UNDETERMINED, candidates, (CONFLICTING,))
    return _structured(YES if present.pop() else NO, candidates)


def _regimens(node: RegimenCount | DaysSinceLastDose, patient: Patient, on: date) -> dict[str, list[Evidence]]:
    grouped: dict[str, list[Evidence]] = {}
    for record in _qualifying(patient, node.concept, None, on):
        grouped.setdefault(record.value.regimen_id, []).append(record)
    return {regimen: _latest(records) for regimen, records in grouped.items()}


def _incomplete(history: Truth) -> Truth:
    """What an unestablished complete history leaves unknown."""
    if history.value == FAILURE:
        return Truth(FAILURE, history.reasons, history.failures)
    return Truth(UNDETERMINED, history.reasons if history.value == UNDETERMINED else frozenset({INSUFFICIENT}))


def _with_citations(truth: Truth, records: Iterable[Evidence], history: Truth) -> Truth:
    cited = frozenset(record.evidence_id for record in records) | history.evidence
    return Truth(truth.value, truth.reasons, truth.failures, cited, frozenset(),
                 frozenset({"structured"}) if cited else frozenset())


def _regimen_count(node: RegimenCount, patient: Patient, context: Context, rule: Executable) -> Truth:
    regimens = _regimens(node, patient, context.evaluation_date)
    history = _assertion(node.history, patient, context, rule)
    records = [record for latest in regimens.values() for record in latest]
    known, limit, complete = len(regimens), rule.resolve(node.value), history.value == YES
    # `known` is a lower bound on the true count; a complete history makes it exact.
    if node.comparator in ("le", "lt"):
        result = NO if not _compare(known, node.comparator, limit) else YES if complete else None
    else:
        result = YES if _compare(known, node.comparator, limit) else NO if complete else None
    truth = Truth(result) if result is not None else _incomplete(history)
    return _with_citations(truth, records, history)


def _days_since_last_dose(node: DaysSinceLastDose, patient: Patient, context: Context, rule: Executable) -> Truth:
    on = context.evaluation_date
    regimens = _regimens(node, patient, on)
    history = _assertion(node.history, patient, context, rule)
    # Each interval bounds the days since one regimen's last dose: (lowest, highest, what leaves it uncertain).
    intervals: list[tuple[float, float, Truth | None]] = []
    for latest in regimens.values():
        states = {(r.value.state, r.value.start_on, r.value.last_dose_on) for r in latest}
        if len(states) > 1:
            intervals.append((0, inf, Truth(UNDETERMINED, frozenset({CONFLICTING}))))
            continue
        state, start, last = states.pop()
        recorded = (on - latest[0].observed_on).days
        if state == "ongoing":
            intervals.append((0, recorded, Truth(UNDETERMINED, frozenset({INSUFFICIENT}))))
        elif last is not None:
            intervals.append(((on - last).days, (on - last).days, None))
        else:
            intervals.append((recorded, (on - start).days, Truth(UNDETERMINED, frozenset({INSUFFICIENT}))))
    if history.value != YES:
        intervals.append((0, inf, _incomplete(history)))
    lowest = min((interval[0] for interval in intervals), default=inf)
    highest = min((interval[1] for interval in intervals), default=inf)
    limit = rule.resolve(node.value)

    def holds(days: float) -> bool:
        return _compare(days, node.comparator, limit)

    records = [record for latest in regimens.values() for record in latest]
    if holds(lowest) == holds(highest):
        return _with_citations(Truth(YES if holds(lowest) else NO), records, history)
    # Undecided: the cause is whatever leaves an interval on both sides of the threshold.
    causes = [cause for low, high, cause in intervals if cause is not None and holds(low) != holds(high)]
    failures = _union(causes, "failures")
    truth = Truth(FAILURE if failures else UNDETERMINED, _union(causes, "reasons"), failures)
    return _with_citations(truth, records, history)


def _narrative(node: Narrative, patient: Patient, context: Context, rule: Executable) -> Truth:
    on = context.evaluation_date
    notes = {note.note_id for note in notes_in_window(patient, on, node.window_days)}
    if not notes:
        return Truth(UNDETERMINED, frozenset({INSUFFICIENT}))
    decision = context.narrative.lookup(patient.patient_id, node.question, on, node.window_days)
    if decision is None:
        return Truth(FAILURE, failures=frozenset({"narrative_decision_unavailable"}))
    if decision.considered != notes or not decision.input_matches:
        return Truth(FAILURE, failures=frozenset({"narrative_binding_mismatch"}))
    source = "reference_narrative" if context.narrative.kind == "reference" else "model_narrative"
    reasons = frozenset({decision.reason}) if decision.value == UNDETERMINED else frozenset()
    return Truth(decision.value, reasons, frozenset(), frozenset(decision.supporting),
                 frozenset({decision.decision_id}), frozenset({source}))


def _truth(node: Node, patient: Patient, context: Context, rule: Executable) -> Truth:
    if isinstance(node, (AllOf, AnyOf)):
        children = [_truth(arg, patient, context, rule) for arg in node.args]
        return _combine(children, NO, YES) if isinstance(node, AllOf) else _combine(children, YES, NO)
    if isinstance(node, Not):
        return _negate(_truth(node.arg, patient, context, rule))
    leaf = {Age: _age, Measurement: _measurement, CodeIn: _code_in, Assertion: _assertion,
            RegimenCount: _regimen_count, DaysSinceLastDose: _days_since_last_dose, Narrative: _narrative}[type(node)]
    try:
        return leaf(node, patient, context, rule)
    except Exception:  # A defect in one leaf is an execution failure of that leaf, never a clinical result.
        return Truth(FAILURE, failures=frozenset({"evaluation_error"}))


def _cell(truth: Truth, applicability: str) -> Cell:
    citations = (tuple(sorted(truth.evidence)), tuple(sorted(truth.narrative)), tuple(sorted(truth.sources)))
    if truth.value == FAILURE:
        return Cell("execution_failure", None, tuple(sorted(truth.reasons)), tuple(sorted(truth.failures)),
                    applicability, *citations)
    if truth.value == UNDETERMINED:
        reasons = tuple(sorted(truth.reasons))
    else:
        reasons = ("not_applicable",) if applicability == "not_applicable" else ("established",)
    return Cell("decision", truth.value, reasons, (), applicability, *citations)


def evaluate_cell(criterion: Criterion, patient: Patient, context: Context) -> Cell:
    """The decision on `criterion` for `patient`, or the execution failure that prevented it."""
    interpretation = criterion.interpretation
    if isinstance(interpretation, Unsupported):
        return Cell("decision", UNDETERMINED, ("unsupported_interpretation",), (), "unconditional", (), (), ())
    conditional = interpretation.applicability is not None
    try:
        requirement = _truth(interpretation.requirement, patient, context, interpretation)
        if not conditional:
            return _cell(requirement, "unconditional")
        applies = _truth(interpretation.applicability, patient, context, interpretation)
        if criterion.category == "inclusion":
            result = _combine([_negate(applies), requirement], YES, NO)
        else:
            result = _combine([applies, requirement], NO, YES)
        return _cell(result, {YES: "applicable", NO: "not_applicable"}.get(applies.value, "undetermined"))
    except Exception:
        return Cell("execution_failure", None, (), ("evaluation_error",),
                    "undetermined" if conditional else "unconditional", (), (), ())
