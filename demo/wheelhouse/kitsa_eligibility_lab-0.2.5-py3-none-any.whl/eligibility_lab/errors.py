"""Refusals with a stable code and every problem found."""
from __future__ import annotations

from typing import Iterable


class EligibilityError(ValueError):
    """An input, edit or output is refused. `code` is stable; `problems` lists each defect as `path: message`."""

    def __init__(self, code: str, message: str, problems: Iterable[str] = ()):
        self.code = code
        self.problems = tuple(problems)
        super().__init__(f"{code}: {message}")
