"""Patient classification and cohort aggregates.

A patient fails when an inclusion criterion is `no` or an exclusion criterion is `yes`; passes only when every
inclusion is `yes` and every exclusion `no`; and is otherwise unresolved, including when a decision is an execution
failure. Patients are the counting unit, so encounters never inflate a count, and every aggregate keeps the whole
cohort as its denominator.

A waterfall applies the criteria cumulatively in a stated order; each step counts passing, failing and unresolved
patients, which always sum to the cohort, and its last step is the classification itself whatever the order. A
criterion's impact recalculates every patient with that criterion waived and all others fixed; impacts are never
added together, because one patient can be blocked by several criteria.
"""
from __future__ import annotations

from collections import Counter
from datetime import date
from typing import Any, Iterable, Mapping

from eligibility_lab.evaluation import Cell
from eligibility_lab.model import Patient

CLASSES = ("passing", "failing", "unresolved")
AGE_BANDS = (("under_18", 17), ("18_49", 49), ("50_64", 64), ("65_74", 74), ("75_79", 79), ("80_plus", None))
SEXES = ("female", "male")


def status(category: str, cell: Cell) -> str:
    if cell.value in (None, "undetermined"):
        return "unresolved"
    satisfied = cell.value == ("yes" if category == "inclusion" else "no")
    return "satisfied" if satisfied else "failing"


def classify(cells: Mapping[str, Cell], categories: Mapping[str, str]) -> str:
    statuses = {status(categories[criterion], cell) for criterion, cell in cells.items()}
    if "failing" in statuses:
        return "failing"
    return "unresolved" if "unresolved" in statuses else "passing"


def counts(classes: Iterable[str]) -> dict[str, int]:
    tally = Counter(classes)
    return {**{name: tally[name] for name in CLASSES}, "total": sum(tally.values())}


def waterfall(order: Iterable[str], matrix: Mapping[str, Mapping[str, Cell]],
              categories: Mapping[str, str]) -> dict[str, Any]:
    order = list(order)
    steps, failing_before = [], 0
    for position, criterion in enumerate(order):
        applied = order[:position + 1]
        tally = counts(classify({c: cells[c] for c in applied}, categories) for cells in matrix.values())
        steps.append({"criterion_id": criterion, "passing": tally["passing"], "failing": tally["failing"],
                      "unresolved": tally["unresolved"], "newly_failing": tally["failing"] - failing_before})
        failing_before = tally["failing"]
    return {"order": order, "denominator": len(matrix), "steps": steps}


def impact(order: Iterable[str], matrix: Mapping[str, Mapping[str, Cell]],
           categories: Mapping[str, str]) -> list[dict[str, Any]]:
    current = {patient: classify(cells, categories) for patient, cells in matrix.items()}
    entries = []
    for criterion in order:
        waived = {patient: classify({c: cell for c, cell in cells.items() if c != criterion}, categories)
                  for patient, cells in matrix.items()}
        gained = sorted(p for p in matrix if current[p] != "passing" and waived[p] == "passing")
        entries.append({"criterion_id": criterion,
                        "failing": sum(status(categories[criterion], cells[criterion]) == "failing"
                                       for cells in matrix.values()),
                        "passing_if_waived": sum(state == "passing" for state in waived.values()),
                        "gain": len(gained), "gained_patients": gained})
    return entries


def coverage(order: Iterable[str], matrix: Mapping[str, Mapping[str, Cell]]) -> dict[str, Any]:
    order = list(order)
    by_criterion = {c: {"yes": 0, "no": 0, "undetermined": 0, "execution_failure": 0} for c in order}
    reasons: Counter[str] = Counter()
    for cells in matrix.values():
        for criterion in order:
            cell = cells[criterion]
            by_criterion[criterion][cell.value or "execution_failure"] += 1
            if cell.value == "undetermined":
                reasons.update(cell.reasons)
    total = {key: sum(entry[key] for entry in by_criterion.values())
             for key in ("yes", "no", "undetermined", "execution_failure")}
    return {"cells": len(matrix) * len(order), "decided": total["yes"] + total["no"],
            "undetermined": total["undetermined"], "execution_failures": total["execution_failure"],
            "complete": total["execution_failure"] == 0, "by_criterion": by_criterion,
            "undetermined_reasons": dict(sorted(reasons.items()))}


def _age(patient: Patient, on: date) -> int | None:
    births = {e.value for e in patient.evidence if e.concept == "birth_date" and e.status == "final"
              and e.observed_on <= on}
    if len(births) != 1:
        return None
    born = births.pop()
    return on.year - born.year - ((on.month, on.day) < (born.month, born.day))


def _sex(patient: Patient, on: date) -> str:
    records = [e for e in patient.evidence if e.concept == "sex" and e.status == "final" and e.observed_on <= on]
    if not records:
        return "unknown"
    newest = max(e.observed_on for e in records)
    values = {e.value for e in records if e.observed_on == newest}
    return values.pop() if len(values) == 1 and values <= set(SEXES) else "unknown"


def age_band(age: int | None) -> str:
    if age is None:
        return "unknown"
    return next(band for band, upper in AGE_BANDS if upper is None or age <= upper)


def summaries(classes: Mapping[str, str], patients: Mapping[str, Patient], on: date) -> dict[str, Any]:
    """Age bands (completed years on `on`; unknown when missing or conflicting) and recorded sex per group."""
    bands = {p: age_band(_age(patients[p], on)) for p in classes}
    sexes = {p: _sex(patients[p], on) for p in classes}
    groups = {"cohort": list(classes), **{name: [p for p, c in classes.items() if c == name] for name in CLASSES}}
    result = {}
    for group, members in groups.items():
        band_tally, sex_tally = Counter(bands[p] for p in members), Counter(sexes[p] for p in members)
        result[group] = {"patients": len(members),
                         "age_bands": {band: band_tally[band] for band, _ in (*AGE_BANDS, ("unknown", None))},
                         "sex": {sex: sex_tally[sex] for sex in (*SEXES, "unknown")}}
    return result


def transitions(before: Mapping[str, str], after: Mapping[str, str]) -> dict[str, int]:
    tally = Counter(f"{before[p]}->{after[p]}" for p in before)
    return {f"{a}->{b}": tally[f"{a}->{b}"] for a in CLASSES for b in CLASSES}


def changed_patients(before_classes: Mapping[str, str], after_classes: Mapping[str, str],
                     before: Mapping[str, Mapping[str, Cell]], after: Mapping[str, Mapping[str, Cell]],
                     order: Iterable[str]) -> list[dict[str, Any]]:
    order = list(order)
    changed = []
    for patient in sorted(before):
        criteria = [{"criterion_id": c, "from": before[patient][c].value or "execution_failure",
                     "to": after[patient][c].value or "execution_failure"}
                    for c in order if before[patient][c].value != after[patient][c].value]
        if criteria or before_classes[patient] != after_classes[patient]:
            changed.append({"patient_id": patient, "from": before_classes[patient], "to": after_classes[patient],
                            "changed_criteria": criteria})
    return changed
