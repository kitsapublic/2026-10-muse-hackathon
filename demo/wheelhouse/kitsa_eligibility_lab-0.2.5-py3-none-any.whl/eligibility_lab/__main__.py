"""Run the command line as `python -m eligibility_lab`."""
from eligibility_lab.cli import main

raise SystemExit(main())
