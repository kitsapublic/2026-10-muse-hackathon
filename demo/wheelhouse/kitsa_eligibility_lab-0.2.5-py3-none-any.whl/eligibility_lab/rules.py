"""The closed rule language of reviewed criterion interpretations.

An interpretation is `unsupported` (with its reason) or `executable`: typed parameters, an optional applicability
rule and a requirement rule. Rules are trees of these nodes only:

- `and`, `or` (two or more arguments) and `not`: three-valued logic.
- `age`: completed years on the evaluation date, compared with an integer.
- `measurement`: the latest qualifying ordinal or quantity within a window, compared after unit normalization.
- `code_in`: the latest qualifying code within a window belongs to a set of listed codes.
- `assertion`: the latest qualifying present/absent statement within a window.
- `regimen_count` and `days_since_last_dose`: distinct systemic regimens and time since the most recent dose, each
  established only within what a treatment-history completeness `assertion` allows.
- `narrative`: a narrative decision bound to the notes inside a window.

Comparators are `lt`, `le`, `gt` and `ge`. A value is a literal or `{"param": name}`. Anything else, including
unknown operators, fields, concepts, units, codes or questions, unused or undeclared parameters, and nesting deeper
than 32 levels, is refused. Nothing is ever evaluated as code.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from decimal import Decimal
import re
from types import MappingProxyType
from typing import Any, Mapping, Union

from eligibility_lab.errors import EligibilityError
from eligibility_lab.vocabulary import CONCEPTS, DECIMAL, HISTORY_CONCEPTS

COMPARATORS = ("lt", "le", "gt", "ge")
MAX_DEPTH = 32
MAX_ARGS = 64
MAX_WINDOW = 36_500
NAME = re.compile(r"[a-z][a-z0-9_]{0,63}")


@dataclass(frozen=True)
class Param:
    name: str


Value = Union[int, Decimal, Param]


@dataclass(frozen=True)
class AllOf:
    args: tuple["Node", ...]


@dataclass(frozen=True)
class AnyOf:
    args: tuple["Node", ...]


@dataclass(frozen=True)
class Not:
    arg: "Node"


@dataclass(frozen=True)
class Age:
    comparator: str
    value: Value


@dataclass(frozen=True)
class Measurement:
    concept: str
    comparator: str
    value: Value
    unit: str | None
    window_days: int | None


@dataclass(frozen=True)
class CodeIn:
    concept: str
    codes: tuple[str, ...]
    window_days: int | None


@dataclass(frozen=True)
class Assertion:
    concept: str
    window_days: int | None


@dataclass(frozen=True)
class RegimenCount:
    concept: str
    comparator: str
    value: Value
    history: Assertion


@dataclass(frozen=True)
class DaysSinceLastDose:
    concept: str
    comparator: str
    value: Value
    history: Assertion


@dataclass(frozen=True)
class Narrative:
    question: str
    window_days: int


Node = Union[AllOf, AnyOf, Not, Age, Measurement, CodeIn, Assertion, RegimenCount, DaysSinceLastDose, Narrative]


@dataclass(frozen=True)
class Parameter:
    name: str
    type: str  # integer | decimal
    value: int | Decimal
    editable: bool
    minimum: int | Decimal | None = None
    maximum: int | Decimal | None = None


@dataclass(frozen=True)
class Executable:
    rule_version: int
    parameters: Mapping[str, Parameter]
    applicability: Node | None
    requirement: Node

    def resolve(self, value: Value) -> int | Decimal:
        return self.parameters[value.name].value if isinstance(value, Param) else value


@dataclass(frozen=True)
class Unsupported:
    reason: str


Interpretation = Union[Executable, Unsupported]


class _Parser:
    def __init__(self, questions: Mapping[str, str], parameters: Mapping[str, Parameter]):
        self.questions = questions
        self.parameters = parameters
        self.used: set[str] = set()
        self.problems: list[str] = []

    def add(self, path: str, message: str) -> None:
        self.problems.append(f"{path}: {message}")

    def fields(self, raw: Any, path: str, required: tuple[str, ...]) -> dict[str, Any] | None:
        if not isinstance(raw, dict):
            self.add(path, "must be an object")
            return None
        for key in required:
            if key not in raw:
                self.add(path, f"missing field {key}")
        for key in raw:
            if key not in required:
                self.add(path, f"unexpected field {key}")
        return raw if all(key in raw for key in required) else None

    def comparator(self, raw: Any, path: str) -> str:
        if raw not in COMPARATORS:
            self.add(path, f"comparator must be one of {', '.join(COMPARATORS)}")
        return raw

    def window(self, raw: Any, path: str, *, nullable: bool = True) -> int | None:
        if raw is None and nullable:
            return None
        if type(raw) is not int or not 0 <= raw <= MAX_WINDOW:
            self.add(path, f"window_days must be an integer from 0 to {MAX_WINDOW}"
                           + (" or null" if nullable else ""))
            return 0
        return raw

    def value(self, raw: Any, path: str, kind: str) -> Value:
        """`kind` is `integer` (whole numbers, counts and days must not be negative) or `number`."""
        if isinstance(raw, dict):
            if set(raw) != {"param"} or not isinstance(raw["param"], str):
                self.add(path, "a parameter reference is exactly {\"param\": name}")
                return 0
            name = raw["param"]
            parameter = self.parameters.get(name)
            if parameter is None:
                self.add(path, f"undeclared parameter {name}")
            elif kind == "integer" and parameter.type != "integer":
                self.add(path, f"parameter {name} must be an integer, not a decimal")
            self.used.add(name)
            return Param(name)
        if type(raw) is int and raw >= 0:
            return raw if kind == "integer" else Decimal(raw)
        if kind == "number" and isinstance(raw, str) and DECIMAL.fullmatch(raw):
            return Decimal(raw)
        self.add(path, "value must be a non-negative integer" if kind == "integer"
                 else "value must be a non-negative integer or decimal string")
        return 0

    def concept(self, raw: Any, path: str, kinds: tuple[str, ...], operator: str) -> str:
        concept = CONCEPTS.get(raw) if isinstance(raw, str) else None
        if concept is None:
            self.add(path, f"unknown concept {raw!r}"[:200])
        elif concept.kind not in kinds:
            self.add(path, f"concept {raw} cannot be used by {operator}")
        return raw if isinstance(raw, str) else ""

    def history(self, raw: Any, path: str, depth: int) -> Assertion:
        node = self.node(raw, path, depth)
        if not isinstance(node, Assertion) or node.concept not in HISTORY_CONCEPTS:
            self.add(path, f"history must be an assertion of {', '.join(HISTORY_CONCEPTS)}")
            return Assertion(HISTORY_CONCEPTS[0], None)
        return node

    def node(self, raw: Any, path: str, depth: int = 1) -> Node:
        if depth > MAX_DEPTH:
            self.add(path, f"rules may not be nested more than {MAX_DEPTH} levels")
            return Assertion(HISTORY_CONCEPTS[0], None)
        if not isinstance(raw, dict):
            self.add(path, "must be an object")
            return Assertion(HISTORY_CONCEPTS[0], None)
        operator = raw.get("op")
        shapes = {"and": ("args",), "or": ("args",), "not": ("arg",), "age": ("comparator", "value"),
                  "measurement": ("concept", "comparator", "value", "unit", "window_days"),
                  "code_in": ("concept", "codes", "window_days"), "assertion": ("concept", "window_days"),
                  "regimen_count": ("concept", "comparator", "value", "history"),
                  "days_since_last_dose": ("concept", "comparator", "value", "history"),
                  "narrative": ("question", "window_days")}
        if not isinstance(operator, str) or operator not in shapes:
            self.add(f"{path}.op", f"unknown operator {operator!r}"[:200])
            return Assertion(HISTORY_CONCEPTS[0], None)
        fields = self.fields(raw, path, ("op", *shapes[operator]))
        if fields is None:
            return Assertion(HISTORY_CONCEPTS[0], None)
        if operator in ("and", "or"):
            args = fields["args"]
            if not isinstance(args, list) or not 2 <= len(args) <= MAX_ARGS:
                self.add(f"{path}.args", f"{operator} needs at least two and at most {MAX_ARGS} arguments")
                return Assertion(HISTORY_CONCEPTS[0], None)
            nodes = tuple(self.node(arg, f"{path}.args[{i}]", depth + 1) for i, arg in enumerate(args))
            return AllOf(nodes) if operator == "and" else AnyOf(nodes)
        if operator == "not":
            return Not(self.node(fields["arg"], f"{path}.arg", depth + 1))
        if operator == "age":
            return Age(self.comparator(fields["comparator"], path), self.value(fields["value"], f"{path}.value",
                                                                              "integer"))
        if operator == "measurement":
            concept = self.concept(fields["concept"], f"{path}.concept", ("ordinal", "quantity"), operator)
            unit = fields["unit"]
            known = CONCEPTS.get(concept)
            if known is not None and known.kind == "ordinal" and unit is not None:
                self.add(f"{path}.unit", f"{concept} is an ordinal score and takes no unit")
            if known is not None and known.kind == "quantity" and (not isinstance(unit, str) or
                                                                   unit not in dict(known.units)):
                self.add(f"{path}.unit", f"unit {unit!r} is not supported for {concept}"[:200])
            kind = "integer" if known is not None and known.kind == "ordinal" else "number"
            return Measurement(concept, self.comparator(fields["comparator"], path),
                               self.value(fields["value"], f"{path}.value", kind), unit,
                               self.window(fields["window_days"], f"{path}.window_days"))
        if operator == "code_in":
            concept = self.concept(fields["concept"], f"{path}.concept", ("code",), operator)
            codes = fields["codes"]
            if not isinstance(codes, list) or not codes or len(set(map(str, codes))) != len(codes):
                self.add(f"{path}.codes", "codes must be a non-empty list of distinct codes")
                codes = []
            known = CONCEPTS.get(concept)
            for code in codes:
                if known is not None and code not in known.codes:
                    self.add(f"{path}.codes", f"unknown code {code!r} for {concept}"[:200])
            return CodeIn(concept, tuple(codes), self.window(fields["window_days"], f"{path}.window_days"))
        if operator == "assertion":
            return Assertion(self.concept(fields["concept"], f"{path}.concept", ("assertion",), operator),
                             self.window(fields["window_days"], f"{path}.window_days"))
        if operator in ("regimen_count", "days_since_last_dose"):
            concept = self.concept(fields["concept"], f"{path}.concept", ("regimen",), operator)
            node_type = RegimenCount if operator == "regimen_count" else DaysSinceLastDose
            return node_type(concept, self.comparator(fields["comparator"], path),
                             self.value(fields["value"], f"{path}.value", "integer"),
                             self.history(fields["history"], f"{path}.history", depth + 1))
        question = fields["question"]
        if not isinstance(question, str) or question not in self.questions:
            self.add(f"{path}.question", f"unknown question {question!r}"[:200])
        return Narrative(question if isinstance(question, str) else "",
                         self.window(fields["window_days"], f"{path}.window_days", nullable=False) or 0)


def _bound(raw: Any, kind: str) -> int | Decimal | None:
    if kind == "integer" and type(raw) is int:
        return raw
    if kind == "decimal" and isinstance(raw, str) and DECIMAL.fullmatch(raw):
        return Decimal(raw)
    return None


def _parameters(raw: Any, path: str, problems: list[str]) -> dict[str, Parameter]:
    if not isinstance(raw, dict):
        problems.append(f"{path}: must be an object")
        return {}
    parameters = {}
    for name, entry in raw.items():
        where = f"{path}.{name}"
        if not NAME.fullmatch(name):
            problems.append(f"{where}: parameter names are lower-case identifiers")
            continue
        if not isinstance(entry, dict):
            problems.append(f"{where}: must be an object")
            continue
        editable = entry.get("editable")
        required = ("type", "value", "editable", "minimum", "maximum") if editable is True \
            else ("type", "value", "editable")
        allowed = ("type", "value", "editable", "minimum", "maximum")
        missing = [key for key in required if key not in entry]
        unexpected = [key for key in entry if key not in allowed]
        problems.extend(f"{where}: missing field {key}" + (" (editable parameters declare their bounds)"
                                                           if key in ("minimum", "maximum") else "")
                        for key in missing)
        problems.extend(f"{where}: unexpected field {key}" for key in unexpected)
        if type(editable) is not bool:
            problems.append(f"{where}: editable must be true or false")
        kind = entry.get("type")
        if kind not in ("integer", "decimal"):
            problems.append(f"{where}: type must be integer or decimal")
            continue
        value = _bound(entry.get("value"), kind)
        bounds = [_bound(entry[key], kind) if key in entry else None for key in ("minimum", "maximum")]
        if value is None:
            problems.append(f"{where}: value must be {'an integer' if kind == 'integer' else 'a decimal string'}")
            continue
        if any(key in entry and bound is None for key, bound in zip(("minimum", "maximum"), bounds)):
            problems.append(f"{where}: bounds must have the parameter's type")
            continue
        minimum, maximum = bounds
        if (minimum is not None and value < minimum) or (maximum is not None and value > maximum):
            problems.append(f"{where}: value lies outside its bounds")
        if missing or unexpected or type(editable) is not bool:
            continue
        parameters[name] = Parameter(name, kind, value, editable, minimum, maximum)
    return parameters


def parse_interpretation(raw: Any, *, questions: Mapping[str, str], path: str) -> Interpretation:
    problems: list[str] = []
    if not isinstance(raw, dict) or raw.get("status") not in ("executable", "unsupported"):
        raise EligibilityError("rule_invalid", f"{path} is not a valid interpretation",
                               [f"{path}.status: must be executable or unsupported"])
    if raw["status"] == "unsupported":
        if set(raw) != {"status", "reason"} or not isinstance(raw["reason"], str) or not raw["reason"].strip():
            raise EligibilityError("rule_invalid", f"{path} is not a valid interpretation",
                                   [f"{path}: an unsupported interpretation has exactly a non-empty reason"])
        return Unsupported(raw["reason"])
    expected = {"status", "rule_version", "parameters", "applicability", "requirement"}
    problems += [f"{path}: missing field {key}" for key in sorted(expected - set(raw))]
    problems += [f"{path}: unexpected field {key}" for key in sorted(set(raw) - expected)]
    if problems:
        raise EligibilityError("rule_invalid", f"{path} is not a valid interpretation", problems)
    if type(raw["rule_version"]) is not int or raw["rule_version"] < 1:
        problems.append(f"{path}.rule_version: must be a positive integer")
    parameters = _parameters(raw["parameters"], f"{path}.parameters", problems)
    parser = _Parser(questions, parameters)
    applicability = None if raw["applicability"] is None \
        else parser.node(raw["applicability"], f"{path}.applicability")
    requirement = parser.node(raw["requirement"], f"{path}.requirement")
    problems += parser.problems
    for name in sorted(set(parameters) - parser.used):
        problems.append(f"{path}.parameters.{name}: unused parameter")
    if problems:
        raise EligibilityError("rule_invalid", f"{path} is not a valid interpretation", problems)
    return Executable(raw["rule_version"], MappingProxyType(parameters), applicability, requirement)


def edit_value(parameter: Parameter, raw: Any, path: str) -> int | Decimal:
    """The validated new value of an editable parameter."""
    value = _bound(raw, parameter.type)
    if value is None:
        raise EligibilityError("invalid_parameter_value", f"{path} must be "
                               + ("an integer" if parameter.type == "integer" else "a decimal string"))
    if value < parameter.minimum or value > parameter.maximum:
        raise EligibilityError("parameter_out_of_bounds",
                               f"{path} must lie from {parameter.minimum} to {parameter.maximum}")
    return value


def with_value(interpretation: Executable, name: str, value: int | Decimal) -> Executable:
    parameters = dict(interpretation.parameters)
    parameters[name] = replace(parameters[name], value=value)
    return replace(interpretation, parameters=MappingProxyType(parameters))


def _text(value: int | Decimal | None) -> int | str | None:
    return str(value) if isinstance(value, Decimal) else value


def node_json(node: Node) -> dict[str, Any]:
    if isinstance(node, (AllOf, AnyOf)):
        return {"op": "and" if isinstance(node, AllOf) else "or", "args": [node_json(arg) for arg in node.args]}
    if isinstance(node, Not):
        return {"op": "not", "arg": node_json(node.arg)}
    names = {Age: "age", Measurement: "measurement", CodeIn: "code_in", Assertion: "assertion",
             RegimenCount: "regimen_count", DaysSinceLastDose: "days_since_last_dose", Narrative: "narrative"}
    result: dict[str, Any] = {"op": names[type(node)]}
    for field, value in vars(node).items():
        if isinstance(value, Param):
            value = {"param": value.name}
        elif isinstance(value, Assertion):
            value = node_json(value)
        elif isinstance(value, tuple):
            value = list(value)
        result[field] = _text(value) if not isinstance(value, (dict, list)) else value
    return result


def interpretation_json(interpretation: Interpretation) -> dict[str, Any]:
    if isinstance(interpretation, Unsupported):
        return {"status": "unsupported", "reason": interpretation.reason}
    return {"status": "executable", "rule_version": interpretation.rule_version,
            "parameters": {name: {"type": p.type, "value": _text(p.value), "editable": p.editable,
                                  "minimum": _text(p.minimum), "maximum": _text(p.maximum)}
                           for name, p in interpretation.parameters.items()},
            "applicability": None if interpretation.applicability is None
            else node_json(interpretation.applicability),
            "requirement": node_json(interpretation.requirement)}


def narratives_of(interpretation: Interpretation) -> tuple[Narrative, ...]:
    """The distinct narrative leaves an interpretation reads, applicability first, in rule order."""
    found: list[Narrative] = []

    def visit(node: Node) -> None:
        if isinstance(node, (AllOf, AnyOf)):
            for arg in node.args:
                visit(arg)
        elif isinstance(node, Not):
            visit(node.arg)
        elif isinstance(node, Narrative) and node not in found:
            found.append(node)

    if isinstance(interpretation, Executable):
        for root in (interpretation.applicability, interpretation.requirement):
            if root is not None:
                visit(root)
    return tuple(found)


def questions_of(interpretation: Interpretation) -> tuple[str, ...]:
    """The narrative questions an interpretation reads, in rule order."""
    return tuple(dict.fromkeys(leaf.question for leaf in narratives_of(interpretation)))
