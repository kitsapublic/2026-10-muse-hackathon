"""Canonical JSON and SHA-256 identities that reproduce byte for byte.

Floats are refused in both directions: decimal values travel as strings, so every producer encodes them identically.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any


def _check(value: Any) -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("canonical JSON keys must be strings")
            _check(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _check(item)
    elif value is not None and not isinstance(value, (str, int, bool)):
        raise TypeError(f"canonical JSON cannot encode {type(value).__name__}")


def canonical_json(value: Any) -> bytes:
    _check(value)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
                      allow_nan=False).encode("utf-8")


def digest(value: Any) -> str:
    return hashlib.sha256(canonical_json(value)).hexdigest()


def strict_loads(data: bytes) -> Any:
    """UTF-8 JSON without duplicate keys, floats or non-finite numbers."""
    def pairs(items):
        result = {}
        for key, item in items:
            if key in result:
                raise ValueError("duplicate JSON key")
            result[key] = item
        return result

    def refuse(text):
        raise ValueError("JSON numbers must be integers; decimals are strings")

    return json.loads(data.decode("utf-8"), object_pairs_hook=pairs, parse_float=refuse, parse_constant=refuse)
