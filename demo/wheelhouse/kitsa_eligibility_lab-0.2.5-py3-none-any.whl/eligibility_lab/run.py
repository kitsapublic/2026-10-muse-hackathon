"""Runs of a bundle: identities, decision reuse, results, scenario comparisons and timing.

A run is pinned by its bundle, protocol, effective criterion set, cohort, narrative-decision source, evaluation
date, scenario (saved, custom edits with their author, or the baseline), waterfall order, interpreter, normalizer,
evaluator and workspace. `run_id` is the digest of exactly that record. Every criterion must be approved before a
run. The baseline criteria are never modified; a scenario evaluates a new criterion set.

A decision is cached under the digest of the patient's evidence and notes, the patient's narrative decisions and
their source kind, the criterion's rule digest and interpreter, the evaluation date and the normalizer and evaluator
identities, so any change that can alter it misses the cache, and a threshold scenario recomputes only the criteria it
edits.

A result's `content_digest` covers everything except `execution_metrics`, so identical inputs reproduce it exactly.
Times are integer microseconds.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from decimal import Decimal
import math
import platform
from time import perf_counter_ns
from typing import Any, Mapping, Sequence

from eligibility_lab import __version__
from eligibility_lab.aggregation import (changed_patients, classify, counts, coverage, impact, status, summaries,
                                         transitions, waterfall)
from eligibility_lab.canonical import digest
from eligibility_lab.errors import EligibilityError
from eligibility_lab.evaluation import Cell, Context, evaluate_cell
from eligibility_lab.model import BASELINE, IDENTIFIER, Bundle, CriterionSet, Edit, Patient
from eligibility_lab.rules import Executable
from eligibility_lab.vocabulary import NORMALIZER

EVALUATOR = {"name": "kitsa-eligibility-lab", "version": __version__}
DEFAULT_WORKSPACE = "local-synthetic"
RESULT_FORMAT = "kitsa/eligibility-lab-result/1"
COMPARISON_FORMAT = "kitsa/eligibility-lab-comparison/1"
BENCHMARK_FORMAT = "kitsa/eligibility-lab-benchmark/1"


class DecisionCache:
    """Decisions by their key; a cell is immutable, so a reused decision is exactly the one computed."""

    def __init__(self):
        self._cells: dict[str, Cell] = {}

    def get(self, key: str) -> Cell | None:
        return self._cells.get(key)

    def put(self, key: str, cell: Cell) -> None:
        self._cells[key] = cell


@dataclass(frozen=True)
class _Plan:
    scenario: dict[str, Any]
    criteria: CriterionSet
    evaluation_date: date
    order: tuple[str, ...]
    workspace: str


@dataclass(frozen=True)
class _Run:
    plan: _Plan
    matrix: dict[str, dict[str, Cell]]
    classes: dict[str, str]
    result: dict[str, Any]


def _json_value(value: Any) -> Any:
    return str(value) if isinstance(value, Decimal) else value


def _edit_json(edit: Edit) -> dict[str, Any]:
    return {"criterion_id": edit.criterion_id, "parameter": edit.parameter, "value": _json_value(edit.value)}


def _plan(bundle: Bundle, scenario: str | None, edits: Sequence[Edit] | None, author: str | None,
          evaluation_date: date | None, order: Sequence[str] | None, workspace: str) -> _Plan:
    if edits is not None and scenario not in (None, BASELINE):
        raise EligibilityError("invalid_scenario", "name a saved scenario or give edits, not both")
    if edits is not None:
        criteria = bundle.criteria.apply(edits)
        described = {"scenario_id": "custom", "title": "Custom edits", "author": author or "unspecified",
                     "edits": [_edit_json(edit) for edit in edits]}
    elif scenario in (None, BASELINE):
        criteria = bundle.criteria
        described = {"scenario_id": BASELINE, "title": "Protocol criteria", "author": None, "edits": []}
    else:
        saved = bundle.scenario(scenario)
        criteria = bundle.criteria.apply(saved.edits)
        described = {"scenario_id": saved.scenario_id, "title": saved.title, "author": saved.author,
                     "edits": [_edit_json(edit) for edit in saved.edits]}
    pending = [c.criterion_id for c in criteria.criteria if c.review_state != "approved"]
    if pending:
        raise EligibilityError("criteria_not_reviewed", "every criterion must be approved before it is run", pending)
    identifiers = [c.criterion_id for c in criteria.criteria]
    order = tuple(identifiers if order is None else order)
    if not all(isinstance(c, str) for c in order) or sorted(order) != sorted(identifiers):
        raise EligibilityError("invalid_order", "the waterfall order must name every criterion exactly once")
    if not isinstance(workspace, str) or not IDENTIFIER.fullmatch(workspace):
        raise EligibilityError("invalid_run", "the workspace must be an identifier")
    if evaluation_date is not None and type(evaluation_date) is not date:
        raise EligibilityError("invalid_run", "the evaluation date must be a date without a time")
    return _Plan(described, criteria, evaluation_date or bundle.reference_date, order, workspace)


def _record(bundle: Bundle, plan: _Plan) -> dict[str, Any]:
    return {"bundle": {"bundle_id": bundle.bundle_id, "bundle_version": bundle.bundle_version},
            "protocol": {"protocol_id": bundle.protocol.protocol_id, "version": bundle.protocol.version,
                         "digest": bundle.protocol.digest},
            "criterion_set": {"criterion_set_id": plan.criteria.criterion_set_id, "version": plan.criteria.version,
                              "digest": plan.criteria.digest},
            "cohort": {"cohort_id": bundle.cohort.cohort_id, "version": bundle.cohort.version,
                       "digest": bundle.cohort.digest, "patients": len(bundle.cohort.patients)},
            "narrative": {"kind": bundle.narrative.kind, "digest": bundle.narrative.digest},
            "evaluation_date": plan.evaluation_date.isoformat(), "scenario": plan.scenario,
            "waterfall_order": list(plan.order), "interpreter": dict(plan.criteria.interpreter),
            "normalizer": dict(NORMALIZER), "evaluator": dict(EVALUATOR), "workspace": plan.workspace}


def _key(bundle: Bundle, patient: Patient, plan: _Plan, rule_digest: str) -> str:
    return digest({"patient": patient.digest, "narrative_kind": bundle.narrative.kind,
                   "narrative": bundle.narrative.patient_digests.get(patient.patient_id),
                   "rule": rule_digest, "interpreter": dict(plan.criteria.interpreter),
                   "evaluation_date": plan.evaluation_date.isoformat(), "normalizer": NORMALIZER["digest"],
                   "evaluator": dict(EVALUATOR)})


def _cell_json(cell: Cell) -> dict[str, Any]:
    return {"outcome": cell.outcome, "value": cell.value, "reasons": list(cell.reasons),
            "failures": list(cell.failures), "applicability": cell.applicability, "evidence": list(cell.evidence),
            "narrative_decisions": list(cell.narrative), "sources": list(cell.sources)}


def _parameters(criterion) -> dict[str, Any]:
    interpretation = criterion.interpretation
    if not isinstance(interpretation, Executable):
        return {}
    return {name: _json_value(p.value) for name, p in interpretation.parameters.items()}


def _execute(bundle: Bundle, plan: _Plan, cache: DecisionCache) -> _Run:
    started = perf_counter_ns()
    context = Context(plan.evaluation_date, bundle.narrative)
    matrix: dict[str, dict[str, Cell]] = {}
    computed = reused = 0
    for patient in bundle.cohort.patients:
        row = matrix[patient.patient_id] = {}
        for criterion in plan.criteria.criteria:
            key = _key(bundle, patient, plan, criterion.rule_digest)
            cell = cache.get(key)
            if cell is None:
                cell = evaluate_cell(criterion, patient, context)
                cache.put(key, cell)
                computed += 1
            else:
                reused += 1
            row[criterion.criterion_id] = cell
    categories = {c.criterion_id: c.category for c in plan.criteria.criteria}
    classes = {patient: classify(cells, categories) for patient, cells in matrix.items()}
    record = _record(bundle, plan)
    patients = []
    for patient_id in sorted(matrix):
        cells = matrix[patient_id]
        statuses = [(c, status(categories[c], cells[c])) for c in plan.order]
        patients.append({"patient_id": patient_id, "classification": classes[patient_id],
                         "failing_criteria": [c for c, state in statuses if state == "failing"],
                         "unresolved_criteria": [c for c, state in statuses if state == "unresolved"],
                         "cells": {c: _cell_json(cell) for c, cell in cells.items()}})
    result: dict[str, Any] = {
        "format": RESULT_FORMAT, "run_id": digest(record), "run": record,
        "criteria": [{"criterion_id": c.criterion_id, "category": c.category, "text": c.text, "anchor": c.anchor,
                      "interpretation": "executable" if isinstance(c.interpretation, Executable) else "unsupported",
                      "parameters": _parameters(c), "rule_digest": c.rule_digest,
                      "baseline_rule_digest": bundle.criteria.criterion(c.criterion_id).rule_digest}
                     for c in (plan.criteria.criterion(identifier) for identifier in plan.order)],
        "patients": patients, "counts": counts(classes.values()), "coverage": coverage(plan.order, matrix),
        "waterfall": waterfall(plan.order, matrix, categories),
        "criterion_impact": impact(plan.order, matrix, categories),
        "summaries": summaries(classes, {p.patient_id: p for p in bundle.cohort.patients}, plan.evaluation_date)}
    result["content_digest"] = digest(result)
    result["execution_metrics"] = {"elapsed_us": (perf_counter_ns() - started) // 1000,
                                   "decisions_computed": computed, "decisions_reused": reused,
                                   "patients": len(matrix), "criteria": len(categories),
                                   "cells": len(matrix) * len(categories)}
    return _Run(plan, matrix, classes, result)


def evaluate(bundle: Bundle, *, scenario: str | None = BASELINE, edits: Sequence[Edit] | None = None,
             author: str | None = None, evaluation_date: date | None = None, order: Sequence[str] | None = None,
             workspace: str = DEFAULT_WORKSPACE, cache: DecisionCache | None = None) -> dict[str, Any]:
    """The result document of one run."""
    plan = _plan(bundle, scenario, edits, author, evaluation_date, order, workspace)
    return _execute(bundle, plan, DecisionCache() if cache is None else cache).result


def compare(bundle: Bundle, *, scenario: str | None = None, edits: Sequence[Edit] | None = None,
            author: str | None = None, evaluation_date: date | None = None, workspace: str = DEFAULT_WORKSPACE,
            cache: DecisionCache | None = None) -> dict[str, Any]:
    """The scenario against the immutable baseline on the same cohort and evaluation date, both recalculated."""
    if edits is None and scenario in (None, BASELINE):
        raise EligibilityError("invalid_scenario", "a comparison needs a saved scenario or edits")
    started = perf_counter_ns()
    cache = DecisionCache() if cache is None else cache
    before = _execute(bundle, _plan(bundle, BASELINE, None, None, evaluation_date, None, workspace), cache)
    after = _execute(bundle, _plan(bundle, scenario, edits, author, evaluation_date, None, workspace), cache)
    changed = []
    for criterion in after.plan.criteria.criteria:
        original = bundle.criteria.criterion(criterion.criterion_id)
        if criterion.rule_digest == original.rule_digest:
            continue
        old, new = _parameters(original), _parameters(criterion)
        changed.append({"criterion_id": criterion.criterion_id,
                        "edits": [{"parameter": name, "from": old[name], "to": new[name]}
                                  for name in new if old.get(name) != new[name]],
                        "baseline_rule_digest": original.rule_digest, "scenario_rule_digest": criterion.rule_digest})
    comparison: dict[str, Any] = {
        "format": COMPARISON_FORMAT,
        "baseline": {key: before.result[key] for key in ("run_id", "content_digest", "counts")},
        "scenario": {**{key: after.result[key] for key in ("run_id", "content_digest", "counts")},
                     **after.plan.scenario},
        "evaluation_date": after.plan.evaluation_date.isoformat(),
        "complete": before.result["coverage"]["complete"] and after.result["coverage"]["complete"],
        "changed_criteria": changed,
        "passing_delta": after.result["counts"]["passing"] - before.result["counts"]["passing"],
        "transitions": transitions(before.classes, after.classes),
        "changed_patients": changed_patients(before.classes, after.classes, before.matrix, after.matrix,
                                             before.plan.order),
        "summaries": {"baseline": before.result["summaries"], "scenario": after.result["summaries"]}}
    comparison["content_digest"] = digest(comparison)
    comparison["execution_metrics"] = {"elapsed_us": (perf_counter_ns() - started) // 1000,
                                       "baseline": before.result["execution_metrics"],
                                       "scenario": after.result["execution_metrics"]}
    return comparison


def _spread(samples: list[int]) -> dict[str, int]:
    ordered = sorted(samples)
    return {"min": ordered[0], "median": ordered[(len(ordered) - 1) // 2],
            "p95": ordered[math.ceil(0.95 * len(ordered)) - 1], "max": ordered[-1]}


def benchmark(bundle: Bundle, *, repeat: int, workspace: str = DEFAULT_WORKSPACE) -> dict[str, Any]:
    """Wall-clock time of full recalculation, and of a scenario reusing the baseline's unchanged decisions, for the
    baseline and every saved scenario; each repetition starts from an empty cache."""
    if type(repeat) is not int or not 1 <= repeat <= 1000:
        raise EligibilityError("invalid_run", "repeat must be an integer from 1 to 1000")
    entries = []
    for scenario in (BASELINE, *(s.scenario_id for s in bundle.scenarios)):
        full, reuse, digests, identities = [], [], set(), set()
        for _ in range(repeat):
            started = perf_counter_ns()
            result = evaluate(bundle, scenario=scenario, workspace=workspace)
            full.append((perf_counter_ns() - started) // 1000)
            digests.add(result["content_digest"])
            identities.add(result["run_id"])
            if scenario != BASELINE:
                cache = DecisionCache()
                evaluate(bundle, workspace=workspace, cache=cache)
                started = perf_counter_ns()
                reused = evaluate(bundle, scenario=scenario, workspace=workspace, cache=cache)
                reuse.append((perf_counter_ns() - started) // 1000)
                digests.add(reused["content_digest"])
        deterministic = len(digests) == 1 and len(identities) == 1
        entries.append({"scenario_id": scenario, "run_id": min(identities) if deterministic else None,
                        "content_digest": min(digests) if deterministic else None, "deterministic": deterministic,
                        "full_recalculation_us": _spread(full),
                        "recalculation_with_reuse_us": _spread(reuse) if reuse else None})
    return {"format": BENCHMARK_FORMAT,
            "bundle": {"bundle_id": bundle.bundle_id, "bundle_version": bundle.bundle_version,
                       "cohort_digest": bundle.cohort.digest},
            "evaluator": dict(EVALUATOR), "patients": len(bundle.cohort.patients),
            "criteria": len(bundle.criteria.criteria), "repeat": repeat,
            "platform": {"python": platform.python_version(), "implementation": platform.python_implementation(),
                         "system": platform.system(), "release": platform.release(), "machine": platform.machine()},
            "scenarios": entries}
