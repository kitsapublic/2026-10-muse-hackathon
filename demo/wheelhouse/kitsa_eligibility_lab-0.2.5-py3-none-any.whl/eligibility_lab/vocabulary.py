"""The closed concept vocabulary and unit normalizer.

Every evidence concept has one value kind. Quantities convert to their canonical unit with exact decimal factors;
a missing or unlisted unit has no conversion, so it can never be compared. Units are UCUM codes and are matched
exactly. Haemoglobin in mmol/L uses the monomer molar mass, 16,114 g/mol. The normalizer identity is the digest of
these tables, so any change to a concept, code list or factor changes every identity that depends on it.
"""
from __future__ import annotations

from dataclasses import dataclass
from decimal import Context, Decimal, ROUND_HALF_EVEN
import re

from eligibility_lab.canonical import digest

KINDS = ("date", "code", "assertion", "ordinal", "quantity", "regimen")
DECIMAL = re.compile(r"(0|[1-9][0-9]{0,15})(\.[0-9]{1,12})?")
# Exact for every factor and amount the patterns allow; independent of any caller's decimal context.
ARITHMETIC = Context(prec=40, rounding=ROUND_HALF_EVEN)


@dataclass(frozen=True)
class Concept:
    name: str
    kind: str
    codes: tuple[str, ...] = ()
    minimum: int | None = None
    maximum: int | None = None
    canonical_unit: str | None = None
    units: tuple[tuple[str, str], ...] = ()  # (UCUM unit, decimal factor to the canonical unit)


CONCEPTS = {concept.name: concept for concept in (
    Concept("birth_date", "date"),
    Concept("sex", "code", codes=("female", "male")),
    Concept("nsclc_histology", "assertion"),
    Concept("disease_stage", "code",
            codes=("0", "IA1", "IA2", "IA3", "IB", "IIA", "IIB", "IIIA", "IIIB", "IIIC", "IVA", "IVB")),
    Concept("ecog", "ordinal", minimum=0, maximum=5),
    Concept("neutrophils", "quantity", canonical_unit="10*9/L",
            units=(("10*9/L", "1"), ("10*3/uL", "1"), ("/uL", "0.001"), ("/mm3", "0.001"))),
    Concept("haemoglobin", "quantity", canonical_unit="g/dL",
            units=(("g/dL", "1"), ("g/L", "0.1"), ("mmol/L", "1.6114"))),
    Concept("systemic_anticancer_regimen", "regimen"),
    Concept("systemic_therapy_history_complete", "assertion"),
)}
# Assertions that may state a treatment history complete for regimen counts and washouts.
HISTORY_CONCEPTS = ("systemic_therapy_history_complete",)


def to_canonical(concept: str, amount: Decimal, unit: str | None) -> Decimal | None:
    """`amount` in the concept's canonical unit, or None when the unit is missing or not listed for it."""
    factors = dict(CONCEPTS[concept].units)
    if unit is None or unit not in factors:
        return None
    return ARITHMETIC.multiply(amount, Decimal(factors[unit]))


def _description() -> dict:
    return {"concepts": [{"name": c.name, "kind": c.kind, "codes": list(c.codes), "minimum": c.minimum,
                          "maximum": c.maximum, "canonical_unit": c.canonical_unit,
                          "units": [list(unit) for unit in c.units]} for c in CONCEPTS.values()],
            "history_concepts": list(HISTORY_CONCEPTS)}


NORMALIZER = {"name": "kitsa-eligibility-lab-normalizer", "version": "1", "digest": digest(_description())}
